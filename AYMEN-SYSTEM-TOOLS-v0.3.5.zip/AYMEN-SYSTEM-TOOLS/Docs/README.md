# AYMEN SYSTEM TOOLS v0.3.5

**One Application. Complete Windows Control.**  (Windows 10 / 11, PowerShell 5.1, no installation)

## Run
Double-click `Start-AymenSystemTools.bat`. If something fails, run `Start-AymenSystemTools-Debug.bat`
(keeps the console open) and read the newest file in `Logs\`.
If Windows blocked the downloaded zip: right-click the zip > Properties > Unblock, then extract again.

## Pages (all delivered)
- **Dashboard**: health score hero banner, recommendations with action buttons, quick actions, system overview, disks.
- **Performance**: live CPU / RAM / disk graphs, fast virtual process list, search, sort, end process (critical processes protected).
- **Maintenance**: disk cleanup (analyze, choose, clean), full repair (DISM + SFC), SFC, DISM, CHKDSK scan,
  restart Explorer, flush DNS, Windows Update reset (expert). Live console, progress, cancel, copy.
- **Network**: adapters table, one-click diagnosis, ping, traceroute, DNS lookup, active connections, renew IP, network reset (expert).
- **Apps & Startup**: startup programs (enable/disable, reversible), Windows services (start/stop/restart/startup type,
  essential services protected), installed programs (search, uninstall, export CSV).
- **Storage**: drives overview, physical disk health, folder size analysis, 50 largest files.
- **Security**: 9 read-only checks with a score, update Defender signatures, quick scan. Never disables protection.
- **Diagnostics**: recent event-log errors with full message, devices with problems and drivers, hardware details,
  HTML technical report, battery report.
- **Windows Tools**: 28 built-in admin tools, searchable.
- **Restore**: create restore points, list them, open System Restore / Protection / Backup.
- **Settings** (language en/fr/ar, dark/light, beginner/expert mode, folders) and **Help** (guide + glossary).

## Build an EXE
Run `Build-Exe.bat` (see Docs\BUILD-EXE.md): one standalone `dist\AYMEN-SYSTEM-TOOLS.exe`, or a launcher EXE as an offline fallback.

## Safety
Every system-changing action asks for confirmation. Personal documents are never deleted. Protection is never
turned off. Admin-only actions offer to restart as administrator.

## Structure
```
AymenSystemTools.ps1       entry point (modules loaded from memory; a broken module is logged, not fatal)
Build-Exe.bat / .ps1       builds dist\AYMEN-SYSTEM-TOOLS.exe
Modules\modules.txt        module load order (shared by the entry script and the EXE builder)
Modules\Main.ps1           application start (paths, DPI, error handling)
Modules\Core.ps1           paths, logging, settings, languages, themes, icons, system summary
Modules\Background.ps1     background runspaces (one-shot jobs and workers, non-blocking stop)
Modules\Kit.ps1            UI components (design system, virtual data list, tabs, hero banner)
Modules\Tasks.ps1          long tasks with live console, admin checks, async page loading
Modules\UI.ps1             window shell, sidebar, page switching
Modules\Performance.ps1    live graphs and process manager
Modules\Page.*.ps1         Dashboard, Maintenance, Network, Tools, Misc (Settings/Help), Apps, Storage,
                           Security, Diagnostics, Restore
Lang\                      en.json, fr.json, ar.json
Config\settings.json       Language, Theme, ExpertMode
Logs\  Reports\  Icons\   runtime folders
```
