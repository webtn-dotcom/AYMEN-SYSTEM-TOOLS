# Build the EXE

Double-click **Build-Exe.bat** in the project folder. The result is `dist\AYMEN-SYSTEM-TOOLS.exe`.

| Mode | What it makes | Needs |
|---|---|---|
| Single (default) | ONE standalone EXE: every module and language is embedded. Copy it anywhere. | PS2EXE module (installed automatically from the PowerShell Gallery the first time, internet needed once) |
| Launcher | Small EXE that starts `AymenSystemTools.ps1` with `-ExecutionPolicy Bypass`. Keep it in the project folder. | Nothing (uses the C# compiler built into Windows, works offline) |

`Build-Exe.bat` tries Single first and falls back to Launcher automatically.
Force a mode: `Build-Exe.bat -Mode Single` or `-Mode Launcher`. Add `-RequireAdmin` to always ask for administrator rights.

## Why it now works on every PC
- Modules are read as text and run from memory, so the PowerShell Execution Policy cannot block them.
- The program looks for its folders next to the EXE and in the parent folder; the Single EXE needs none.
- Config, Logs and Reports are created next to the EXE; if that folder is read-only they go to `%LOCALAPPDATA%\AYMEN-SYSTEM-TOOLS`.
- "Restart as administrator" relaunches the EXE itself.

## Notes
- Some antivirus products warn about any EXE made with PS2EXE (false positive). If that happens use the Launcher mode or sign the EXE.
- After changing any module or language file, build again.
