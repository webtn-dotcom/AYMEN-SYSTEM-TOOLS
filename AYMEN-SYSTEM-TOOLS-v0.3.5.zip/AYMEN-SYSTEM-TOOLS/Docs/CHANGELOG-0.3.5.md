# AYMEN SYSTEM TOOLS v0.3.5

## Display and rendering
- Moved process DPI initialization to the entry point, before Windows Forms is loaded.
- Prefer Per-Monitor DPI Awareness V2, with a legacy System-DPI fallback for older Windows versions.
- Set the WinForms compatible text-rendering default explicitly before creating controls.
- Improved glyph rendering for the generated application icon on its opaque bitmap.
- Removed the late DPI initialization from the application startup routine.

## Compatibility and scope
- Preserves the v0.3.4 pages, tools, language files, themes, and layout.
- This is a rendering-focused update; visual smoothness and sharpness still require confirmation on the target Windows machine.
