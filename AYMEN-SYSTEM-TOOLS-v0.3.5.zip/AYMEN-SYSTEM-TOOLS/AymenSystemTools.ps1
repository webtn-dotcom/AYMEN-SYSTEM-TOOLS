<#
    AYMEN SYSTEM TOOLS - entry point.
    - Works as a plain script (Start-AymenSystemTools.bat) and when this file is converted to an EXE.
    - Modules are read as TEXT and executed from memory, so the PowerShell Execution Policy never
      blocks them (the policy only applies to script FILES).
    - For a fully standalone EXE use Build-Exe.bat (embeds every module and language).
    Keep all .ps1 files ASCII-only. Translated text lives in Lang\*.json (UTF-8).
#>
param()

$ErrorActionPreference = 'Stop'

# Establish DPI awareness before loading Windows Forms or creating any controls.
# Prefer Per-Monitor V2 on Windows 10 1703+, then fall back safely on older systems.
try {
    if (-not ('AstDisplayNative' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class AstDisplayNative {
    [DllImport("user32.dll", EntryPoint="SetProcessDpiAwarenessContext", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SetProcessDpiAwarenessContext(IntPtr value);

    [DllImport("user32.dll", EntryPoint="SetProcessDPIAware", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SetProcessDPIAware();
}
'@ -ErrorAction Stop
    }
    # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = (HANDLE)-4
    [void][AstDisplayNative]::SetProcessDpiAwarenessContext([IntPtr](-4))
}
catch {
    try { [void][AstDisplayNative]::SetProcessDPIAware() } catch { }
}

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
try { [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch { }
[System.Windows.Forms.Application]::SetUnhandledExceptionMode([System.Windows.Forms.UnhandledExceptionMode]::CatchException)

function Find-AstRoot {
    $candidates = New-Object System.Collections.ArrayList
    if ($PSScriptRoot) { [void]$candidates.Add($PSScriptRoot) }
    try {
        $exeDir = Split-Path -Parent ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName)
        [void]$candidates.Add($exeDir)
        [void]$candidates.Add((Split-Path -Parent $exeDir))
    }
    catch { }
    try { [void]$candidates.Add((Get-Location).Path) } catch { }
    foreach ($c in $candidates) {
        if ($c -and (Test-Path -LiteralPath (Join-Path $c 'Modules\Core.ps1'))) { return $c }
    }
    return $null
}

$Root = Find-AstRoot
if (-not $Root) {
    [void][System.Windows.Forms.MessageBox]::Show(
        "The 'Modules' folder was not found.`n`nKeep this program next to the Modules and Lang folders, or build the standalone version with Build-Exe.bat.",
        'AYMEN SYSTEM TOOLS', 'OK', 'Error')
    exit 1
}

# Load every module from memory (no dot-sourcing of files = no Execution Policy problem)
$loadErrors = @()
$moduleNames = @(Get-Content -LiteralPath (Join-Path $Root 'Modules\modules.txt') | Where-Object { $_.Trim() -and -not $_.Trim().StartsWith('#') } | ForEach-Object { $_.Trim() })
foreach ($moduleName in $moduleNames) {
    $modulePath = Join-Path $Root ('Modules\' + $moduleName + '.ps1')
    try { . ([scriptblock]::Create([System.IO.File]::ReadAllText($modulePath))) }
    catch { $loadErrors += ('{0}: {1}' -f $moduleName, $_.Exception.Message) }
}

if (-not (Get-Command -Name Start-AstApplication -ErrorAction SilentlyContinue)) {
    [void][System.Windows.Forms.MessageBox]::Show(
        ("The program could not load.`n`n" + ($loadErrors -join "`n")),
        'AYMEN SYSTEM TOOLS', 'OK', 'Error')
    exit 1
}
Start-AstApplication -Root $Root -LoadErrors $loadErrors
