# ============================================================
# Tasks.ps1 - long-running tasks with live console output, admin checks, async page loading
# ASCII-only file.
#
#   Start-AstTask      : runs external commands step by step (-Steps) or a PowerShell script (-Script)
#                        in a background runspace and streams the output into a console (New-AstConsole).
#   Connect-AstTask    : re-attach a running/finished task to a console after the page was rebuilt.
#   Stop-AstTask       : cancel (kills the child process).
#   Start-AstLoadAsync : show a loading spinner, run a script in the background, then render the page.
# ============================================================

$script:Tasks     = @{}
$script:TaskTimer = $null

# Background script that runs external programs one after another and streams their output.
# Step = @{ Title; Exe; Args; Encoding ('unicode' for sfc.exe); Progress ($true when the tool prints %) }
$script:StepRunnerScript = {
    param($Shared, $Steps)
    $oem = $null
    try { $oem = [System.Text.Encoding]::GetEncoding([System.Globalization.CultureInfo]::CurrentCulture.TextInfo.OEMCodePage) }
    catch { $oem = [System.Text.Encoding]::Default }
    $Shared['ExitCode'] = 0
    try {
        foreach ($step in $Steps) {
            if ($Shared['Stop']) { break }
            if ($step.Title) {
                [void]$Shared['Lines'].Add('')
                [void]$Shared['Lines'].Add('=== ' + [string]$step.Title + ' ===')
                $Shared['Status'] = [string]$step.Title
            }
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = [string]$step.Exe
            $psi.Arguments = [string]$step.Args
            $psi.UseShellExecute = $false
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError = $true
            $psi.CreateNoWindow = $true
            $enc = $oem
            if ($step.Encoding -eq 'unicode') { $enc = [System.Text.Encoding]::Unicode }
            $psi.StandardOutputEncoding = $enc
            $psi.StandardErrorEncoding = $enc

            $proc = $null
            try { $proc = [System.Diagnostics.Process]::Start($psi) }
            catch {
                [void]$Shared['Lines'].Add('ERROR: ' + $_.Exception.Message)
                $Shared['ExitCode'] = -1
                continue
            }
            $Shared['Pid'] = $proc.Id
            $sb = New-Object System.Text.StringBuilder
            $reader = $proc.StandardOutput
            while ($true) {
                $c = $reader.Read()
                if ($c -lt 0) { break }
                $ch = [char]$c
                if ($ch -eq "`r" -or $ch -eq "`n") {
                    if ($sb.Length -gt 0) {
                        $line = $sb.ToString().Trim()
                        [void]$sb.Clear()
                        if ($line.Length -gt 0) {
                            if ($step.Progress -and $line -match '(\d{1,3}(?:[.,]\d+)?)\s*%') {
                                $Shared['Percent'] = [double](($Matches[1]) -replace ',', '.')
                            }
                            else { [void]$Shared['Lines'].Add($line) }
                        }
                    }
                }
                else { [void]$sb.Append($ch) }
            }
            if ($sb.Length -gt 0) {
                $tail = $sb.ToString().Trim()
                if ($tail.Length -gt 0 -and -not ($step.Progress -and $tail -match '%')) { [void]$Shared['Lines'].Add($tail) }
            }
            $proc.WaitForExit()
            $errText = ''
            try { $errText = $proc.StandardError.ReadToEnd() } catch { }
            foreach ($l in ($errText -split "`r?`n")) { if ($l.Trim().Length -gt 0) { [void]$Shared['Lines'].Add($l.Trim()) } }
            if ($proc.ExitCode -ne 0) { $Shared['ExitCode'] = $proc.ExitCode }
            $Shared['Pid'] = 0
        }
    }
    catch { [void]$Shared['Lines'].Add('ERROR: ' + $_.Exception.Message); $Shared['ExitCode'] = -1 }
    finally { $Shared['Done'] = $true }
}

# Wrapper for custom PowerShell scripts: they get ($Shared, args...) and write lines to $Shared['Lines'].
$script:ScriptRunnerWrapper = {
    param($Shared, $UserScript, $UserArgs)
    $Shared['ExitCode'] = 0
    try {
        $sb = [scriptblock]::Create([string]$UserScript)
        & $sb $Shared @UserArgs
    }
    catch { [void]$Shared['Lines'].Add('ERROR: ' + $_.Exception.Message); $Shared['ExitCode'] = -1 }
    finally { $Shared['Done'] = $true }
}

function Assert-AstAdmin {
    if (Test-AstAdmin) { return $true }
    $answer = Show-AstMessage (T 'admin_needed_text') (T 'admin_needed_title') 'YesNo' 'Warning'
    if ($answer -eq 'Yes') {
        if (Restart-AstAsAdmin) { $script:Form.Close() }
        else { [void](Show-AstMessage (T 'admin_failed') (T 'error_title') 'OK' 'Warning') }
    }
    return $false
}

function Set-AstTaskUIState {
    param($Task, [bool]$Running)
    $c = $Task.Console
    if ($c -and -not $c.Panel.IsDisposed) {
        $c.Spinner.Visible = $Running
        $c.Cancel.Enabled = $Running
    }
    foreach ($ctl in @($Task.Lock)) {
        if ($ctl -and -not $ctl.IsDisposed) { $ctl.Enabled = (-not $Running) }
    }
}

function Start-AstTask {
    param(
        [Parameter(Mandatory)][string]$Key,
        [Parameter(Mandatory)]$Console,
        [object[]]$Steps = $null,
        [scriptblock]$Script = $null,
        [object[]]$ScriptArgs = @(),
        $Lock = @(),
        [string]$OnDone = ''
    )
    if ($script:Tasks.ContainsKey($Key) -and -not $script:Tasks[$Key].Done) {
        [void](Show-AstMessage (T 'task_already_running') (T 'app_title') 'OK' 'Information')
        return
    }
    $lines = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
    $shared = [hashtable]::Synchronized(@{
        Stop = $false; Done = $false; Percent = -1.0; Status = ''; Pid = 0; ExitCode = 0; Lines = $lines
    })

    $task = @{
        Key = $Key; Shared = $shared; Worker = $null; Read = 0; Done = $false; Cancelled = $false
        Buffer = (New-Object System.Text.StringBuilder); Console = $Console; Lock = @($Lock)
        OnDone = $OnDone; Started = (Get-Date)
    }
    $script:Tasks[$Key] = $task

    $Console.Box.Clear()
    $Console.Status.Text = T 'task_running'
    Set-AstProgress $Console.Progress 0
    Set-AstSlider $Console.Progress $true
    $task.Busy = $true
    Set-AstTaskUIState $task $true

    if ($Steps) {
        $task.Worker = Start-AstWorker -ScriptBlock $script:StepRunnerScript -Shared $shared -ArgumentList @(, $Steps)
    }
    else {
        $task.Worker = Start-AstWorker -ScriptBlock $script:ScriptRunnerWrapper -Shared $shared -ArgumentList @($Script.ToString(), $ScriptArgs)
    }
    Write-AstLog 'INFO' ("Task started: " + $Key)

    if (-not $script:TaskTimer) {
        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 250
        $timer.Add_Tick({ Update-AstTasks })
        $script:TaskTimer = $timer
    }
    $script:TaskTimer.Start()
}

function Connect-AstTask {
    param([string]$Key, $Console, $Lock = @())
    if (-not $script:Tasks.ContainsKey($Key)) { return }
    $task = $script:Tasks[$Key]
    $task.Console = $Console
    $task.Lock = @($Lock)
    $Console.Box.Clear()
    Add-AstConsoleLines $Console.Box @(($task.Buffer.ToString() -split "`r?`n") | Where-Object { $_.Length -gt 0 })
    if ($task.Done) { Set-AstTaskUIState $task $false; $Console.Status.Text = [string]$task.FinalText }
    else {
        $Console.Status.Text = T 'task_running'
        Set-AstTaskUIState $task $true
        if ($task.Busy) { Set-AstSlider $Console.Progress $true }
    }
}

function Complete-AstTask {
    param($Task)
    $Task.Done = $true
    $code = [int]$Task.Shared['ExitCode']
    if ($Task.Cancelled) { $text = T 'task_cancelled' }
    elseif ($code -eq 0) { $text = T 'task_done' }
    else { $text = (T 'task_failed') -f $code }
    $Task.FinalText = $text
    Stop-AstWorker $Task.Worker
    Set-AstTaskUIState $Task $false
    $c = $Task.Console
    if ($c -and -not $c.Panel.IsDisposed) {
        Set-AstSlider $c.Progress $false
        $c.Status.Text = $text
        if ($code -eq 0 -and -not $Task.Cancelled) { Set-AstProgress $c.Progress 100 }
        $tail = $text
        if ($code -eq 0 -and -not $Task.Cancelled) { $tail = '[ OK ] ' + $text } elseif ($Task.Cancelled) { $tail = '[WARN] ' + $text } else { $tail = '[FAIL] ' + $text }
        Add-AstConsoleLines $c.Box @('', $tail)
        [void]$Task.Buffer.AppendLine('')
        [void]$Task.Buffer.AppendLine($tail)
    }
    $Task.Busy = $false
    Write-AstLog 'INFO' ("Task finished: {0} (exit {1}, cancelled {2})" -f $Task.Key, $code, $Task.Cancelled)
    if ($Task.OnDone) {
        try { & $Task.OnDone $Task }
        catch { Write-AstLog 'ERROR' ('Task completion handler failed: ' + $_.Exception.Message) }
    }
}

function Update-AstTasks {
    $active = 0
    foreach ($key in @($script:Tasks.Keys)) {
        $task = $script:Tasks[$key]
        if ($task.Done) { continue }
        $active++
        $sh = $task.Shared
        $done = [bool]$sh['Done']          # read BEFORE draining so no line is lost

        $lines = $sh['Lines']
        $count = $lines.Count
        if ($count -gt $task.Read) {
            $newLines = New-Object System.Collections.ArrayList
            for ($i = $task.Read; $i -lt $count; $i++) { [void]$newLines.Add([string]$lines[$i]) }
            $task.Read = $count
            foreach ($l in $newLines) { [void]$task.Buffer.AppendLine($l) }
            $c = $task.Console
            if ($c -and -not $c.Box.IsDisposed) { Add-AstConsoleLines $c.Box @($newLines) }
        }
        $c = $task.Console
        if ($c -and -not $c.Panel.IsDisposed) {
            $pct = [double]$sh['Percent']
            if ($pct -ge 0) {
                if ($task.Busy) { Set-AstSlider $c.Progress $false; $task.Busy = $false }
                Set-AstProgress $c.Progress $pct
            }
            $st = [string]$sh['Status']
            if ($st) {
                if ($pct -ge 0) { $c.Status.Text = ('{0}  -  {1:N0}%' -f $st, $pct) } else { $c.Status.Text = $st }
            }
        }
        if ($done) { Complete-AstTask $task; $active-- }
    }
    if ($active -le 0 -and $script:TaskTimer) { $script:TaskTimer.Stop() }
}

function Stop-AstTask {
    param([string]$Key)
    if (-not $script:Tasks.ContainsKey($Key)) { return }
    $task = $script:Tasks[$Key]
    if ($task.Done) { return }
    $task.Cancelled = $true
    $task.Shared['Stop'] = $true
    $procId = [int]$task.Shared['Pid']
    if ($procId -gt 0) { try { Stop-Process -Id $procId -Force -ErrorAction Stop } catch { } }
    Write-AstLog 'INFO' ('Task cancel requested: ' + $Key)
}

function Stop-AllAstTasks {
    foreach ($key in @($script:Tasks.Keys)) {
        $task = $script:Tasks[$key]
        if (-not $task.Done) { Stop-AstTask $key }
    }
}

# ---------- Async page loading ----------
function Complete-AstLoadAsync {
    param($Result, $ErrorText, $State)
    if (-not $State -or $State.Container.IsDisposed -or $State.View.IsDisposed) { return }
    $State.Container.Controls.Remove($State.View)
    $State.View.Dispose()

    $data = $null
    if ($Result -and @($Result).Count -gt 0) { $data = @($Result)[0] }
    if ($null -eq $data) {
        Write-AstLog 'ERROR' ('Async page load failed: ' + $ErrorText)
        $State.Container.Controls.Add((New-AstLabel (T 'error_load_page') -Size 11 -Width 600))
        return
    }
    try { & $State.Render $State.Container $data }
    catch {
        Write-AstLog 'ERROR' ("Render '{0}' failed: {1}" -f $State.Render, $_.Exception.ToString())
        $State.Container.Controls.Add((New-AstLabel (T 'error_load_page') -Size 11 -Width 600))
    }
}

function Start-AstLoadAsync {
    param($Container, [scriptblock]$Script, [string]$Render, [string]$Text, [object[]]$ArgumentList = @())
    $view = New-AstLoadingView $Text
    $Container.Controls.Add($view)
    $state = @{ Container = $Container; View = $view; Render = $Render }
    Start-AstBackground -ScriptBlock $Script -ArgumentList $ArgumentList -State $state -OnComplete {
        param($res, $err, $st)
        Complete-AstLoadAsync $res $err $st
    }
}

function Invoke-AstRestartAdmin {
    $answer = Show-AstMessage (T 'admin_confirm_text') (T 'admin_confirm_title') 'YesNo' 'Question'
    if ($answer -eq 'Yes') {
        if (Restart-AstAsAdmin) { $script:Form.Close() }
        else { [void](Show-AstMessage (T 'admin_failed') (T 'error_title') 'OK' 'Warning') }
    }
}
