# ============================================================
# Page.Diagnostics.ps1 - event log errors, devices and drivers, hardware details,
#                        technical report (HTML) and battery report
# ASCII-only file. Everything is read-only.
# ============================================================

$script:DiagCtx = $null

# ---------- Background scripts ----------
$script:EventsScript = {
    param($Days)
    $start = (Get-Date).AddDays(-[int]$Days)
    foreach ($log in 'System', 'Application') {
        $events = @()
        try { $events = @(Get-WinEvent -FilterHashtable @{ LogName = $log; Level = 1, 2; StartTime = $start } -MaxEvents 120 -ErrorAction Stop) }
        catch { continue }
        foreach ($e in $events) {
            $full = [string]$e.Message
            $first = ($full -split "`r?`n")[0]
            if ($first.Length -gt 200) { $first = $first.Substring(0, 200) }
            $level = 'Error'; $tone = 'warn'
            if ($e.Level -eq 1) { $level = 'Critical'; $tone = 'bad' }
            [pscustomobject]@{
                Time = $e.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss'); Level = $level; Source = [string]$e.ProviderName
                EventId = [int]$e.Id; Message = $first; Full = $full; Tone = $tone; Id = ($log + '|' + [string]$e.RecordId)
            }
        }
    }
}

$script:DevicesScript = {
    $rows = @()
    $n = 0
    try {
        foreach ($d in @(Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.ConfigManagerErrorCode -ne 0 })) {
            $n++
            $rows += [pscustomobject]@{
                Device = [string]$d.Name; Class = [string]$d.PNPClass; Maker = [string]$d.Manufacturer; Version = ''; Date = ''
                Status = ('Problem (code ' + [string]$d.ConfigManagerErrorCode + ')'); Tone = 'bad'; Id = ('problem|' + [string]$d.DeviceID)
            }
        }
    }
    catch { }
    try {
        foreach ($d in @(Get-CimInstance -ClassName Win32_PnPSignedDriver -ErrorAction Stop | Where-Object { $_.DeviceName })) {
            $date = ''
            try { if ($d.DriverDate) { $date = ([datetime]$d.DriverDate).ToString('yyyy-MM-dd') } } catch { }
            $rows += [pscustomobject]@{
                Device = [string]$d.DeviceName; Class = [string]$d.DeviceClass; Maker = [string]$d.Manufacturer
                Version = [string]$d.DriverVersion; Date = $date; Status = 'OK'; Tone = 'normal'; Id = ('drv|' + [string]$d.DeviceID + '|' + [string]$d.InfName)
            }
        }
    }
    catch { }
    , $rows
}

$script:HardwareScript = {
    $hwRows = New-Object System.Collections.ArrayList
    function Add-Row { param([string]$Cat, [string]$Item, [string]$Value) [void]$hwRows.Add([pscustomobject]@{ Category = $Cat; Item = $Item; Value = $Value; Id = ($Cat + '|' + $Item + '|' + $Value) }) }
    try { $cs = Get-CimInstance Win32_ComputerSystem; Add-Row 'System' 'Manufacturer / model' (([string]$cs.Manufacturer + ' ' + [string]$cs.Model).Trim()) } catch { }
    try { $b = Get-CimInstance Win32_BIOS; Add-Row 'System' 'Serial number' ([string]$b.SerialNumber); Add-Row 'System' 'BIOS' (([string]$b.SMBIOSBIOSVersion) + '  (' + ([string]$b.ReleaseDate).Substring(0, [math]::Min(8, ([string]$b.ReleaseDate).Length)) + ')') } catch { }
    try { $bb = Get-CimInstance Win32_BaseBoard; Add-Row 'System' 'Motherboard' (([string]$bb.Manufacturer + ' ' + [string]$bb.Product).Trim()) } catch { }
    try { $os = Get-CimInstance Win32_OperatingSystem; Add-Row 'System' 'Windows' (([string]$os.Caption) + '  build ' + [string]$os.BuildNumber); Add-Row 'System' 'Installed on' ([string]([datetime]$os.InstallDate).ToString('yyyy-MM-dd')) } catch { }
    try { foreach ($c in @(Get-CimInstance Win32_Processor)) { Add-Row 'Processor' 'Model' (([string]$c.Name) -replace '\s+', ' '); Add-Row 'Processor' 'Cores / threads' (([string]$c.NumberOfCores) + ' / ' + [string]$c.NumberOfLogicalProcessors); Add-Row 'Processor' 'Max clock' (([string]$c.MaxClockSpeed) + ' MHz') } } catch { }
    try { foreach ($m in @(Get-CimInstance Win32_PhysicalMemory)) { Add-Row 'Memory' ([string]$m.DeviceLocator) (([string][math]::Round([double]$m.Capacity / 1GB, 0)) + ' GB  ' + [string]$m.Speed + ' MHz  ' + ([string]$m.Manufacturer).Trim()) } } catch { }
    try { foreach ($g in @(Get-CimInstance Win32_VideoController)) { Add-Row 'Graphics' ([string]$g.Name) ('Driver ' + [string]$g.DriverVersion) } } catch { }
    try { foreach ($d in @(Get-CimInstance Win32_DiskDrive)) { Add-Row 'Disks' ([string]$d.Model) (([string][math]::Round([double]$d.Size / 1GB, 0)) + ' GB  ' + [string]$d.InterfaceType) } } catch { }
    try { foreach ($n in @(Get-CimInstance Win32_NetworkAdapter | Where-Object { $_.PhysicalAdapter -and $_.NetEnabled })) { Add-Row 'Network' ([string]$n.Name) ([string]$n.MACAddress) } } catch { }
    try { foreach ($m in @(Get-CimInstance WmiMonitorID -Namespace root\wmi -ErrorAction Stop)) { $name = (($m.UserFriendlyName | Where-Object { $_ -ne 0 } | ForEach-Object { [char]$_ }) -join ''); if ($name) { Add-Row 'Display' $name 'Monitor' } } } catch { }
    , @($hwRows)
}

$script:BatteryScript = {
    param($Path)
    try {
        $out = & powercfg.exe /batteryreport /output $Path 2>&1 | Out-String
        if (Test-Path -LiteralPath $Path) { 'OK|' + $Path } else { 'ERR: ' + $out.Trim() }
    }
    catch { 'ERR: ' + $_.Exception.Message }
}

$script:ReportScript = {
    param($Path, $L)
    function Esc { param($s) return [System.Net.WebUtility]::HtmlEncode([string]$s) }
    $sb = New-Object System.Text.StringBuilder
    function Add-Table {
        param([string]$Title, $Rows, [string[]]$Cols)
        [void]$sb.AppendLine('<h2>' + (Esc $Title) + '</h2>')
        $rowsArr = @($Rows)
        if ($rowsArr.Count -eq 0) { [void]$sb.AppendLine('<p class="muted">-</p>'); return }
        [void]$sb.AppendLine('<table><tr>' + (($Cols | ForEach-Object { '<th>' + (Esc $_) + '</th>' }) -join '') + '</tr>')
        foreach ($r in $rowsArr) {
            $cells = foreach ($c in $Cols) { '<td>' + (Esc $r.$c) + '</td>' }
            [void]$sb.AppendLine('<tr>' + ($cells -join '') + '</tr>')
        }
        [void]$sb.AppendLine('</table>')
    }
    $cs = Get-CimInstance Win32_ComputerSystem
    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $bios = Get-CimInstance Win32_BIOS
    $sys = @(
        [pscustomobject]@{ K = $L.computer; V = [string]$env:COMPUTERNAME },
        [pscustomobject]@{ K = $L.model; V = (([string]$cs.Manufacturer + ' ' + [string]$cs.Model).Trim()) },
        [pscustomobject]@{ K = $L.serial; V = [string]$bios.SerialNumber },
        [pscustomobject]@{ K = $L.os; V = (([string]$os.Caption) + ' ' + [string]$os.OSArchitecture + ' build ' + [string]$os.BuildNumber) },
        [pscustomobject]@{ K = $L.cpu; V = (([string]$cpu.Name) -replace '\s+', ' ') },
        [pscustomobject]@{ K = $L.ram; V = (([string][math]::Round([double]$cs.TotalPhysicalMemory / 1GB, 1)) + ' GB') },
        [pscustomobject]@{ K = $L.user; V = ($env:USERDOMAIN + '\' + $env:USERNAME) },
        [pscustomobject]@{ K = $L.uptime; V = ([string][math]::Floor(((Get-Date) - $os.LastBootUpTime).TotalDays) + ' d') }
    )
    $disks = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object {
        [pscustomobject]@{ Drive = [string]$_.DeviceID; Label = [string]$_.VolumeName; Size = ([string][math]::Round([double]$_.Size / 1GB, 1) + ' GB'); Free = ([string][math]::Round([double]$_.FreeSpace / 1GB, 1) + ' GB') } })
    $net = @()
    try { $net = @(Get-NetIPConfiguration -ErrorAction Stop | ForEach-Object { [pscustomobject]@{ Adapter = [string]$_.InterfaceAlias; IPv4 = (@($_.IPv4Address | ForEach-Object { $_.IPAddress }) -join ', '); Gateway = [string](@($_.IPv4DefaultGateway)[0]).NextHop } }) } catch { }
    $procs = @(Get-Process -ErrorAction SilentlyContinue | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 | ForEach-Object {
        [pscustomobject]@{ Name = [string]$_.ProcessName; PID = [string]$_.Id; MemMB = [string][math]::Round($_.WorkingSet64 / 1MB, 1) } })
    $startup = @()
    foreach ($k in 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run') {
        try { foreach ($p in @((Get-ItemProperty -Path $k -ErrorAction Stop).PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })) { $startup += [pscustomobject]@{ Name = [string]$p.Name; Command = [string]$p.Value } } } catch { }
    }
    $programs = @()
    foreach ($k in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*') {
        foreach ($p in @(Get-ItemProperty -Path $k -ErrorAction SilentlyContinue)) {
            if ($p.DisplayName -and $p.SystemComponent -ne 1 -and -not $p.ParentKeyName) { $programs += [pscustomobject]@{ Name = [string]$p.DisplayName; Version = [string]$p.DisplayVersion; Publisher = [string]$p.Publisher } }
        }
    }
    $programs = @($programs | Sort-Object Name -Unique | Select-Object -First 300)
    $errors = @()
    try {
        $errors = @(Get-WinEvent -FilterHashtable @{ LogName = 'System', 'Application'; Level = 1, 2; StartTime = (Get-Date).AddDays(-7) } -MaxEvents 40 -ErrorAction Stop | ForEach-Object {
            $m = ([string]$_.Message -split "`r?`n")[0]; if ($m.Length -gt 160) { $m = $m.Substring(0, 160) }
            [pscustomobject]@{ Time = $_.TimeCreated.ToString('yyyy-MM-dd HH:mm'); Source = [string]$_.ProviderName; Id = [string]$_.Id; Message = $m } })
    }
    catch { }

    [void]$sb.AppendLine('<!DOCTYPE html><html dir="' + $L.dir + '"><head><meta charset="utf-8"><title>' + (Esc $L.title) + '</title>')
    [void]$sb.AppendLine('<style>body{font-family:Segoe UI,Arial,sans-serif;margin:32px;background:#f4f6fa;color:#1a2233}h1{color:#2563eb;margin-bottom:4px}h2{margin-top:28px;border-bottom:2px solid #2563eb;padding-bottom:4px}table{border-collapse:collapse;width:100%;background:#fff}th,td{border:1px solid #d5dbe5;padding:6px 10px;text-align:start;font-size:13px}th{background:#e8eefc}.muted{color:#667}</style></head><body>')
    [void]$sb.AppendLine('<h1>' + (Esc $L.title) + '</h1><p class="muted">' + (Esc (Get-Date -Format 'yyyy-MM-dd HH:mm')) + '</p>')
    Add-Table $L.sec_system $sys @('K', 'V')
    Add-Table $L.sec_disks $disks @('Drive', 'Label', 'Size', 'Free')
    Add-Table $L.sec_network $net @('Adapter', 'IPv4', 'Gateway')
    Add-Table $L.sec_startup $startup @('Name', 'Command')
    Add-Table $L.sec_procs $procs @('Name', 'PID', 'MemMB')
    Add-Table $L.sec_errors $errors @('Time', 'Source', 'Id', 'Message')
    Add-Table ($L.sec_programs + ' (' + $programs.Count + ')') $programs @('Name', 'Version', 'Publisher')
    [void]$sb.AppendLine('</body></html>')
    [System.IO.File]::WriteAllText($Path, $sb.ToString(), (New-Object System.Text.UTF8Encoding($true)))
    'OK|' + $Path
}

# ---------- Page with tabs ----------
function Build-AstPage-diagnostics {
    param($Container)
    $ctx = @{}
    $script:DiagCtx = $ctx
    $content = [System.Windows.Forms.Panel]::new()
    $content.Dock = 'Fill'
    $content.Padding = [System.Windows.Forms.Padding]::new(0, (Sz 6), 0, 0)
    $ctx.Content = $content
    $tabs = @(
        @{ Key = 'events';   Title = 'tab_events';   Icon = 'warning' },
        @{ Key = 'devices';  Title = 'tab_devices';  Icon = 'devices' },
        @{ Key = 'hardware'; Title = 'tab_hardware'; Icon = 'info' },
        @{ Key = 'report';   Title = 'tab_report';   Icon = 'page' }
    )
    $bar = New-AstTabBar $tabs 'Show-AstDiagTab'
    $Container.Controls.Add($content)
    $Container.Controls.Add($bar)
    Select-AstTab $bar 'events' 'Show-AstDiagTab'
}

function Show-AstDiagTab {
    param([string]$Key)
    $ctx = $script:DiagCtx
    if (-not $ctx) { return }
    $content = $ctx.Content
    $content.SuspendLayout()
    foreach ($c in @($content.Controls)) { $content.Controls.Remove($c); $c.Dispose() }
    try {
        switch ($Key) {
            'events'   { Build-AstEventsTab $content }
            'devices'  { Build-AstDevicesTab $content }
            'hardware' { Build-AstHardwareTab $content }
            'report'   { Build-AstReportTab $content }
        }
    }
    catch { Write-AstLog 'ERROR' ("Diagnostics tab '{0}' failed: {1}" -f $Key, $_.Exception.ToString()) }
    $content.ResumeLayout($true)
}

function New-AstDiagSection {
    param([string]$TitleKey, [string]$Icon, [string]$Color)
    $sec = New-AstSection (T $TitleKey) $Icon 100 $Color -Spinner
    $sec.Panel.Dock = 'Fill'
    return $sec
}

function Complete-AstDiagLoad {
    param($Result, $ErrorText, $St)
    if (-not $St -or $St.List.IsDisposed) { return }
    $St.Spinner.Visible = $false
    $rows = @()
    if ($St.Wrapped) { if ($Result -and @($Result).Count -gt 0) { $rows = @(@($Result)[0]) } }
    else { $rows = @(@($Result) | Where-Object { $_ -and $_.Id }) }
    Set-AstDataList $St.List @($rows | Where-Object { $_ -and $_.Id })
    if ($ErrorText) { Write-AstLog 'WARN' ('Diagnostics load problem: ' + $ErrorText) }
}

# ---- Events ----
function Build-AstEventsTab {
    param($Content)
    $sec = New-AstDiagSection 'sec_events' 'warning' 'Warn'
    $toolbar = New-AstToolbar
    $count = New-AstLabel '' -Muted
    $count.Margin = [System.Windows.Forms.Padding]::new((Sz 6), (Sz 14), 0, 0)
    $cols = @(
        @{ Header = 'col_time'; Width = 160; Prop = 'Time' }, @{ Header = 'col_level'; Width = 80; Prop = 'Level' },
        @{ Header = 'col_source'; Width = 200; Prop = 'Source' }, @{ Header = 'col_eventid'; Width = 70; Prop = 'EventId' },
        @{ Header = 'col_message'; Width = 620; Prop = 'Message' })
    $list = New-AstDataList -Columns $cols -KeyProp 'Id' -CountKey 'count_items' -CountLabel $count
    $list.Tag.SortAsc = $false
    $detail = [System.Windows.Forms.TextBox]::new()
    $detail.Dock = 'Bottom'
    $detail.Height = Sz 96
    $detail.Multiline = $true
    $detail.ReadOnly = $true
    $detail.ScrollBars = 'Vertical'
    $detail.BorderStyle = 'None'
    $detail.BackColor = $script:Theme.Surface
    $detail.ForeColor = $script:Theme.TextMuted
    $detail.Font = Get-AstFont 'Segoe UI' 9.5 'Regular'
    $detail.Text = T 'events_hint'
    $list.Tag.Detail = $detail
    $list.Add_SelectedIndexChanged({
        param($s, $e)
        $row = Get-AstDataSelected $s
        if ($row -and $s.Tag.Detail -and -not $s.Tag.Detail.IsDisposed) { $s.Tag.Detail.Text = [string]$row.Full }
    })
    $days = New-AstCombo -Items @((T 'days_1'), (T 'days_7'), (T 'days_30')) -Index 1 -Width 150
    $days.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 6), (Sz 8), 0)
    $state = @{ List = $list; Spinner = $sec.Spinner; Days = $days; Wrapped = $false }
    $script:DiagCtx.Events = $state
    $bRef = New-AstButton (T 'refresh') -Icon 'refresh' -OnClick { Start-AstEventsLoad }
    $bOpen = New-AstButton (T 'events_open') -Icon 'link' -OnClick { Start-Process -FilePath 'eventvwr.msc' }
    foreach ($c in @($bRef, $days, (New-AstSearchBox $list 200), $bOpen, $count)) { $toolbar.Controls.Add($c) }
    $sec.Body.Controls.Add($list)
    $sec.Body.Controls.Add($detail)
    $sec.Body.Controls.Add($toolbar)
    $Content.Controls.Add($sec.Panel)
    Start-AstEventsLoad
}

function Start-AstEventsLoad {
    $st = $script:DiagCtx.Events
    if (-not $st -or $st.List.IsDisposed) { return }
    $dayValues = @(1, 7, 30)
    $d = $dayValues[[math]::Max(0, $st.Days.SelectedIndex)]
    $st.Spinner.Visible = $true
    Start-AstBackground -ScriptBlock $script:EventsScript -ArgumentList @($d) -State $st -OnComplete {
        param($res, $err, $s) Complete-AstDiagLoad $res $err $s
    }
}

# ---- Devices and drivers ----
function Build-AstDevicesTab {
    param($Content)
    $sec = New-AstDiagSection 'sec_devices' 'devices' 'Accent'
    $toolbar = New-AstToolbar
    $count = New-AstLabel '' -Muted
    $count.Margin = [System.Windows.Forms.Padding]::new((Sz 6), (Sz 14), 0, 0)
    $cols = @(
        @{ Header = 'col_device'; Width = 330; Prop = 'Device' }, @{ Header = 'col_class'; Width = 120; Prop = 'Class' },
        @{ Header = 'col_maker'; Width = 190; Prop = 'Maker' }, @{ Header = 'col_version'; Width = 130; Prop = 'Version' },
        @{ Header = 'col_date'; Width = 100; Prop = 'Date' }, @{ Header = 'col_status'; Width = 150; Prop = 'Status' })
    $list = New-AstDataList -Columns $cols -KeyProp 'Id' -CountKey 'count_items' -CountLabel $count
    $list.Tag.SortCol = 5
    $list.Tag.SortAsc = $false
    $state = @{ List = $list; Spinner = $sec.Spinner; Wrapped = $true }
    $script:DiagCtx.Devices = $state
    $bRef = New-AstButton (T 'refresh') -Icon 'refresh' -OnClick { Start-AstDevicesLoad }
    $bDm = New-AstButton (T 'tool_devmgmt') -Icon 'devices' -OnClick { Start-Process -FilePath 'devmgmt.msc' }
    foreach ($c in @($bRef, (New-AstSearchBox $list 200), $bDm, $count)) { $toolbar.Controls.Add($c) }
    $sec.Body.Controls.Add($list)
    $sec.Body.Controls.Add($toolbar)
    $Content.Controls.Add($sec.Panel)
    Start-AstDevicesLoad
}

function Start-AstDevicesLoad {
    $st = $script:DiagCtx.Devices
    if (-not $st -or $st.List.IsDisposed) { return }
    $st.Spinner.Visible = $true
    Start-AstBackground -ScriptBlock $script:DevicesScript -State $st -OnComplete {
        param($res, $err, $s) Complete-AstDiagLoad $res $err $s
    }
}

# ---- Hardware ----
function Build-AstHardwareTab {
    param($Content)
    $sec = New-AstDiagSection 'sec_hardware' 'info' 'Sky'
    $toolbar = New-AstToolbar
    $count = New-AstLabel '' -Muted
    $count.Margin = [System.Windows.Forms.Padding]::new((Sz 6), (Sz 14), 0, 0)
    $cols = @(
        @{ Header = 'col_category'; Width = 150; Prop = 'Category' }, @{ Header = 'col_item'; Width = 280; Prop = 'Item' },
        @{ Header = 'col_value'; Width = 640; Prop = 'Value' })
    $list = New-AstDataList -Columns $cols -KeyProp 'Id' -CountKey 'count_items' -CountLabel $count
    $state = @{ List = $list; Spinner = $sec.Spinner; Wrapped = $true }
    $script:DiagCtx.Hardware = $state
    $bRef = New-AstButton (T 'refresh') -Icon 'refresh' -OnClick { Start-AstHardwareLoad }
    $bCopy = New-AstButton (T 'console_copy') -Icon 'copy' -OnClick { Copy-AstHardware } -Tip (T 'hardware_copy_tip')
    $bInfo = New-AstButton (T 'tool_msinfo') -Icon 'info' -OnClick { Start-Process -FilePath 'msinfo32.exe' }
    foreach ($c in @($bRef, $bCopy, $bInfo, (New-AstSearchBox $list 180), $count)) { $toolbar.Controls.Add($c) }
    $sec.Body.Controls.Add($list)
    $sec.Body.Controls.Add($toolbar)
    $Content.Controls.Add($sec.Panel)
    Start-AstHardwareLoad
}

function Start-AstHardwareLoad {
    $st = $script:DiagCtx.Hardware
    if (-not $st -or $st.List.IsDisposed) { return }
    $st.Spinner.Visible = $true
    Start-AstBackground -ScriptBlock $script:HardwareScript -State $st -OnComplete {
        param($res, $err, $s) Complete-AstDiagLoad $res $err $s
    }
}

function Copy-AstHardware {
    $st = $script:DiagCtx.Hardware
    $rows = @($st.List.Tag.Data)
    if ($rows.Count -eq 0) { return }
    $text = ($rows | ForEach-Object { '{0} | {1} | {2}' -f $_.Category, $_.Item, $_.Value }) -join "`r`n"
    try { [System.Windows.Forms.Clipboard]::SetText($text) } catch { }
}

# ---- Report and battery ----
function Build-AstReportTab {
    param($Content)
    $sec = New-AstSection (T 'sec_report') 'page' 100 'Purple' -Spinner
    $sec.Panel.Dock = 'Fill'
    $flow = New-AstFlow
    $hint = New-AstLabel (T 'report_hint') -Muted -Width 900
    $flow.Controls.Add($hint)
    $flow.SetFlowBreak($hint, $true)
    $status = New-AstLabel '' -Muted -Width 900
    $state = @{ Spinner = $sec.Spinner; Status = $status; Buttons = (New-Object System.Collections.ArrayList) }
    $script:DiagCtx.Report = $state
    $b1 = New-AstButton (T 'report_make') -Icon 'page' -Style primary -OnClick { Start-AstReport } -Tip (T 'report_make_tip')
    $b2 = New-AstButton (T 'report_battery') -Icon 'power' -OnClick { Start-AstBattery } -Tip (T 'report_battery_tip')
    $b3 = New-AstButton (T 'open_reports') -Icon 'folder' -OnClick { Open-AstFolder 'Reports' }
    foreach ($b in @($b1, $b2, $b3)) { $flow.Controls.Add($b) }
    [void]$state.Buttons.Add($b1); [void]$state.Buttons.Add($b2)
    $flow.SetFlowBreak($b3, $true)
    $flow.Controls.Add($status)
    $sec.Body.Controls.Add($flow)
    $sec.Spinner.Visible = $false
    $Content.Controls.Add($sec.Panel)
}

function Start-AstReportJob {
    param([scriptblock]$Script, [object[]]$Args2, [string]$StatusKey)
    $st = $script:DiagCtx.Report
    foreach ($b in @($st.Buttons)) { $b.Enabled = $false }
    $st.Spinner.Visible = $true
    $st.Status.Text = T $StatusKey
    Start-AstBackground -ScriptBlock $Script -ArgumentList $Args2 -State $st -OnComplete {
        param($res, $err, $s) Complete-AstReportJob $res $err $s
    }
}

function Complete-AstReportJob {
    param($Result, $ErrorText, $St)
    if (-not $St -or $St.Status.IsDisposed) { return }
    foreach ($b in @($St.Buttons)) { if (-not $b.IsDisposed) { $b.Enabled = $true } }
    $St.Spinner.Visible = $false
    $msg = [string](@($Result)[0])
    if ($ErrorText -and -not $msg) { $msg = 'ERR: ' + $ErrorText }
    if ($msg -like 'OK|*') {
        $file = $msg.Substring(3)
        $St.Status.Text = (T 'report_done') -f $file
        Write-AstLog 'INFO' ('Report created: ' + $file)
        try { Start-Process -FilePath $file } catch { }
    }
    else {
        $St.Status.Text = (T 'report_failed') -f ($msg -replace '^ERR:\s*', '')
        Write-AstLog 'WARN' ('Report failed: ' + $msg)
    }
}

function Start-AstReport {
    $file = Join-Path $script:Paths['Reports'] ('report_{0}.html' -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $dir = 'ltr'
    if ($script:IsRtl) { $dir = 'rtl' }
    $labels = @{
        dir = $dir; title = (T 'report_title'); sec_system = (T 'report_sec_system'); sec_disks = (T 'report_sec_disks')
        sec_network = (T 'report_sec_network'); sec_startup = (T 'report_sec_startup'); sec_procs = (T 'report_sec_procs')
        sec_errors = (T 'report_sec_errors'); sec_programs = (T 'report_sec_programs')
        computer = (T 'card_computer'); model = (T 'report_model'); serial = (T 'report_serial'); os = (T 'card_os')
        cpu = (T 'card_cpu'); ram = (T 'card_ram'); user = (T 'card_user'); uptime = (T 'card_uptime')
    }
    Start-AstReportJob $script:ReportScript @($file, $labels) 'report_working'
}

function Start-AstBattery {
    $file = Join-Path $script:Paths['Reports'] ('battery_{0}.html' -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    Start-AstReportJob $script:BatteryScript @($file) 'report_working'
}
