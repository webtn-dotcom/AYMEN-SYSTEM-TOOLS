# ============================================================
# Performance.ps1 - live CPU / RAM / disk graphs + process manager
# ASCII-only file.
#   - A background worker samples CPU, RAM and disk activity about once per second.
#   - A UI timer (1 s) reads the shared data and redraws the graphs.
#   - Every 3 s a one-shot background job snapshots the process list.
#   - The process list is a VIRTUAL ListView: only visible rows are created, so refreshes never
#     freeze the window even with hundreds of processes.
#   - Leaving the page / changing language or theme / closing the app releases everything
#     through $script:PageCleanup.
# ============================================================

$script:Perf = $null

# Processes that must never be ended from this tool
$script:ProtectedProcesses = @(
    'Idle', 'System', 'Registry', 'Memory Compression', 'smss', 'csrss', 'wininit',
    'winlogon', 'services', 'lsass', 'lsm', 'svchost', 'dwm', 'fontdrvhost', 'MsMpEng'
)

# ---------- Background scripts (own runspace) ----------
$script:SamplerScript = {
    param($Shared)
    $totalGB = 0.0
    try { $totalGB = [double](Get-CimInstance -ClassName Win32_ComputerSystem).TotalPhysicalMemory / 1GB } catch { }

    while (-not $Shared['Stop']) {
        try {
            $cpu = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'"
            $os  = Get-CimInstance -ClassName Win32_OperatingSystem
            $dsk = Get-CimInstance -ClassName Win32_PerfFormattedData_PerfDisk_PhysicalDisk -Filter "Name='_Total'"

            $freeGB = [double]$os.FreePhysicalMemory * 1KB / 1GB
            $usedGB = [math]::Max(0.0, $totalGB - $freeGB)
            $ramPct = 0.0
            if ($totalGB -gt 0) { $ramPct = $usedGB / $totalGB * 100.0 }
            $cpuVal = 0.0
            if ($cpu) { $cpuVal = [double]$cpu.PercentProcessorTime }
            $dskVal = 0.0
            if ($dsk) { $dskVal = [double]$dsk.PercentDiskTime }

            $Shared['Cpu']        = [math]::Min(100.0, $cpuVal)
            $Shared['Disk']       = [math]::Min(100.0, $dskVal)
            $Shared['RamPercent'] = $ramPct
            $Shared['RamUsedGB']  = [math]::Round($usedGB, 1)
            $Shared['RamTotalGB'] = [math]::Round($totalGB, 1)
            $Shared['Stamp']      = [DateTime]::UtcNow.Ticks
        }
        catch { $Shared['Error'] = $_.Exception.Message }
        for ($i = 0; $i -lt 8 -and -not $Shared['Stop']; $i++) { Start-Sleep -Milliseconds 100 }
    }
}

$script:ProcessSnapshotScript = {
    param($PrevCpu, $PrevTicks, $Cores)
    $nowTicks = [DateTime]::UtcNow.Ticks
    $elapsed = 0.0
    if ($PrevTicks) { $elapsed = ($nowTicks - [int64]$PrevTicks) / 10000000.0 }
    if (-not $Cores -or $Cores -lt 1) { $Cores = 1 }

    $rows = New-Object System.Collections.Generic.List[object]
    $cpuNow = @{}
    foreach ($proc in (Get-Process -ErrorAction SilentlyContinue)) {
        $cpuSec = 0.0
        try { $cpuSec = [double]$proc.TotalProcessorTime.TotalSeconds } catch { }
        $cpuNow[$proc.Id] = $cpuSec
        $pct = 0.0
        if ($PrevCpu -and $elapsed -gt 0 -and $PrevCpu.ContainsKey($proc.Id)) {
            $pct = ($cpuSec - [double]$PrevCpu[$proc.Id]) / $elapsed / $Cores * 100.0
            if ($pct -lt 0) { $pct = 0.0 }
        }
        $rows.Add([pscustomobject]@{
            Id    = [int]$proc.Id
            Name  = [string]$proc.ProcessName
            MemMB = [math]::Round($proc.WorkingSet64 / 1MB, 1)
            Cpu   = [math]::Round($pct, 1)
        })
    }
    [pscustomobject]@{ Rows = $rows.ToArray(); CpuNow = $cpuNow; Ticks = $nowTicks }
}

# ---------- Graph cards ----------
function Invoke-AstGraphPaint {
    param($Sender, $E)
    $info = $Sender.Tag
    if (-not $info) { return }
    $t = $script:Theme
    $g = $E.Graphics
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $w = [single]$Sender.ClientSize.Width
    $h = [single]$Sender.ClientSize.Height
    if ($w -lt 10 -or $h -lt 10) { return }

    $gridPen = New-Object System.Drawing.Pen($t.Border)
    foreach ($f in 0.25, 0.5, 0.75) {
        $y = [single]($h * (1 - $f))
        $g.DrawLine($gridPen, [single]0, $y, $w, $y)
    }
    $gridPen.Dispose()

    $hist = $info.Hist
    $n = $hist.Count
    if ($n -lt 2) { return }
    $step = $w / 59
    # newest sample on the reading-start side of the end: right in LTR, left in RTL
    $points = New-Object 'System.Collections.Generic.List[System.Drawing.PointF]'
    for ($i = 0; $i -lt $n; $i++) {
        $v = [math]::Max(0.0, [math]::Min(100.0, [double]$hist[$i]))
        $offset = ($n - 1 - $i) * $step
        if ($script:IsRtl) { $x = [single]$offset } else { $x = [single]($w - $offset) }
        $y = [single]($h - ($v / 100.0 * ($h - 2)) - 1)
        $points.Add([System.Drawing.PointF]::new($x, $y))
    }
    $poly = New-Object 'System.Collections.Generic.List[System.Drawing.PointF]'
    $poly.AddRange($points)
    $poly.Add([System.Drawing.PointF]::new($points[$n - 1].X, $h))
    $poly.Add([System.Drawing.PointF]::new($points[0].X, $h))

    $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(50, $info.Color))
    $g.FillPolygon($brush, $poly.ToArray())
    $brush.Dispose()
    $pen = New-Object System.Drawing.Pen($info.Color, [single]2)
    $g.DrawLines($pen, $points.ToArray())
    $pen.Dispose()
}

function New-AstGraphCard {
    param([string]$Title, [string]$Icon, [string]$ColorName)
    $t = $script:Theme
    $color = $t[$ColorName]

    $card = [System.Windows.Forms.Panel]::new()
    $card.BackColor = $t.Surface
    Set-AstDoubleBuffered $card
    $card.Add_Resize({ param($s, $e) Set-AstRegion $s (Sz 8) })

    $iconLbl = New-AstIcon $Icon 12 $color
    $iconLbl.Dock = Get-AstStart
    $iconLbl.Width = Sz 40

    $titleLabel = [System.Windows.Forms.Label]::new()
    $titleLabel.Dock = 'Fill'
    $titleLabel.Text = $Title
    $titleLabel.ForeColor = $t.TextMuted
    $titleLabel.Font = Get-AstFont 'Segoe UI' 9.5 'Regular'
    $titleLabel.TextAlign = 'MiddleLeft'
    $titleLabel.AutoEllipsis = $true

    $titleRow = [System.Windows.Forms.Panel]::new()
    $titleRow.Dock = 'Top'
    $titleRow.Height = Sz 30
    $titleRow.Controls.Add($titleLabel)
    $titleRow.Controls.Add($iconLbl)

    $valueLabel = [System.Windows.Forms.Label]::new()
    $valueLabel.Dock = 'Top'
    $valueLabel.Height = Sz 36
    $valueLabel.Text = '-'
    $valueLabel.ForeColor = $t.Text
    $valueLabel.Font = Get-AstFont 'Segoe UI Semibold' 15 'Regular'
    $valueLabel.TextAlign = 'MiddleLeft'
    $valueLabel.Padding = New-AstPad 14 0 8 0
    $valueLabel.AutoEllipsis = $true

    $hist = New-Object 'System.Collections.Generic.List[double]'
    $graph = [System.Windows.Forms.Panel]::new()
    $graph.Dock = 'Fill'
    $graph.Tag = @{ Hist = $hist; Color = $color }
    Set-AstDoubleBuffered $graph
    $graph.Add_Paint({ param($s, $e) Invoke-AstGraphPaint $s $e })

    # Fill first, then the top rows (the last added control is docked first = topmost)
    $card.Controls.Add($graph)
    $card.Controls.Add($valueLabel)
    $card.Controls.Add($titleRow)
    return @{ Card = $card; Panel = $graph; Value = $valueLabel; Hist = $hist }
}

function Add-AstGraphSample {
    param($Graph, [double]$Value, [string]$Text)
    $Graph.Hist.Add($Value)
    while ($Graph.Hist.Count -gt 60) { $Graph.Hist.RemoveAt(0) }
    $Graph.Value.Text = $Text
    $Graph.Value.ForeColor = Get-AstBarColor -Percent ([int]$Value)
    $Graph.Panel.Invalidate()
}

# ---------- Live sampling ----------
function Update-AstPerformance {
    $p = $script:Perf
    if (-not $p) { return }
    $s = $p.Shared

    if ($s.ContainsKey('Stamp') -and $s['Stamp'] -ne $p.LastStamp) {
        $p.LastStamp = $s['Stamp']
        $cpu  = [double]$s['Cpu']
        $disk = [double]$s['Disk']
        $ram  = [double]$s['RamPercent']
        $ramText = ((T 'perf_ram_value') -f $s['RamUsedGB'], $s['RamTotalGB']) + '  (' + [int][math]::Round($ram) + '%)'
        Add-AstGraphSample $p.Graphs.Cpu  $cpu  ('{0:N0}%' -f $cpu)
        Add-AstGraphSample $p.Graphs.Ram  $ram  $ramText
        Add-AstGraphSample $p.Graphs.Disk $disk ('{0:N0}%' -f $disk)
    }

    $p.Tick = $p.Tick + 1
    if ($p.Auto.Checked -and ($p.Tick % 3 -eq 0)) { Request-AstProcessRefresh }
}

function Stop-AstPerformance {
    $p = $script:Perf
    if (-not $p) { return }
    $script:Perf = $null    # late completions of background jobs see $null and do nothing
    try { if ($p.Timer) { $p.Timer.Stop(); $p.Timer.Dispose() } } catch { }
    Stop-AstWorker $p.Worker
    Write-AstLog 'INFO' 'Performance monitoring stopped.'
}

# ---------- Process list (virtual) ----------
function Request-AstProcessRefresh {
    $p = $script:Perf
    if (-not $p -or $p.Busy) { return }
    $p.Busy = $true
    Start-AstBackground -ScriptBlock $script:ProcessSnapshotScript `
        -ArgumentList @($p.PrevCpu, $p.PrevTicks, $p.Cores) `
        -OnComplete { param($res, $err, $st) Complete-AstProcessRefresh $res $err }
}

function Complete-AstProcessRefresh {
    param($Result, $ErrorText)
    $p = $script:Perf
    if (-not $p) { return }
    $p.Busy = $false
    if ($ErrorText) { Write-AstLog 'WARN' ('Process refresh problem: ' + $ErrorText) }
    $r = $null
    if ($Result -and @($Result).Count -gt 0) { $r = @($Result)[0] }
    if (-not $r) { return }
    $p.ProcData  = @($r.Rows)
    $p.PrevCpu   = $r.CpuNow
    $p.PrevTicks = $r.Ticks
    Update-AstProcessList
}

function Update-AstProcessList {
    $p = $script:Perf
    if (-not $p) { return }
    $lv = $p.List
    $props = @('Name', 'Id', 'Cpu', 'MemMB')

    $rows = @($p.ProcData)
    $filter = $p.Search.Text.Trim()
    if ($filter.Length -gt 0) {
        $rows = @($rows | Where-Object {
            ($_.Name.IndexOf($filter, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) -or (([string]$_.Id) -eq $filter)
        })
    }
    $rows = @($rows | Sort-Object -Property $props[$p.SortCol] -Descending:(-not $p.SortAsc))

    # Remember the selected process (by PID) and the scroll position
    $selPid = $null
    if ($lv.SelectedIndices.Count -gt 0) {
        $idx = $lv.SelectedIndices[0]
        if ($idx -lt $p.View.Count) { $selPid = [int]$p.View[$idx].Id }
    }
    $topIndex = 0
    try { if ($lv.TopItem) { $topIndex = $lv.TopItem.Index } } catch { }

    $p.View = $rows
    $lv.BeginUpdate()
    try {
        $lv.VirtualListSize = $rows.Count
        if ($null -ne $selPid) {
            for ($i = 0; $i -lt $rows.Count; $i++) {
                if ($rows[$i].Id -eq $selPid) { $lv.SelectedIndices.Add($i); break }
            }
        }
        if ($topIndex -gt 0 -and $topIndex -lt $rows.Count) { try { $lv.TopItem = $lv.Items[$topIndex] } catch { } }
    }
    finally { $lv.EndUpdate() }
    $lv.Invalidate()

    $arrow = [string][char]0x25BC
    if ($p.SortAsc) { $arrow = [string][char]0x25B2 }
    for ($i = 0; $i -lt $p.ColKeys.Count; $i++) {
        $caption = T $p.ColKeys[$i]
        if ($i -eq $p.SortCol) { $caption = $caption + ' ' + $arrow }
        $lv.Columns[$i].Text = $caption
    }
    $p.Count.Text = (T 'proc_count') -f $rows.Count
}

function Get-AstProcessRow {
    param($E)
    $p = $script:Perf
    $item = $null
    if ($p -and $E.ItemIndex -lt $p.View.Count) {
        $r = $p.View[$E.ItemIndex]
        $item = [System.Windows.Forms.ListViewItem]::new([string]$r.Name)
        [void]$item.SubItems.Add([string]$r.Id)
        [void]$item.SubItems.Add(('{0:N1}' -f $r.Cpu))
        [void]$item.SubItems.Add(('{0:N1}' -f $r.MemMB))
    }
    else { $item = [System.Windows.Forms.ListViewItem]::new('') }
    $E.Item = $item
}

function Set-AstProcessSort {
    param([int]$Column)
    $p = $script:Perf
    if (-not $p) { return }
    if ($p.SortCol -eq $Column) { $p.SortAsc = -not $p.SortAsc }
    else { $p.SortCol = $Column; $p.SortAsc = ($Column -le 1) }
    Update-AstProcessList
}

function Stop-AstSelectedProcess {
    $p = $script:Perf
    if (-not $p) { return }
    $lv = $p.List
    if ($lv.SelectedIndices.Count -eq 0 -or $lv.SelectedIndices[0] -ge $p.View.Count) {
        [void](Show-AstMessage (T 'proc_select_first') (T 'proc_end') 'OK' 'Information')
        return
    }
    $row = $p.View[$lv.SelectedIndices[0]]
    $procId = [int]$row.Id
    $name = [string]$row.Name

    $isProtected = ($script:ProtectedProcesses -contains $name) -or ($procId -le 4) -or ($procId -eq $PID)
    if ($isProtected) {
        Write-AstLog 'WARN' ("Blocked attempt to end protected process {0} (PID {1})" -f $name, $procId)
        [void](Show-AstMessage ((T 'proc_protected') -f $name, $procId) (T 'proc_confirm_title') 'OK' 'Warning')
        return
    }
    $answer = Show-AstMessage ((T 'proc_confirm') -f $name, $procId) (T 'proc_confirm_title') 'YesNo' 'Warning'
    if ($answer -ne 'Yes') { return }
    try {
        Stop-Process -Id $procId -Force -ErrorAction Stop
        Write-AstLog 'INFO' ("Process ended by user: {0} (PID {1})" -f $name, $procId)
        Request-AstProcessRefresh
    }
    catch {
        Write-AstLog 'ERROR' ("Could not end {0} (PID {1}): {2}" -f $name, $procId, $_.Exception.Message)
        [void](Show-AstMessage ((T 'proc_failed') -f $_.Exception.Message) (T 'error_title') 'OK' 'Error')
    }
}

# ---------- Page ----------
function Build-AstPage-performance {
    param($Container)
    Stop-AstPerformance
    $t = $script:Theme

    $shared = [hashtable]::Synchronized(@{ Stop = $false })
    $p = @{
        Shared = $shared; Worker = $null; Timer = $null; Tick = 0; LastStamp = $null; Busy = $false
        ProcData = @(); View = @(); PrevCpu = @{}; PrevTicks = [DateTime]::UtcNow.Ticks
        Cores = [Environment]::ProcessorCount; SortCol = 3; SortAsc = $false
        ColKeys = @('proc_col_name', 'proc_col_pid', 'proc_col_cpu', 'proc_col_mem'); Graphs = @{}
    }

    # Graph row (three cards, equal width, same behaviour in LTR and RTL)
    $cpuCard  = New-AstGraphCard (T 'perf_cpu')  'pulse' 'Accent'
    $ramCard  = New-AstGraphCard (T 'perf_ram')  'devices' 'Good'
    $diskCard = New-AstGraphCard (T 'perf_disk') 'drive' 'Warn'
    $p.Graphs.Cpu = $cpuCard; $p.Graphs.Ram = $ramCard; $p.Graphs.Disk = $diskCard

    $row = [System.Windows.Forms.TableLayoutPanel]::new()
    $row.Dock = 'Top'
    $row.Height = Sz 190
    $row.ColumnCount = 3
    $row.RowCount = 1
    for ($i = 0; $i -lt 3; $i++) {
        [void]$row.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 33.33)))
    }
    [void]$row.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    foreach ($c in @($cpuCard, $ramCard, $diskCard)) {
        $c.Card.Dock = 'Fill'
        $c.Card.Margin = [System.Windows.Forms.Padding]::new((Sz 6))
    }
    $row.Controls.Add($cpuCard.Card, 0, 0)
    $row.Controls.Add($ramCard.Card, 1, 0)
    $row.Controls.Add($diskCard.Card, 2, 0)

    # Process toolbar
    $bar = New-AstToolbar

    $lblSearch = New-AstLabel (T 'proc_search') -Muted
    $lblSearch.Margin = [System.Windows.Forms.Padding]::new((Sz 8), (Sz 14), (Sz 6), 0)
    $txtSearch = New-AstTextBox -Width 210
    $txtSearch.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 11), (Sz 14), 0)
    Set-AstTip $txtSearch (T 'proc_search_tip')
    $chkAuto = New-AstCheck (T 'proc_auto') $true
    $chkAuto.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 13), (Sz 14), 0)
    $btnRefresh = New-AstButton (T 'proc_refresh') -Icon 'refresh' -OnClick { Request-AstProcessRefresh }
    $btnRefresh.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 8), (Sz 8), 0)
    $btnEnd = New-AstButton (T 'proc_end') -Icon 'cancel' -Style danger -OnClick { Stop-AstSelectedProcess } -Tip (T 'proc_end_tip')
    $btnEnd.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 8), (Sz 14), 0)
    $lblCount = New-AstLabel '' -Muted
    $lblCount.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 14), 0, 0)
    foreach ($c in @($lblSearch, $txtSearch, $chkAuto, $btnRefresh, $btnEnd, $lblCount)) { $bar.Controls.Add($c) }

    # Virtual list
    $lv = [System.Windows.Forms.ListView]::new()
    $lv.Dock = 'Fill'
    $lv.View = 'Details'
    $lv.VirtualMode = $true
    $lv.FullRowSelect = $true
    $lv.MultiSelect = $false
    $lv.HideSelection = $false
    $lv.BorderStyle = 'None'
    $lv.BackColor = $t.Surface
    $lv.ForeColor = $t.Text
    $lv.Font = Get-AstFont 'Segoe UI' 9.5 'Regular'
    Set-AstDoubleBuffered $lv
    [void]$lv.Columns.Add((T 'proc_col_name'), (Sz 300))
    [void]$lv.Columns.Add((T 'proc_col_pid'), (Sz 90))
    [void]$lv.Columns.Add((T 'proc_col_cpu'), (Sz 100))
    [void]$lv.Columns.Add((T 'proc_col_mem'), (Sz 130))
    $lv.Add_RetrieveVirtualItem({ param($s, $e) Get-AstProcessRow $e })
    $lv.Add_ColumnClick({ param($s, $e) Set-AstProcessSort $e.Column })
    $txtSearch.Add_TextChanged({ Update-AstProcessList })

    $procPanel = [System.Windows.Forms.Panel]::new()
    $procPanel.Dock = 'Fill'
    $procPanel.Controls.Add($lv)
    $procPanel.Controls.Add($bar)

    $spacer = [System.Windows.Forms.Panel]::new()
    $spacer.Dock = 'Top'
    $spacer.Height = Sz 10

    # Docking runs from the last added to the first: graphs on top, spacer, then the process area
    $Container.Controls.Add($procPanel)
    $Container.Controls.Add($spacer)
    $Container.Controls.Add($row)

    $p.List = $lv; $p.Search = $txtSearch; $p.Auto = $chkAuto; $p.Count = $lblCount

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 1000
    $timer.Add_Tick({ Update-AstPerformance })
    $p.Timer = $timer

    $script:Perf = $p
    $script:PageCleanup = { Stop-AstPerformance }

    $p.Worker = Start-AstWorker -ScriptBlock $script:SamplerScript -Shared $shared
    $timer.Start()
    Write-AstLog 'INFO' 'Performance monitoring started.'
    Request-AstProcessRefresh
}
