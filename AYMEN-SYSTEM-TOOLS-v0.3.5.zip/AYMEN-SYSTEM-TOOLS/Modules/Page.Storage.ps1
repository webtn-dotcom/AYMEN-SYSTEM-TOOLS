# ============================================================
# Page.Storage.ps1 - drives overview, physical disk health, folder size analysis, largest files
# ASCII-only file. Read-only: nothing is deleted here (use Maintenance for cleaning).
# ============================================================

$script:StorageCtx = $null

$script:StorageScript = {
    $disks = @()
    foreach ($d in @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3')) {
        if (-not $d.Size) { continue }
        $size = [double]$d.Size
        $free = [double]$d.FreeSpace
        $disks += [pscustomobject]@{
            Name = [string]$d.DeviceID; Label = [string]$d.VolumeName; FileSystem = [string]$d.FileSystem
            SizeGB = [math]::Round($size / 1GB, 1); FreeGB = [math]::Round($free / 1GB, 1)
            UsedPercent = [int][math]::Round(($size - $free) / $size * 100)
        }
    }
    $phys = @()
    try {
        foreach ($p in @(Get-PhysicalDisk -ErrorAction Stop)) {
            $tone = 'good'
            if ([string]$p.HealthStatus -ne 'Healthy') { $tone = 'bad' }
            $phys += [pscustomobject]@{
                Name = [string]$p.FriendlyName; Type = [string]$p.MediaType; Health = [string]$p.HealthStatus
                Status = (@($p.OperationalStatus) -join ', '); SizeGB = [math]::Round([double]$p.Size / 1GB, 0)
                Id = [string]$p.FriendlyName; Tone = $tone
            }
        }
    }
    catch { }
    [pscustomobject]@{ Disks = $disks; Physical = $phys }
}

# Shared helper text for the two folder scanners (they run in their own runspace)
$script:FolderSizesScript = {
    param($Shared, $Root)
    function Format-Size {
        param([double]$B)
        if ($B -ge 1GB) { return ('{0:N2} GB' -f ($B / 1GB)) }
        if ($B -ge 1MB) { return ('{0:N1} MB' -f ($B / 1MB)) }
        if ($B -ge 1KB) { return ('{0:N0} KB' -f ($B / 1KB)) }
        return ('{0:N0} B' -f $B)
    }
    function Get-TreeBytes {
        param([string]$Path)
        $total = 0.0
        $stack = New-Object System.Collections.Generic.Stack[string]
        $stack.Push($Path)
        while ($stack.Count -gt 0) {
            if ($Shared['Stop']) { break }
            $dir = $stack.Pop()
            try { foreach ($f in [System.IO.Directory]::EnumerateFiles($dir)) { try { $total += [System.IO.FileInfo]::new($f).Length } catch { } } } catch { }
            try {
                foreach ($d in [System.IO.Directory]::EnumerateDirectories($dir)) {
                    $skip = $false
                    try { if (([System.IO.File]::GetAttributes($d) -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { $skip = $true } } catch { $skip = $true }
                    if (-not $skip) { $stack.Push($d) }
                }
            }
            catch { }
        }
        return $total
    }
    $children = @()
    try { $children = @([System.IO.Directory]::EnumerateDirectories($Root)) }
    catch { [void]$Shared['Lines'].Add('ERROR: ' + $_.Exception.Message); $Shared['ExitCode'] = 1; return }
    $results = New-Object System.Collections.Generic.List[object]
    $n = 0
    foreach ($c in $children) {
        if ($Shared['Stop']) { break }
        $Shared['Status'] = [string]$c
        $Shared['Percent'] = [double]($n / [math]::Max(1, $children.Count) * 100)
        $n++
        $results.Add([pscustomobject]@{ Path = $c; Bytes = (Get-TreeBytes $c) })
    }
    $loose = 0.0
    try { foreach ($f in [System.IO.Directory]::EnumerateFiles($Root)) { try { $loose += [System.IO.FileInfo]::new($f).Length } catch { } } } catch { }
    if ($loose -gt 0) { $results.Add([pscustomobject]@{ Path = ($Root + '  (files)'); Bytes = $loose }) }
    $sum = 0.0
    foreach ($r in $results) { $sum += $r.Bytes }
    foreach ($r in ($results | Sort-Object Bytes -Descending | Select-Object -First 60)) {
        $pct = 0
        if ($sum -gt 0) { $pct = [int][math]::Round($r.Bytes / $sum * 100) }
        $bar = ('#' * [math]::Min(20, [int][math]::Round($pct / 5)))
        [void]$Shared['Lines'].Add(('{0,12}  {1,3}%  {2,-20}  {3}' -f (Format-Size $r.Bytes), $pct, $bar, $r.Path))
    }
    [void]$Shared['Lines'].Add('')
    [void]$Shared['Lines'].Add('Total: ' + (Format-Size $sum))
    $Shared['Percent'] = 100.0
}

$script:LargestFilesScript = {
    param($Shared, $Root)
    function Format-Size {
        param([double]$B)
        if ($B -ge 1GB) { return ('{0:N2} GB' -f ($B / 1GB)) }
        if ($B -ge 1MB) { return ('{0:N1} MB' -f ($B / 1MB)) }
        if ($B -ge 1KB) { return ('{0:N0} KB' -f ($B / 1KB)) }
        return ('{0:N0} B' -f $B)
    }
    $limit = 50
    $top = New-Object System.Collections.Generic.List[object]
    $stack = New-Object System.Collections.Generic.Stack[string]
    $stack.Push($Root)
    $dirs = 0
    while ($stack.Count -gt 0) {
        if ($Shared['Stop']) { break }
        $dir = $stack.Pop()
        $dirs++
        if ($dirs % 25 -eq 0) { $Shared['Status'] = [string]$dir }
        try {
            foreach ($f in [System.IO.Directory]::EnumerateFiles($dir)) {
                try {
                    $len = [System.IO.FileInfo]::new($f).Length
                    if ($top.Count -lt $limit -or $len -gt $top[$top.Count - 1].Len) {
                        $top.Add([pscustomobject]@{ Len = $len; Path = $f })
                        $sorted = @($top | Sort-Object Len -Descending | Select-Object -First $limit)
                        $top.Clear()
                        foreach ($x in $sorted) { $top.Add($x) }
                    }
                }
                catch { }
            }
        }
        catch { }
        try {
            foreach ($d in [System.IO.Directory]::EnumerateDirectories($dir)) {
                $skip = $false
                try { if (([System.IO.File]::GetAttributes($d) -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { $skip = $true } } catch { $skip = $true }
                if (-not $skip) { $stack.Push($d) }
            }
        }
        catch { }
    }
    foreach ($r in $top) { [void]$Shared['Lines'].Add(('{0,12}  {1}' -f (Format-Size $r.Len), $r.Path)) }
    $Shared['Percent'] = 100.0
}

function Get-AstStoragePath {
    $ctx = $script:StorageCtx
    if (-not $ctx) { return $null }
    $path = $ctx.Path.Text.Trim().Trim('"')
    if (-not $path -or -not (Test-Path -LiteralPath $path -PathType Container)) {
        [void](Show-AstMessage (T 'storage_path_invalid') (T 'sec_folders') 'OK' 'Warning')
        return $null
    }
    $isRoot = ($path.TrimEnd('\') -match '^[A-Za-z]:$')
    if ($isRoot -and ((Show-AstMessage (T 'storage_root_confirm') (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes')) { return $null }
    return $path
}

function Start-AstFolderSizes {
    $path = Get-AstStoragePath
    $ctx = $script:StorageCtx
    if ($path) { Start-AstTask -Key 'storage' -Console $ctx.Console -Script $script:FolderSizesScript -ScriptArgs @($path) -Lock $ctx.Lock }
}
function Start-AstLargestFiles {
    $path = Get-AstStoragePath
    $ctx = $script:StorageCtx
    if ($path) { Start-AstTask -Key 'storage' -Console $ctx.Console -Script $script:LargestFilesScript -ScriptArgs @($path) -Lock $ctx.Lock }
}
function Select-AstStorageFolder {
    $ctx = $script:StorageCtx
    $dlg = [System.Windows.Forms.FolderBrowserDialog]::new()
    try {
        $dlg.Description = T 'storage_browse'
        if (Test-Path -LiteralPath $ctx.Path.Text) { $dlg.SelectedPath = $ctx.Path.Text }
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { $ctx.Path.Text = $dlg.SelectedPath }
    }
    finally { $dlg.Dispose() }
}

function Build-AstPage-storage {
    param($Container)
    Start-AstLoadAsync -Container $Container -Script $script:StorageScript -Render 'Show-AstStorage' -Text (T 'loading_storage')
}

function Show-AstStorage {
    param($Container, $Data)
    $stack = New-AstPage $Container 'desc_storage'
    $lock = New-Object System.Collections.ArrayList
    $ctx = @{ Lock = $lock }
    $script:StorageCtx = $ctx

    # --- Drives ---
    Add-AstRow $stack (New-AstTextBlock (T 'sec_drives') -Semi -Size 12) 4
    $grid = New-AstGrid -TileWidth 300 -TileHeight 110
    foreach ($d in @($Data.Disks)) {
        $title = (T 'card_disk') -f $d.Name
        if ($d.Label) { $title = $title + '  (' + $d.Label + ')' }
        $value = ((T 'disk_free') -f $d.FreeGB, $d.SizeGB) + "`n" + $d.FileSystem + '  -  ' + ((T 'used_percent') -f $d.UsedPercent)
        $grid.Controls.Add((New-AstStatCard $title $value $d.UsedPercent 'Teal'))
    }
    Add-AstRow $stack $grid

    # --- Physical disk health ---
    $phys = @($Data.Physical)
    $secP = New-AstSection (T 'sec_health_disks') 'drive' 150 'Teal'
    $count = New-AstLabel '' -Muted
    if ($phys.Count -eq 0) {
        $secP.Body.Controls.Add((New-AstLabel (T 'storage_no_health') -Muted -Width 800))
    }
    else {
        $cols = @(
            @{ Header = 'col_name'; Width = 330; Prop = 'Name' }, @{ Header = 'col_type'; Width = 110; Prop = 'Type' },
            @{ Header = 'col_health'; Width = 120; Prop = 'Health' }, @{ Header = 'col_status'; Width = 160; Prop = 'Status' },
            @{ Header = 'col_sizegb'; Width = 110; Prop = 'SizeGB' })
        $pl = New-AstDataList -Columns $cols -KeyProp 'Id'
        Set-AstDataList $pl $phys
        $secP.Body.Controls.Add($pl)
    }
    Add-AstRow $stack $secP.Panel

    # --- Folder analysis ---
    $secF = New-AstSection (T 'sec_folders') 'folder' 74 'Accent'
    $flow = New-AstFlow
    $lblP = New-AstLabel (T 'storage_folder') -Muted
    $lblP.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 14), (Sz 8), 0)
    $txt = New-AstTextBox -Width 380
    $txt.Text = $env:USERPROFILE
    $txt.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 9), (Sz 8), 0)
    $ctx.Path = $txt
    $bBrowse = New-AstButton (T 'storage_browse_btn') -Icon 'folder' -OnClick { Select-AstStorageFolder }
    $bSizes = New-AstButton (T 'storage_sizes') -Icon 'search' -Style primary -OnClick { Start-AstFolderSizes } -Tip (T 'storage_sizes_tip')
    $bBig = New-AstButton (T 'storage_big') -Icon 'filter' -OnClick { Start-AstLargestFiles } -Tip (T 'storage_big_tip')
    $bOpen = New-AstButton (T 'storage_open') -Icon 'link' -OnClick {
        $p = $script:StorageCtx.Path.Text.Trim().Trim('"')
        if ($p -and (Test-Path -LiteralPath $p)) { Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $p) }
    }
    $bSet = New-AstButton (T 'storage_settings') -Icon 'settings' -OnClick { Start-Process -FilePath 'ms-settings:storagesense' }
    foreach ($c in @($lblP, $txt, $bBrowse, $bSizes, $bBig, $bOpen, $bSet)) { $flow.Controls.Add($c) }
    $flow.SetFlowBreak($bBrowse, $true)
    foreach ($b in @($bBrowse, $bSizes, $bBig)) { [void]$lock.Add($b) }
    $secF.Body.Controls.Add($flow)
    Set-AstSectionAuto $secF $flow
    Add-AstRow $stack $secF.Panel

    $secO = New-AstSection (T 'sec_output') 'cmd' 290 'Sky'
    $console = New-AstConsole -Key 'storage'
    $console.Panel.Dock = 'Fill'
    $secO.Body.Controls.Add($console.Panel)
    Add-AstRow $stack $secO.Panel
    $ctx.Console = $console
    Connect-AstTask 'storage' $console $lock
}
