# ============================================================
# Page.Dashboard.ps1 - smart dashboard: health score, recommendations, quick actions, overview
# ASCII-only file.
# ============================================================

function Get-AstHealth {
    param($S)
    $score = 100
    $items = New-Object System.Collections.ArrayList

    if ($S.SystemDisk) {
        $free = [int]$S.SystemDisk.FreePercent
        if ($free -lt 10) { $score -= 25; [void]$items.Add(@{ Level = 'bad'; Text = ((T 'rec_disk_low') -f $S.SystemDisk.Name, $free); Page = 'maintenance'; Btn = 'rec_btn_clean' }) }
        elseif ($free -lt 20) { $score -= 10; [void]$items.Add(@{ Level = 'warn'; Text = ((T 'rec_disk_low') -f $S.SystemDisk.Name, $free); Page = 'maintenance'; Btn = 'rec_btn_clean' }) }
    }
    if ($S.RamPercent -ge 90) { $score -= 15; [void]$items.Add(@{ Level = 'bad'; Text = ((T 'rec_ram_high') -f $S.RamPercent); Page = 'performance'; Btn = 'rec_btn_open' }) }
    elseif ($S.RamPercent -ge 80) { $score -= 8; [void]$items.Add(@{ Level = 'warn'; Text = ((T 'rec_ram_high') -f $S.RamPercent); Page = 'performance'; Btn = 'rec_btn_open' }) }

    $days = [int][math]::Floor($S.Uptime.TotalDays)
    if ($days -ge 14) { $score -= 8; [void]$items.Add(@{ Level = 'bad'; Text = ((T 'rec_uptime') -f $days); Page = ''; Btn = '' }) }
    elseif ($days -ge 7) { $score -= 4; [void]$items.Add(@{ Level = 'warn'; Text = ((T 'rec_uptime') -f $days); Page = ''; Btn = '' }) }

    if ($S.PendingReboot) { $score -= 8; [void]$items.Add(@{ Level = 'warn'; Text = (T 'rec_reboot'); Page = ''; Btn = '' }) }
    if ($S.Defender -eq 'off') { $score -= 20; [void]$items.Add(@{ Level = 'bad'; Text = (T 'rec_defender_off'); Page = 'security'; Btn = 'rec_btn_open' }) }
    if ($S.Firewall -eq 'off') { $score -= 15; [void]$items.Add(@{ Level = 'bad'; Text = (T 'rec_firewall_off'); Page = 'security'; Btn = 'rec_btn_open' }) }
    if ($S.StartupCount -gt 15) { $score -= 6; [void]$items.Add(@{ Level = 'warn'; Text = ((T 'rec_startup') -f $S.StartupCount); Page = 'startup'; Btn = 'rec_btn_open' }) }
    if (-not $S.IsAdmin) { [void]$items.Add(@{ Level = 'info'; Text = (T 'rec_admin'); Page = '@admin'; Btn = 'rec_btn_admin' }) }

    return @{ Score = [math]::Max(0, $score); Items = $items }
}

function Invoke-AstRecAction {
    param($Sender, $E)
    $page = [string]$Sender.Tag
    if ($page -eq '@admin') {
        $a = Show-AstMessage (T 'admin_confirm_text') (T 'admin_confirm_title') 'YesNo' 'Question'
        if ($a -eq 'Yes') {
            if (Restart-AstAsAdmin) { $script:Form.Close() }
            else { [void](Show-AstMessage (T 'admin_failed') (T 'error_title') 'OK' 'Warning') }
        }
    }
    elseif ($page) { Show-AstPage $page }
}

function New-AstRecRow {
    param($Rec)
    $t = $script:Theme
    $row = [System.Windows.Forms.Panel]::new()
    $row.Dock = 'Top'
    $row.Height = Sz 46

    switch ($Rec.Level) {
        'bad'  { $iconName = 'warning'; $color = $t.Bad }
        'warn' { $iconName = 'warning'; $color = $t.Warn }
        default { $iconName = 'info'; $color = $t.Sky }
    }
    $icon = New-AstIcon $iconName 13 $color
    $icon.Dock = Get-AstStart
    $icon.Width = Sz 40

    $text = [System.Windows.Forms.Label]::new()
    $text.Dock = 'Fill'
    $text.Text = [string]$Rec.Text
    $text.Font = Get-AstFont 'Segoe UI' 10 'Regular'
    $text.ForeColor = $t.Text
    $text.TextAlign = 'MiddleLeft'

    $row.Controls.Add($text)
    $row.Controls.Add($icon)
    $show = ($Rec.Page -eq '@admin') -or ($Rec.Page -and (Test-AstPageAvailable $Rec.Page))
    if ($show) {
        $btn = New-AstButton (T $Rec.Btn) -Style secondary
        $btn.Height = Sz 32
        $btn.Dock = Get-AstEnd
        $btn.Margin = [System.Windows.Forms.Padding]::new(0)
        $btn.Tag = [string]$Rec.Page
        $btn.Add_Click({ param($s, $e) Invoke-AstRecAction $s $e })
        $row.Controls.Add($btn)
    }
    return $row
}

function Add-AstTiles {
    param($Grid, $Tiles)
    foreach ($tile in $Tiles) {
        if ($tile.Action.Kind -eq 'page' -and -not (Test-AstPageAvailable $tile.Action.Target)) { continue }
        $Grid.Controls.Add((New-AstTile $tile.Icon (T $tile.Title) (T $tile.Desc) $tile.Color $tile.Action))
    }
}

function Build-AstPage-dashboard {
    param($Container)
    Start-AstLoadAsync -Container $Container -Script $script:SummaryScript -Render 'Show-AstDashboard' -Text (T 'loading_system')
}

function Show-AstDashboard {
    param($Container, $S)
    $t = $script:Theme
    $stack = New-AstPage $Container 'desc_dashboard'
    $health = Get-AstHealth $S
    $score = [int]$health.Score
    if ($score -ge 80) { $c1 = $t.Accent; $c2 = $t.Teal; $scoreTitle = T 'health_good' }
    elseif ($score -ge 60) { $c1 = $t.Warn; $c2 = $t.Pink; $scoreTitle = T 'health_fair' }
    else { $c1 = $t.Bad; $c2 = $t.Purple; $scoreTitle = T 'health_poor' }
    $issueCount = @($health.Items | Where-Object { $_.Level -ne 'info' }).Count

    # --- Hero banner: gradient + score gauge (painted by New-AstHero) ---
    $hero = New-AstHero $score $c1 $c2 150
    Set-AstTip $hero (T 'health_tip')

    $textHost = [System.Windows.Forms.Panel]::new()
    $textHost.Dock = 'Fill'
    $textHost.BackColor = [System.Drawing.Color]::Transparent
    $textHost.Padding = New-AstPad 176 26 16 12

    $msgSub = [System.Windows.Forms.Label]::new()
    $msgSub.Dock = 'Fill'
    $msgSub.BackColor = [System.Drawing.Color]::Transparent
    $msgSub.Font = Get-AstFont 'Segoe UI' 11 'Regular'
    $msgSub.ForeColor = [System.Drawing.Color]::White
    $msgSub.TextAlign = 'TopLeft'
    if ($issueCount -eq 0) { $msgSub.Text = T 'health_no_issues' } else { $msgSub.Text = (T 'health_issues') -f $issueCount }
    $msgTitle = [System.Windows.Forms.Label]::new()
    $msgTitle.Dock = 'Top'
    $msgTitle.Height = Sz 48
    $msgTitle.BackColor = [System.Drawing.Color]::Transparent
    $msgTitle.Font = Get-AstFont 'Segoe UI Semibold' 22 'Regular'
    $msgTitle.ForeColor = [System.Drawing.Color]::White
    $msgTitle.TextAlign = 'BottomLeft'
    $msgTitle.Text = $scoreTitle
    $textHost.Controls.Add($msgSub)
    $textHost.Controls.Add($msgTitle)

    $refreshHost = [System.Windows.Forms.Panel]::new()
    $refreshHost.Dock = Get-AstEnd
    $refreshHost.Width = Sz 170
    $refreshHost.BackColor = [System.Drawing.Color]::Transparent
    $refreshHost.Padding = [System.Windows.Forms.Padding]::new(0, (Sz 54), (Sz 20), 0)
    $btnRefresh = New-AstButton (T 'refresh') -Icon 'refresh' -Width 140 -OnClick {
        $script:Form.BeginInvoke([System.Action]{ Show-AstPage 'dashboard' }) | Out-Null
    }
    $btnRefresh.Dock = 'Top'
    $btnRefresh.Margin = [System.Windows.Forms.Padding]::new(0)
    $refreshHost.Controls.Add($btnRefresh)

    $hero.Controls.Add($textHost)
    $hero.Controls.Add($refreshHost)
    Add-AstRow $stack $hero

    # --- Recommendations ---
    $recs = @($health.Items)
    $count = [math]::Max(1, $recs.Count)
    $secRec = New-AstSection (T 'sec_recs') 'info' ($count * 46 + 6) 'Warn'
    if ($recs.Count -eq 0) {
        $ok = @{ Level = 'ok'; Text = (T 'rec_all_good'); Page = ''; Btn = '' }
        $okRow = New-AstRecRow $ok
        $okRow.Controls[1].Text = [string][char]0xE73E
        $okRow.Controls[1].ForeColor = $t.Good
        $secRec.Body.Controls.Add($okRow)
    }
    else {
        for ($i = $recs.Count - 1; $i -ge 0; $i--) { $secRec.Body.Controls.Add((New-AstRecRow $recs[$i])) }
    }
    Add-AstRow $stack $secRec.Panel

    # --- Quick actions ---
    Add-AstRow $stack (New-AstTextBlock (T 'sec_quick') -Semi -Size 12) 4
    $grid = New-AstGrid -TileWidth 300 -TileHeight 108
    $tiles = @(
        @{ Icon = 'trash';    Color = 'Good';   Title = 'tile_clean';   Desc = 'tile_clean_d';   Action = @{ Kind = 'page'; Target = 'maintenance' } },
        @{ Icon = 'sync';     Color = 'Teal';   Title = 'tile_repair';  Desc = 'tile_repair_d';  Action = @{ Kind = 'page'; Target = 'maintenance' } },
        @{ Icon = 'globe';    Color = 'Sky';    Title = 'tile_network'; Desc = 'tile_network_d'; Action = @{ Kind = 'page'; Target = 'network' } },
        @{ Icon = 'pulse';    Color = 'Pink';   Title = 'tile_perf';    Desc = 'tile_perf_d';    Action = @{ Kind = 'page'; Target = 'performance' } },
        @{ Icon = 'restore';  Color = 'Purple'; Title = 'tile_restore'; Desc = 'tile_restore_d'; Action = @{ Kind = 'page'; Target = 'restore' } },
        @{ Icon = 'apps';     Color = 'Accent'; Title = 'tile_tools';   Desc = 'tile_tools_d';   Action = @{ Kind = 'page'; Target = 'tools' } },
        @{ Icon = 'download'; Color = 'Warn';   Title = 'tile_update';  Desc = 'tile_update_d';  Action = @{ Kind = 'launch'; Target = 'ms-settings:windowsupdate' } },
        @{ Icon = 'lock';     Color = 'Bad';    Title = 'tile_secure';  Desc = 'tile_secure_d';  Action = @{ Kind = 'page'; Target = 'security' } }
    )
    Add-AstTiles $grid $tiles
    Add-AstRow $stack $grid

    # --- System overview ---
    Add-AstRow $stack (New-AstTextBlock (T 'sec_overview') -Semi -Size 12) 4
    $cards = New-AstGrid -TileWidth 250 -TileHeight 108
    $adminText = if ($S.IsAdmin) { T 'badge_admin' } else { T 'badge_user' }
    $cards.Controls.Add((New-AstStatCard (T 'card_computer') ($S.ComputerName + "`n" + $S.Model) -1 'Accent'))
    $cards.Controls.Add((New-AstStatCard (T 'card_user') ($S.UserName + "`n" + $adminText) -1 'Purple'))
    $cards.Controls.Add((New-AstStatCard (T 'card_os') ($S.OsName + ' ' + $S.OsArch + "`n" + ((T 'build_label') -f $S.OsBuild)) -1 'Sky'))
    $cards.Controls.Add((New-AstStatCard (T 'card_cpu') ($S.CpuName + "`n" + ((T 'cores') -f $S.CpuThreads)) -1 'Pink'))
    $ramText = (T 'ram_value') -f $S.RamUsedGB, $S.RamTotalGB, $S.RamPercent
    $cards.Controls.Add((New-AstStatCard (T 'card_ram') $ramText $S.RamPercent 'Good'))
    $cards.Controls.Add((New-AstStatCard (T 'card_uptime') (Format-AstUptime $S.Uptime) -1 'Warn'))
    foreach ($d in @($S.Disks)) {
        $title = (T 'card_disk') -f $d.Name
        if ($d.Label) { $title = $title + '  (' + $d.Label + ')' }
        $cards.Controls.Add((New-AstStatCard $title ((T 'disk_free') -f $d.FreeGB, $d.SizeGB) $d.UsedPercent 'Teal'))
    }
    Add-AstRow $stack $cards
}
