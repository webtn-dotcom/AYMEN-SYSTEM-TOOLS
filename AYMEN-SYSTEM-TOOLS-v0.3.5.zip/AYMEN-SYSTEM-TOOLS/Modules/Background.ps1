# ============================================================
# Background.ps1 - run work outside the UI thread (separate runspaces)
# ASCII-only file.
#
#   Start-AstBackground : one-shot job. Result is delivered to -OnComplete on the UI thread.
#                         OnComplete receives ($Result, $ErrorText, $State).
#   Start-AstWorker     : long-running job sharing data through a synchronized hashtable.
#   Stop-AstWorker      : NON-BLOCKING stop (sets $Shared.Stop, cleanup happens later).
#
# Rules for scriptblocks that run in the background:
#   - they run in a NEW runspace: no $script: variables, no functions of this app, no UI controls
#   - pass everything they need through -ArgumentList
# ============================================================

$script:BgJobs      = New-Object System.Collections.ArrayList
$script:BgGraveyard = New-Object System.Collections.ArrayList
$script:BgTimer     = $null

function Update-AstBackground {
    foreach ($job in @($script:BgJobs)) {
        if (-not $job.Handle.IsCompleted) { continue }
        [void]$script:BgJobs.Remove($job)

        $result = $null
        $errorText = $null
        try {
            $result = @($job.PS.EndInvoke($job.Handle))
            if ($job.PS.HadErrors) {
                $errorText = (@($job.PS.Streams.Error) | ForEach-Object { $_.ToString() }) -join '; '
            }
        }
        catch { $errorText = $_.Exception.Message }
        finally { try { $job.PS.Dispose() } catch { } }

        if ($job.OnComplete) {
            try { & $job.OnComplete $result $errorText $job.State }
            catch { Write-AstLog 'ERROR' ('Background completion handler failed: ' + $_.Exception.Message) }
        }
    }

    # Finish stopped workers without ever blocking the UI thread
    foreach ($w in @($script:BgGraveyard)) {
        $age = ((Get-Date) - $w.Since).TotalSeconds
        if ($w.Handle.IsCompleted) {
            try { $w.PS.Dispose() } catch { }
            [void]$script:BgGraveyard.Remove($w)
        }
        elseif ($age -gt 8 -and -not $w.Stopping) {
            $w.Stopping = $true
            try { [void]$w.PS.BeginStop($null, $null) } catch { }
        }
        elseif ($age -gt 30) {
            [void]$script:BgGraveyard.Remove($w)
        }
    }

    if ($script:BgJobs.Count -eq 0 -and $script:BgGraveyard.Count -eq 0 -and $script:BgTimer) { $script:BgTimer.Stop() }
}

function Start-AstBgTimer {
    if (-not $script:BgTimer) {
        $timer = New-Object System.Windows.Forms.Timer
        $timer.Interval = 150
        $timer.Add_Tick({ Update-AstBackground })
        $script:BgTimer = $timer
    }
    $script:BgTimer.Start()
}

function Start-AstBackground {
    param(
        [Parameter(Mandatory)][scriptblock]$ScriptBlock,
        [object[]]$ArgumentList = @(),
        [scriptblock]$OnComplete,
        $State = $null
    )
    $ps = [powershell]::Create()
    [void]$ps.AddScript($ScriptBlock.ToString())
    foreach ($arg in $ArgumentList) { [void]$ps.AddArgument($arg) }

    $job = @{ PS = $ps; Handle = $ps.BeginInvoke(); OnComplete = $OnComplete; State = $State }
    [void]$script:BgJobs.Add($job)
    Start-AstBgTimer
}

function Start-AstWorker {
    param(
        [Parameter(Mandatory)][scriptblock]$ScriptBlock,
        [Parameter(Mandatory)][hashtable]$Shared,
        [object[]]$ArgumentList = @()
    )
    $ps = [powershell]::Create()
    [void]$ps.AddScript($ScriptBlock.ToString())
    [void]$ps.AddArgument($Shared)
    foreach ($arg in $ArgumentList) { [void]$ps.AddArgument($arg) }
    return @{ PS = $ps; Handle = $ps.BeginInvoke(); Shared = $Shared; Since = (Get-Date); Stopping = $false }
}

function Stop-AstWorker {
    param($Worker)
    if (-not $Worker) { return }
    try { $Worker.Shared['Stop'] = $true } catch { }
    $Worker.Since = Get-Date
    [void]$script:BgGraveyard.Add($Worker)
    Start-AstBgTimer
}
