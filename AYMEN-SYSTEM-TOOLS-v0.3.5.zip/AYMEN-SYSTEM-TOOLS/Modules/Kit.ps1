# ============================================================
# Kit.ps1 - reusable UI components (design system)
# ASCII-only file.
#
# Layout rules used everywhere:
#   - RTL (Arabic) is handled by RightToLeft=Yes on the form + Get-AstStart / Get-AstEnd / New-AstPad.
#     The form is never mirrored with RightToLeftLayout (that recreates the window).
#   - Pages are vertical "stacks" of rows (New-AstPage / Add-AstRow). Event handlers never use
#     closures: data travels in .Tag and handlers read $sender.Tag.
# ============================================================

$script:Scale     = 1.0
$script:FontCache = @{}
$script:Tip       = $null

function Sz {
    param([double]$Value)
    return [int][math]::Round($Value * $script:Scale)
}

function Get-AstFont {
    param([string]$Name = 'Segoe UI', [double]$Size = 10, [string]$Style = 'Regular')
    $key = $Name + '|' + [string]$Size + '|' + $Style
    if (-not $script:FontCache.ContainsKey($key)) {
        $script:FontCache[$key] = [System.Drawing.Font]::new($Name, [single]$Size, [System.Drawing.FontStyle]$Style)
    }
    return $script:FontCache[$key]
}

function Get-AstStart {
    if ($script:IsRtl) { return 'Right' } else { return 'Left' }
}
function Get-AstEnd {
    if ($script:IsRtl) { return 'Left' } else { return 'Right' }
}

function New-AstPad {
    param([double]$Start = 0, [double]$Top = 0, [double]$End = 0, [double]$Bottom = 0)
    if ($script:IsRtl) {
        return [System.Windows.Forms.Padding]::new((Sz $End), (Sz $Top), (Sz $Start), (Sz $Bottom))
    }
    return [System.Windows.Forms.Padding]::new((Sz $Start), (Sz $Top), (Sz $End), (Sz $Bottom))
}

function Set-AstDoubleBuffered {
    param($Control)
    try {
        $flags = [System.Reflection.BindingFlags]::Instance -bor [System.Reflection.BindingFlags]::NonPublic
        $Control.GetType().GetProperty('DoubleBuffered', $flags).SetValue($Control, $true, $null)
    }
    catch { }
}

function Show-AstMessage {
    param(
        [string]$Text,
        [string]$Title,
        [string]$Buttons = 'OK',
        [string]$Icon = 'Information'
    )
    $options = [System.Windows.Forms.MessageBoxOptions]0
    if ($script:IsRtl) {
        $options = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign
    }
    return [System.Windows.Forms.MessageBox]::Show(
        $Text, $Title,
        [System.Windows.Forms.MessageBoxButtons]$Buttons,
        [System.Windows.Forms.MessageBoxIcon]$Icon,
        [System.Windows.Forms.MessageBoxDefaultButton]::Button1,
        $options)
}

function Set-AstTip {
    param($Control, [string]$Text)
    if ($script:Tip -and $Control -and $Text) { $script:Tip.SetToolTip($Control, $Text) }
}

# ---------- Rounded corners ----------
function Set-AstRegion {
    param($C, [int]$Radius)
    if (-not $C -or $C.IsDisposed -or $C.Width -lt 6 -or $C.Height -lt 6) { return }
    $d = [math]::Max(2, $Radius * 2)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc(0, 0, $d, $d, 180, 90)
    $path.AddArc($C.Width - $d, 0, $d, $d, 270, 90)
    $path.AddArc($C.Width - $d, $C.Height - $d, $d, $d, 0, 90)
    $path.AddArc(0, $C.Height - $d, $d, $d, 90, 90)
    $path.CloseFigure()
    $old = $C.Region
    $C.Region = New-Object System.Drawing.Region($path)
    if ($old) { $old.Dispose() }
    $path.Dispose()
}

# ---------- Sliding highlight (indeterminate "scanning" effect) ----------
$script:Sliders = New-Object System.Collections.ArrayList
$script:SliderTimer = $null

function Register-AstSlider {
    param($Track, $Comet)
    for ($i = $script:Sliders.Count - 1; $i -ge 0; $i--) {
        if ($script:Sliders[$i].Track.IsDisposed) { $script:Sliders.RemoveAt($i) }
    }
    [void]$script:Sliders.Add(@{ Track = $Track; Comet = $Comet; Pos = 0; On = $false })
}

function Update-AstSliders {
    $any = $false
    foreach ($item in @($script:Sliders)) {
        if ($item.Track.IsDisposed) { [void]$script:Sliders.Remove($item); continue }
        if (-not $item.On) { continue }
        $w = $item.Track.Width
        if ($w -lt 20) { continue }
        $any = $true
        $cw = [int]($w * 0.30)
        $item.Pos = $item.Pos + [math]::Max(5, [int]($w / 45))
        if ($item.Pos -gt $w) { $item.Pos = -$cw }
        $item.Comet.SetBounds($item.Pos, 0, $cw, $item.Track.Height)
    }
    if (-not $any -and $script:SliderTimer) { $script:SliderTimer.Stop() }
}

function Set-AstSlider {
    param($Track, [bool]$On)
    foreach ($item in $script:Sliders) {
        if ([object]::ReferenceEquals($item.Track, $Track)) {
            $item.On = $On
            if ($item.Track.IsDisposed) { continue }
            if ($On) { $item.Pos = -[int]($item.Track.Width * 0.3); $item.Comet.Visible = $true }
            else { $item.Comet.Visible = $false }
        }
    }
    if ($On) {
        if (-not $script:SliderTimer) {
            $timer = New-Object System.Windows.Forms.Timer
            $timer.Interval = 35
            $timer.Add_Tick({ Update-AstSliders })
            $script:SliderTimer = $timer
        }
        $script:SliderTimer.Start()
    }
}

function Set-AstSectionAuto {
    # Makes a section grow or shrink with its wrapping button flow (no clipped buttons, any window width)
    param($Sec, $Flow)
    $Sec.Panel.Tag = @{ Kind = 'flowsection'; Flow = $Flow }
}

function Add-AstConsoleLines {
    param($Box, [string[]]$Lines)
    if (-not $Box -or $Box.IsDisposed) { return }
    $plain = [System.Drawing.ColorTranslator]::FromHtml('#D1D9E6')
    $good  = [System.Drawing.ColorTranslator]::FromHtml('#4ADE80')
    $bad   = [System.Drawing.ColorTranslator]::FromHtml('#F87171')
    $head  = [System.Drawing.ColorTranslator]::FromHtml('#60A5FA')
    $warn  = [System.Drawing.ColorTranslator]::FromHtml('#FBBF24')
    foreach ($line in $Lines) {
        $color = $plain
        if ($line -match '^\[\s*OK\s*\]') { $color = $good }
        elseif ($line -match '^\[FAIL\]' -or $line -match '^ERROR') { $color = $bad }
        elseif ($line -match '^\[WARN') { $color = $warn }
        elseif ($line.StartsWith('===')) { $color = $head }
        $Box.SelectionStart = $Box.TextLength
        $Box.SelectionLength = 0
        $Box.SelectionColor = $color
        $Box.AppendText($line + "`n")
    }
    $Box.SelectionColor = $plain
    $Box.SelectionStart = $Box.TextLength
    $Box.ScrollToCaret()
}

function New-AstAppIcon {
    try {
        $size = 64
        $bmp = New-Object System.Drawing.Bitmap($size, $size)
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit
        $r = 14
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddArc(0, 0, 2 * $r, 2 * $r, 180, 90)
        $path.AddArc($size - 2 * $r, 0, 2 * $r, 2 * $r, 270, 90)
        $path.AddArc($size - 2 * $r, $size - 2 * $r, 2 * $r, 2 * $r, 0, 90)
        $path.AddArc(0, $size - 2 * $r, 2 * $r, 2 * $r, 90, 90)
        $path.CloseFigure()
        $rect = New-Object System.Drawing.Rectangle(0, 0, $size, $size)
        $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, [System.Drawing.ColorTranslator]::FromHtml('#3B82F6'), [System.Drawing.ColorTranslator]::FromHtml('#8B5CF6'), [single]45)
        $g.FillPath($brush, $path)
        $font = New-Object System.Drawing.Font('Segoe MDL2 Assets', 30)
        $fmt = New-Object System.Drawing.StringFormat
        $fmt.Alignment = [System.Drawing.StringAlignment]::Center
        $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
        $g.DrawString([string][char]0xE713, $font, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF(0, 0, $size, $size)), $fmt)
        $g.Dispose()
        return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
    }
    catch { return $null }
}

# ---------- Basic controls ----------
function New-AstLabel {
    param(
        [string]$Text,
        [switch]$Muted,
        [switch]$Bold,
        [switch]$Semi,
        [double]$Size = 10,
        [int]$Width = 0,
        $Color = $null
    )
    $l = [System.Windows.Forms.Label]::new()
    $l.Text = $Text
    $fontName = 'Segoe UI'
    $style = 'Regular'
    if ($Semi) { $fontName = 'Segoe UI Semibold' }
    if ($Bold) { $style = 'Bold' }
    $l.Font = Get-AstFont $fontName $Size $style
    if ($Color) { $l.ForeColor = $Color }
    elseif ($Muted) { $l.ForeColor = $script:Theme.TextMuted }
    else { $l.ForeColor = $script:Theme.Text }
    $l.BackColor = [System.Drawing.Color]::Transparent
    $l.AutoSize = $true
    if ($Width -gt 0) { $l.MaximumSize = [System.Drawing.Size]::new((Sz $Width), 0) }
    $l.Margin = [System.Windows.Forms.Padding]::new(0, 0, 0, (Sz 6))
    return $l
}

function New-AstIcon {
    param([string]$Name, [double]$Size = 14, $Color = $null)
    $l = [System.Windows.Forms.Label]::new()
    $l.Font = Get-AstFont 'Segoe MDL2 Assets' $Size 'Regular'
    $l.Text = Get-AstGlyph $Name
    $l.AutoSize = $false
    $l.TextAlign = 'MiddleCenter'
    if ($Color) { $l.ForeColor = $Color } else { $l.ForeColor = $script:Theme.Accent }
    $l.BackColor = [System.Drawing.Color]::Transparent
    return $l
}

function Invoke-AstButtonPaint {
    param($Sender, $E)
    $tag = $Sender.Tag
    if (-not ($tag -is [hashtable]) -or -not $tag.Glyph) { return }
    $font = Get-AstFont 'Segoe MDL2 Assets' 11 'Regular'
    $w = Sz 34
    $x = 2
    if ($script:IsRtl) { $x = $Sender.Width - $w - 2 }
    $rect = [System.Drawing.Rectangle]::new($x, 0, $w, $Sender.Height)
    $color = $tag.Color
    if (-not $Sender.Enabled) { $color = $script:Theme.TextMuted }
    $flags = [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor [System.Windows.Forms.TextFormatFlags]::NoPadding
    [System.Windows.Forms.TextRenderer]::DrawText($E.Graphics, $tag.Glyph, $font, $rect, $color, $flags)
}

function New-AstButton {
    param(
        [string]$Text,
        [string]$Icon = '',
        [string]$Style = 'secondary',
        [int]$Width = 0,
        [scriptblock]$OnClick = $null,
        [string]$Tip = ''
    )
    $t = $script:Theme
    $b = [System.Windows.Forms.Button]::new()
    $b.Text = $Text
    $b.FlatStyle = 'Flat'
    $b.UseVisualStyleBackColor = $false
    $b.Cursor = 'Hand'
    $b.Font = Get-AstFont 'Segoe UI Semibold' 9.5 'Regular'
    $b.Height = Sz 38
    $b.Margin = [System.Windows.Forms.Padding]::new(0, 0, (Sz 8), (Sz 8))

    switch ($Style) {
        'primary' { $bg = $t.Accent;   $fg = $t.AccentText; $border = $t.Accent }
        'danger'  { $bg = $t.Bad;      $fg = [System.Drawing.Color]::White; $border = $t.Bad }
        default   { $bg = $t.Surface2; $fg = $t.Text; $border = $t.Border }
    }
    $b.BackColor = $bg
    $b.ForeColor = $fg
    $b.FlatAppearance.BorderSize = 1
    $b.FlatAppearance.BorderColor = $border
    $b.FlatAppearance.MouseOverBackColor = [System.Windows.Forms.ControlPaint]::Light($bg, 0.18)
    $b.FlatAppearance.MouseDownBackColor = [System.Windows.Forms.ControlPaint]::Dark($bg, 0.08)

    $extra = 0
    if ($Icon) {
        $extra = 34
        $b.Padding = New-AstPad 30 0 0 0
        $b.Tag = @{ Glyph = (Get-AstGlyph $Icon); Color = $fg }
        $b.Add_Paint({ param($s, $e) Invoke-AstButtonPaint $s $e })
    }
    if ($Width -gt 0) { $b.Width = Sz $Width }
    else {
        $textWidth = [System.Windows.Forms.TextRenderer]::MeasureText($Text, $b.Font).Width
        $b.Width = [math]::Max((Sz 96), $textWidth + (Sz 30) + (Sz $extra))
    }
    $b.Add_Resize({ param($s, $e) Set-AstRegion $s (Sz 7) })
    Set-AstRegion $b (Sz 7)
    if ($OnClick) { $b.Add_Click($OnClick) }
    if ($Tip) { Set-AstTip $b $Tip }
    return $b
}

function New-AstCombo {
    param([string[]]$Items, [int]$Index = 0, [int]$Width = 240)
    $t = $script:Theme
    $c = [System.Windows.Forms.ComboBox]::new()
    $c.DropDownStyle = 'DropDownList'
    $c.FlatStyle = 'Flat'
    $c.Width = Sz $Width
    $c.Font = Get-AstFont 'Segoe UI' 10 'Regular'
    $c.BackColor = $t.Surface2
    $c.ForeColor = $t.Text
    $c.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 4), (Sz 14), (Sz 8))
    foreach ($item in $Items) { [void]$c.Items.Add($item) }
    if ($Index -ge 0 -and $Index -lt $c.Items.Count) { $c.SelectedIndex = $Index }
    return $c
}

function New-AstTextBox {
    param([int]$Width = 240)
    $t = $script:Theme
    $x = [System.Windows.Forms.TextBox]::new()
    $x.Width = Sz $Width
    $x.BorderStyle = 'FixedSingle'
    $x.BackColor = $t.Surface2
    $x.ForeColor = $t.Text
    $x.Font = Get-AstFont 'Segoe UI' 10 'Regular'
    $x.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 6), (Sz 10), (Sz 8))
    return $x
}

function New-AstCheck {
    param([string]$Text, [bool]$Checked = $false)
    $c = [System.Windows.Forms.CheckBox]::new()
    $c.Text = $Text
    $c.Checked = $Checked
    $c.AutoSize = $true
    $c.ForeColor = $script:Theme.Text
    $c.BackColor = [System.Drawing.Color]::Transparent
    $c.Font = Get-AstFont 'Segoe UI' 10 'Regular'
    $c.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 8), (Sz 14), (Sz 8))
    return $c
}

function New-AstFlow {
    $f = [System.Windows.Forms.FlowLayoutPanel]::new()
    $f.Dock = 'Fill'
    $f.FlowDirection = 'LeftToRight'
    $f.WrapContents = $true
    $f.BackColor = [System.Drawing.Color]::Transparent
    Set-AstDoubleBuffered $f
    return $f
}

function Get-AstBarColor {
    param([int]$Percent)
    if ($Percent -ge 90) { return $script:Theme.Bad }
    if ($Percent -ge 70) { return $script:Theme.Warn }
    return $script:Theme.Good
}

# ---------- Progress bar ----------
function New-AstProgress {
    param([int]$Height = 6, $Color = $null)
    if (-not $Color) { $Color = $script:Theme.Accent }
    $track = [System.Windows.Forms.Panel]::new()
    $track.Height = Sz $Height
    $track.BackColor = $script:Theme.Border
    $comet = [System.Windows.Forms.Panel]::new()
    $comet.BackColor = [System.Windows.Forms.ControlPaint]::Light($Color, 0.3)
    $comet.Visible = $false
    $fill = [System.Windows.Forms.Panel]::new()
    $fill.Dock = Get-AstStart
    $fill.Width = 0
    $fill.BackColor = $Color
    $track.Controls.Add($comet)
    $track.Controls.Add($fill)
    $track.Tag = @{ Pct = 0.0; Fill = $fill; Comet = $comet }
    $track.Add_Resize({ param($s, $e) Set-AstProgress $s $s.Tag.Pct })
    Register-AstSlider $track $comet
    return $track
}

function Set-AstProgress {
    param($Bar, [double]$Percent)
    if (-not $Bar -or $Bar.IsDisposed) { return }
    $p = [math]::Max(0.0, [math]::Min(100.0, $Percent))
    $Bar.Tag.Pct = $p
    $Bar.Tag.Fill.Width = [int][math]::Round($Bar.Width * $p / 100.0)
}

# ---------- Spinner / loading ----------
function Invoke-AstSpinnerPaint {
    param($Sender, $E)
    $info = $Sender.Tag
    $g = $E.Graphics
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $d = [math]::Min($Sender.Width, $Sender.Height) - 2 * $info.Pad
    if ($d -lt 6) { return }
    $x = [int](($Sender.Width - $d) / 2)
    $y = [int](($Sender.Height - $d) / 2)
    $rect = [System.Drawing.Rectangle]::new($x, $y, $d, $d)
    $penWidth = [single](Sz 3)
    $track = New-Object System.Drawing.Pen($script:Theme.Border, $penWidth)
    $g.DrawEllipse($track, $rect)
    $track.Dispose()
    $arc = New-Object System.Drawing.Pen($info.Color, $penWidth)
    $arc.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $arc.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $g.DrawArc($arc, $rect, [single]$info.Angle, [single]100)
    $arc.Dispose()
}

function New-AstSpinner {
    param([int]$Size = 40, [int]$Pad = 4, $Color = $null, $BackColor = $null)
    $p = [System.Windows.Forms.Panel]::new()
    $p.Size = [System.Drawing.Size]::new((Sz $Size), (Sz $Size))
    if ($BackColor) { $p.BackColor = $BackColor } else { $p.BackColor = $script:Theme.Back }
    if (-not $Color) { $Color = $script:Theme.Accent }
    Set-AstDoubleBuffered $p

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 50
    $timer.Tag = $p
    $timer.Add_Tick({
        param($s, $e)
        $pn = $s.Tag
        if (-not $pn -or $pn.IsDisposed) { $s.Stop(); return }
        if ($pn.Visible) {
            $pn.Tag.Angle = ($pn.Tag.Angle + 24) % 360
            $pn.Invalidate()
        }
    })
    $p.Tag = @{ Angle = 0; Color = $Color; Pad = (Sz $Pad); Timer = $timer }
    $p.Add_Paint({ param($s, $e) Invoke-AstSpinnerPaint $s $e })
    $p.Add_Disposed({
        param($s, $e)
        try { $s.Tag.Timer.Stop(); $s.Tag.Timer.Dispose() } catch { }
    })
    $timer.Start()
    return $p
}

function New-AstLoadingView {
    param([string]$Text)
    $v = [System.Windows.Forms.Panel]::new()
    $v.Dock = 'Fill'
    $v.BackColor = $script:Theme.Back
    $sp = New-AstSpinner -Size 56 -Pad 4 -BackColor $script:Theme.Back
    $lb = New-AstLabel $Text -Muted -Size 11
    $v.Controls.Add($sp)
    $v.Controls.Add($lb)
    $v.Tag = @{ Spinner = $sp; Label = $lb }
    $v.Add_Resize({
        param($s, $e)
        $sp = $s.Tag.Spinner
        $lb = $s.Tag.Label
        $sp.Left = [int](($s.Width - $sp.Width) / 2)
        $sp.Top = [int]([math]::Max(10, $s.Height / 2 - (Sz 60)))
        $lb.Left = [int](($s.Width - $lb.PreferredWidth) / 2)
        $lb.Top = $sp.Bottom + (Sz 10)
    })
    return $v
}

# ---------- Vertical stack (page layout) ----------
function Get-AstTextHeight {
    param([string]$Text, $Font, [int]$Width)
    $flags = [System.Windows.Forms.TextFormatFlags]::WordBreak
    $size = [System.Windows.Forms.TextRenderer]::MeasureText($Text, $Font, [System.Drawing.Size]::new([math]::Max(60, $Width), 0), $flags)
    return $size.Height
}

function Update-AstGridLayout {
    param($Grid)
    $info = $Grid.Tag
    $w = $Grid.ClientSize.Width
    if ($w -lt 50) { return }
    $tileMin = $info.W
    $gap = $info.Gap
    $cols = [int][math]::Max(1, [math]::Floor(($w + $gap) / ($tileMin + $gap)))
    $tileW = [int][math]::Floor(($w - ($cols - 1) * $gap) / $cols)
    $i = 0
    foreach ($c in $Grid.Controls) {
        $col = $i % $cols
        $row = [int][math]::Floor($i / $cols)
        $x = $col * ($tileW + $gap)
        if ($script:IsRtl) { $x = $w - $tileW - $x }
        $c.SetBounds($x, $row * ($info.H + $gap), $tileW, $info.H)
        $i++
    }
    $rows = [int][math]::Ceiling($i / $cols)
    $h = 0
    if ($rows -gt 0) { $h = $rows * ($info.H + $gap) - $gap }
    if ($Grid.Height -ne $h) { $Grid.Height = $h }
}

function Update-AstChildHeight {
    param($C)
    if (-not ($C.Tag -is [hashtable])) { return }
    switch ([string]$C.Tag.Kind) {
        'grid' { Update-AstGridLayout $C }
        'text' {
            $lbl = $C.Tag.Label
            $C.Height = (Get-AstTextHeight $lbl.Text $lbl.Font ($C.Width - $C.Padding.Horizontal)) + (Sz 6)
        }
        'infocard' {
            $lbl = $C.Tag.Label
            $textWidth = $C.Width - $lbl.Padding.Horizontal
            $C.Height = (Sz 48) + (Get-AstTextHeight $lbl.Text $lbl.Font $textWidth) + (Sz 18)
        }
        'flowsection' {
            $w = [math]::Max(120, $C.Width - (Sz 32))
            $ph = $C.Tag.Flow.GetPreferredSize([System.Drawing.Size]::new($w, 0)).Height
            $C.Height = (Sz 51) + $ph + (Sz 18)
        }
    }
}

function Update-AstStackLayout {
    param($Stack)
    if (-not $Stack -or $Stack.IsDisposed) { return }
    $w = $Stack.ClientSize.Width
    if ($w -lt 120) { return }
    $scrollY = [math]::Abs($Stack.AutoScrollPosition.Y)
    $Stack.SuspendLayout()
    $y = 0
    foreach ($row in $Stack.Tag.Rows) {
        $c = $row.Ctl
        if ($c.IsDisposed) { continue }
        $c.Width = $w
        Update-AstChildHeight $c
        $c.SetBounds(0, $y - $scrollY, $w, $c.Height)
        $y += $c.Height + $row.Gap
    }
    $Stack.AutoScrollMinSize = [System.Drawing.Size]::new(0, $y)
    $Stack.ResumeLayout($true)
}

function New-AstStack {
    $s = [System.Windows.Forms.Panel]::new()
    $s.Dock = 'Fill'
    $s.AutoScroll = $true
    $s.BackColor = $script:Theme.Back
    Set-AstDoubleBuffered $s
    $s.Tag = @{ Rows = (New-Object System.Collections.ArrayList) }
    $s.Add_Resize({ param($sender, $e) Update-AstStackLayout $sender })
    return $s
}

function Add-AstRow {
    param($Stack, $Control, [int]$Gap = 14)
    [void]$Stack.Tag.Rows.Add(@{ Ctl = $Control; Gap = (Sz $Gap) })
    $Stack.Controls.Add($Control)
    Update-AstStackLayout $Stack
}

function New-AstTextBlock {
    param([string]$Text, [switch]$Muted, [switch]$Semi, [double]$Size = 10)
    $p = [System.Windows.Forms.Panel]::new()
    $p.BackColor = [System.Drawing.Color]::Transparent
    $lbl = New-AstLabel $Text -Muted:$Muted -Semi:$Semi -Size $Size
    $lbl.AutoSize = $false
    $lbl.Dock = 'Fill'
    $lbl.Margin = [System.Windows.Forms.Padding]::new(0)
    $p.Controls.Add($lbl)
    $p.Tag = @{ Kind = 'text'; Label = $lbl }
    return $p
}

function New-AstPage {
    param($Container, [string]$DescKey)
    $stack = New-AstStack
    $Container.Controls.Add($stack)
    if ($DescKey) { Add-AstRow $stack (New-AstTextBlock (T $DescKey) -Muted -Size 10) 6 }
    return $stack
}

# ---------- Cards and sections ----------
function New-AstSection {
    param([string]$Title, [string]$Icon = 'info', [int]$BodyHeight = 100, [string]$Color = 'Accent', [switch]$Spinner)
    $t = $script:Theme
    $panel = [System.Windows.Forms.Panel]::new()
    $panel.BackColor = $t.Surface
    $panel.Height = (Sz 51) + (Sz $BodyHeight)
    Set-AstDoubleBuffered $panel
    $panel.Add_Resize({ param($s, $e) Set-AstRegion $s (Sz 8) })

    $body = [System.Windows.Forms.Panel]::new()
    $body.Dock = 'Fill'
    $body.Padding = New-AstPad 16 0 16 14

    $header = [System.Windows.Forms.Panel]::new()
    $header.Dock = 'Top'
    $header.Height = Sz 48

    $iconLbl = New-AstIcon $Icon 14 $t[$Color]
    $iconLbl.Dock = Get-AstStart
    $iconLbl.Width = Sz 48

    $titleLbl = [System.Windows.Forms.Label]::new()
    $titleLbl.Dock = 'Fill'
    $titleLbl.Text = $Title
    $titleLbl.Font = Get-AstFont 'Segoe UI Semibold' 11.5 'Regular'
    $titleLbl.ForeColor = $t.Text
    $titleLbl.TextAlign = 'MiddleLeft'

    $header.Controls.Add($titleLbl)
    $header.Controls.Add($iconLbl)

    # Colored strip on top; a lighter highlight slides along it while the section is busy
    $strip = [System.Windows.Forms.Panel]::new()
    $strip.Dock = 'Top'
    $strip.Height = Sz 3
    $strip.BackColor = $t[$Color]
    $comet = [System.Windows.Forms.Panel]::new()
    $comet.BackColor = [System.Windows.Forms.ControlPaint]::LightLight($t[$Color])
    $comet.Visible = $false
    $strip.Controls.Add($comet)
    Register-AstSlider $strip $comet

    $sp = $null
    if ($Spinner) {
        $sp = New-AstSpinner -Size 48 -Pad 14 -BackColor $t.Surface
        $sp.Dock = Get-AstEnd
        $sp.Tag.Strip = $strip
        $sp.Add_VisibleChanged({ param($s, $e) Set-AstSlider $s.Tag.Strip $s.Visible })
        $header.Controls.Add($sp)
        Set-AstSlider $strip $true
    }

    $panel.Controls.Add($body)
    $panel.Controls.Add($header)
    $panel.Controls.Add($strip)
    return @{ Panel = $panel; Body = $body; Spinner = $sp; Header = $header; Strip = $strip }
}

function New-AstInfoCard {
    param([string]$Title, [string]$Text, [string]$Icon = 'info', [string]$Color = 'Accent')
    $t = $script:Theme
    $panel = [System.Windows.Forms.Panel]::new()
    $panel.BackColor = $t.Surface

    $iconLbl = New-AstIcon $Icon 14 $t[$Color]
    $iconLbl.Dock = Get-AstStart
    $iconLbl.Width = Sz 48

    $titleLbl = [System.Windows.Forms.Label]::new()
    $titleLbl.Dock = 'Fill'
    $titleLbl.Text = $Title
    $titleLbl.Font = Get-AstFont 'Segoe UI Semibold' 11 'Regular'
    $titleLbl.ForeColor = $t.Text
    $titleLbl.TextAlign = 'MiddleLeft'

    $header = [System.Windows.Forms.Panel]::new()
    $header.Dock = 'Top'
    $header.Height = Sz 48
    $header.Controls.Add($titleLbl)
    $header.Controls.Add($iconLbl)

    $body = [System.Windows.Forms.Label]::new()
    $body.Dock = 'Fill'
    $body.Text = $Text
    $body.Font = Get-AstFont 'Segoe UI' 10 'Regular'
    $body.ForeColor = $t.TextMuted
    $body.TextAlign = 'TopLeft'
    $body.Padding = New-AstPad 16 0 16 14

    $panel.Controls.Add($body)
    $panel.Controls.Add($header)
    $panel.Tag = @{ Kind = 'infocard'; Label = $body }
    $panel.Add_Resize({ param($s, $e) Set-AstRegion $s (Sz 8) })
    return $panel
}

function New-AstGrid {
    param([int]$TileWidth = 280, [int]$TileHeight = 96, [int]$Gap = 12)
    $g = [System.Windows.Forms.Panel]::new()
    $g.BackColor = [System.Drawing.Color]::Transparent
    Set-AstDoubleBuffered $g
    $g.Tag = @{ Kind = 'grid'; W = (Sz $TileWidth); H = (Sz $TileHeight); Gap = (Sz $Gap) }
    $g.Add_Resize({ param($s, $e) Update-AstGridLayout $s })
    return $g
}

function New-AstStatCard {
    param([string]$Title, [string]$Value, [int]$Percent = -1, [string]$Accent = 'Accent')
    $t = $script:Theme
    $card = [System.Windows.Forms.Panel]::new()
    $card.BackColor = $t.Surface
    Set-AstDoubleBuffered $card

    $valueLabel = [System.Windows.Forms.Label]::new()
    $valueLabel.Dock = 'Fill'
    $valueLabel.Text = $Value
    $valueLabel.Font = Get-AstFont 'Segoe UI Semibold' 10.5 'Regular'
    $valueLabel.ForeColor = $t.Text
    $valueLabel.TextAlign = 'TopLeft'
    $valueLabel.Padding = New-AstPad 14 2 14 6

    $titleLabel = [System.Windows.Forms.Label]::new()
    $titleLabel.Dock = 'Top'
    $titleLabel.Height = Sz 30
    $titleLabel.Text = $Title
    $titleLabel.Font = Get-AstFont 'Segoe UI' 9 'Regular'
    $titleLabel.ForeColor = $t.TextMuted
    $titleLabel.TextAlign = 'BottomLeft'
    $titleLabel.Padding = New-AstPad 14 0 14 2

    $card.Controls.Add($valueLabel)
    $card.Controls.Add($titleLabel)

    if ($Percent -ge 0) {
        $pct = [math]::Min($Percent, 100)
        $bar = New-AstProgress -Height 6 -Color (Get-AstBarColor -Percent $pct)
        $bar.Dock = 'Bottom'
        Set-AstProgress $bar $pct
        $card.Controls.Add($bar)
    }
    $strip = [System.Windows.Forms.Panel]::new()
    $strip.Dock = Get-AstStart
    $strip.Width = Sz 4
    $strip.BackColor = $t[$Accent]
    $card.Controls.Add($strip)
    $card.Tag = @{ Strip = $strip }
    $card.Add_Resize({ param($s, $e) Set-AstRegion $s (Sz 8) })
    return $card
}

# ---------- Tiles (clickable cards that launch something) ----------
function Invoke-AstTileAction {
    param($Action)
    if (-not $Action) { return }
    try {
        switch ([string]$Action.Kind) {
            'page'   { Show-AstPage ([string]$Action.Target) }
            'launch' {
                $params = @{ FilePath = [string]$Action.Target; ErrorAction = 'Stop' }
                if ($Action.Args) { $params['ArgumentList'] = [string]$Action.Args }
                if ($Action.Verb) { $params['Verb'] = [string]$Action.Verb }
                Start-Process @params
                Write-AstLog 'INFO' ('Launched: ' + [string]$Action.Target)
            }
            'func'   { & ([string]$Action.Target) }
        }
    }
    catch {
        Write-AstLog 'WARN' ('Tile action failed: ' + $_.Exception.Message)
        [void](Show-AstMessage ((T 'tool_unavailable') -f [string]$Action.Target) (T 'error_title') 'OK' 'Warning')
    }
}

function New-AstTile {
    param([string]$Icon, [string]$Title, [string]$Desc, [string]$Color = 'Accent', $Action = $null)
    $t = $script:Theme
    $tile = [System.Windows.Forms.Panel]::new()
    $tile.BackColor = $t.Surface
    $tile.Cursor = 'Hand'
    Set-AstDoubleBuffered $tile
    $tile.Add_Resize({ param($s, $e) Set-AstRegion $s (Sz 8) })

    $iconHost = [System.Windows.Forms.Panel]::new()
    $iconHost.Dock = Get-AstStart
    $iconHost.Width = Sz 72
    $iconHost.Padding = [System.Windows.Forms.Padding]::new((Sz 12), (Sz 30), (Sz 12), (Sz 30))
    $glyph = New-AstIcon $Icon 16 ([System.Drawing.Color]::White)
    $glyph.Dock = 'Fill'
    $glyph.BackColor = $t[$Color]
    $iconHost.Controls.Add($glyph)

    $titleLbl = [System.Windows.Forms.Label]::new()
    $titleLbl.Dock = 'Top'
    $titleLbl.Height = Sz 46
    $titleLbl.Text = $Title
    $titleLbl.Font = Get-AstFont 'Segoe UI Semibold' 10.5 'Regular'
    $titleLbl.ForeColor = $t.Text
    $titleLbl.TextAlign = 'BottomLeft'

    $descLbl = [System.Windows.Forms.Label]::new()
    $descLbl.Dock = 'Fill'
    $descLbl.Text = $Desc
    $descLbl.Font = Get-AstFont 'Segoe UI' 8.5 'Regular'
    $descLbl.ForeColor = $t.TextMuted
    $descLbl.TextAlign = 'TopLeft'

    $textHost = [System.Windows.Forms.Panel]::new()
    $textHost.Dock = 'Fill'
    $textHost.Padding = New-AstPad 0 4 10 6
    $textHost.Controls.Add($descLbl)
    $textHost.Controls.Add($titleLbl)

    $tile.Controls.Add($textHost)
    $tile.Controls.Add($iconHost)

    $data = @{ Action = $Action; Panel = $tile }
    $onClick = { param($s, $e) Invoke-AstTileAction $s.Tag.Action }
    $onEnter = { param($s, $e) $s.Tag.Panel.BackColor = $script:Theme.Surface2 }
    $onLeave = { param($s, $e) $s.Tag.Panel.BackColor = $script:Theme.Surface }
    foreach ($c in @($tile, $iconHost, $glyph, $textHost, $titleLbl, $descLbl)) {
        $c.Tag = $data
        $c.Cursor = 'Hand'
        $c.Add_Click($onClick)
        $c.Add_MouseEnter($onEnter)
        $c.Add_MouseLeave($onLeave)
    }
    Set-AstTip $tile $Desc
    return $tile
}

# ---------- Banner ----------
function New-AstBanner {
    param([string]$Text, [string]$Icon = 'warning', [string]$Color = 'Warn', [string]$ButtonText = '', [scriptblock]$OnClick = $null)
    $t = $script:Theme
    $p = [System.Windows.Forms.Panel]::new()
    $p.BackColor = $t.Surface
    $p.Height = Sz 62

    $strip = [System.Windows.Forms.Panel]::new()
    $strip.Dock = Get-AstStart
    $strip.Width = Sz 5
    $strip.BackColor = $t[$Color]

    $iconLbl = New-AstIcon $Icon 16 $t[$Color]
    $iconLbl.Dock = Get-AstStart
    $iconLbl.Width = Sz 52

    $lbl = [System.Windows.Forms.Label]::new()
    $lbl.Dock = 'Fill'
    $lbl.Text = $Text
    $lbl.Font = Get-AstFont 'Segoe UI' 10 'Regular'
    $lbl.ForeColor = $t.Text
    $lbl.TextAlign = 'MiddleLeft'

    $p.Controls.Add($lbl)
    $p.Controls.Add($iconLbl)
    $p.Controls.Add($strip)
    $p.Add_Resize({ param($s, $e) Set-AstRegion $s (Sz 8) })
    if ($ButtonText -and $OnClick) {
        $host_ = [System.Windows.Forms.Panel]::new()
        $host_.Dock = Get-AstEnd
        $host_.Padding = [System.Windows.Forms.Padding]::new((Sz 8), (Sz 11), (Sz 12), (Sz 8))
        $btn = New-AstButton $ButtonText -Style primary -OnClick $OnClick
        $btn.Dock = 'Fill'
        $host_.Width = $btn.Width + (Sz 20)
        $host_.Controls.Add($btn)
        $p.Controls.Add($host_)
    }
    return $p
}

# ---------- Console (live output of long tasks) ----------
function New-AstConsole {
    param([string]$Key, [int]$Height = 280)
    $t = $script:Theme
    $panel = [System.Windows.Forms.Panel]::new()
    $panel.BackColor = $t.Surface
    $panel.Height = Sz $Height

    $box = [System.Windows.Forms.RichTextBox]::new()
    $box.ReadOnly = $true
    $box.ScrollBars = 'Both'
    $box.WordWrap = $false
    $box.DetectUrls = $false
    $box.Dock = 'Fill'
    $box.BorderStyle = 'None'
    $box.BackColor = [System.Drawing.ColorTranslator]::FromHtml('#0A0F18')
    $box.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#D1D9E6')
    $box.Font = Get-AstFont 'Consolas' 9.5 'Regular'
    $box.RightToLeft = 'No'
    $box.HideSelection = $false

    $progress = New-AstProgress -Height 5
    $progress.Dock = 'Top'

    $bar = [System.Windows.Forms.Panel]::new()
    $bar.Dock = 'Top'
    $bar.Height = Sz 50
    $bar.Padding = [System.Windows.Forms.Padding]::new((Sz 10), (Sz 6), (Sz 10), (Sz 6))

    $status = [System.Windows.Forms.Label]::new()
    $status.Dock = 'Fill'
    $status.Text = T 'console_idle'
    $status.Font = Get-AstFont 'Segoe UI' 9.5 'Regular'
    $status.ForeColor = $t.TextMuted
    $status.TextAlign = 'MiddleLeft'

    $spinner = New-AstSpinner -Size 38 -Pad 9 -BackColor $t.Surface
    $spinner.Dock = Get-AstStart
    $spinner.Visible = $false

    $copy = New-AstButton (T 'console_copy') -Icon 'copy' -Style secondary
    $copy.Dock = Get-AstEnd
    $copy.Margin = [System.Windows.Forms.Padding]::new(0)
    $copy.Tag = @{ Glyph = (Get-AstGlyph 'copy'); Color = $copy.ForeColor; Box = $box }
    $copy.Add_Click({ param($s, $e) Copy-AstConsoleText $s })

    $cancel = New-AstButton (T 'console_cancel') -Icon 'stop' -Style danger
    $cancel.Dock = Get-AstEnd
    $cancel.Margin = [System.Windows.Forms.Padding]::new(0, 0, (Sz 8), 0)
    $cancel.Enabled = $false
    $cancel.Add_Click({ param($s, $e) Stop-AstTask ([string]$s.Tag.Key) })
    $cancel.Tag = @{ Glyph = (Get-AstGlyph 'stop'); Color = [System.Drawing.Color]::White; Key = $Key }

    $bar.Controls.Add($status)
    $bar.Controls.Add($spinner)
    $bar.Controls.Add($copy)
    $bar.Controls.Add($cancel)

    $panel.Controls.Add($box)
    $panel.Controls.Add($progress)
    $panel.Controls.Add($bar)

    $console = @{ Key = $Key; Panel = $panel; Box = $box; Status = $status; Spinner = $spinner; Progress = $progress; Cancel = $cancel; Copy = $copy }
    return $console
}

function Copy-AstConsoleText {
    param($Sender)
    $box = $Sender.Tag.Box
    if ($box -and $box.Text.Length -gt 0) { try { [System.Windows.Forms.Clipboard]::SetText($box.Text) } catch { } }
}


# ---------- Hero banner with gradient and score gauge ----------
function Invoke-AstHeroPaint {
    param($Sender, $E)
    $info = $Sender.Tag
    $rect = $Sender.ClientRectangle
    if ($rect.Width -lt 4 -or $rect.Height -lt 4) { return }
    $g = $E.Graphics
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $info.Color1, $info.Color2, [single]20)
    $g.FillRectangle($brush, $rect)
    $brush.Dispose()
    $circleA = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(30, 255, 255, 255))
    $circleB = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(20, 255, 255, 255))
    if ($script:IsRtl) { $cx = Sz 40 } else { $cx = $rect.Width - (Sz 40) }
    $g.FillEllipse($circleA, [int]($cx - (Sz 170)), [int](-(Sz 80)), (Sz 300), (Sz 300))
    $g.FillEllipse($circleB, [int]($cx - (Sz 330)), [int]($rect.Height - (Sz 90)), (Sz 220), (Sz 220))
    $circleA.Dispose(); $circleB.Dispose()

    $size = [int][math]::Min($rect.Height - (Sz 36), (Sz 118))
    $margin = Sz 26
    if ($script:IsRtl) { $x = $rect.Width - $margin - $size } else { $x = $margin }
    $y = [int](($rect.Height - $size) / 2)
    $gr = [System.Drawing.Rectangle]::new($x, $y, $size, $size)
    $penW = [single](Sz 9)
    $track = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(80, 255, 255, 255), $penW)
    $g.DrawEllipse($track, $gr)
    $track.Dispose()
    $arc = New-Object System.Drawing.Pen([System.Drawing.Color]::White, $penW)
    $arc.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $arc.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $sweep = [single]([math]::Max(4, 360.0 * $info.Score / 100.0))
    $g.DrawArc($arc, $gr, [single]-90, $sweep)
    $arc.Dispose()
    $flags = [System.Windows.Forms.TextFormatFlags]::HorizontalCenter -bor [System.Windows.Forms.TextFormatFlags]::VerticalCenter -bor [System.Windows.Forms.TextFormatFlags]::NoPadding
    [System.Windows.Forms.TextRenderer]::DrawText($g, [string]$info.Score, (Get-AstFont 'Segoe UI Semibold' 28 'Regular'), $gr, [System.Drawing.Color]::White, $flags)
}

function New-AstHero {
    param([int]$Score, $Color1, $Color2, [int]$Height = 150)
    $p = [System.Windows.Forms.Panel]::new()
    $p.Height = Sz $Height
    Set-AstDoubleBuffered $p
    $p.Tag = @{ Score = $Score; Color1 = $Color1; Color2 = $Color2 }
    $p.Add_Paint({ param($s, $e) Invoke-AstHeroPaint $s $e })
    $p.Add_Resize({ param($s, $e) Set-AstRegion $s (Sz 12) })
    return $p
}

# ---------- Tab bar ----------
function Select-AstTab {
    param($Bar, [string]$Key, [string]$Callback)
    $t = $script:Theme
    foreach ($b in $Bar.Controls) {
        if ($b.Tag.Key -eq $Key) {
            $b.BackColor = $t.Accent; $b.ForeColor = $t.AccentText; $b.Tag.Color = $t.AccentText
            $b.FlatAppearance.BorderColor = $t.Accent
        }
        else {
            $b.BackColor = $t.Surface2; $b.ForeColor = $t.Text; $b.Tag.Color = $t.Text
            $b.FlatAppearance.BorderColor = $t.Border
        }
        $b.Invalidate()
    }
    & $Callback $Key
}

function New-AstTabBar {
    param([array]$Tabs, [string]$Callback)
    $bar = [System.Windows.Forms.FlowLayoutPanel]::new()
    $bar.Dock = 'Top'
    $bar.Height = Sz 54
    $bar.WrapContents = $false
    $bar.BackColor = $script:Theme.Back
    foreach ($tab in $Tabs) {
        $b = New-AstButton (T $tab.Title) -Icon $tab.Icon -Style secondary
        $b.Margin = [System.Windows.Forms.Padding]::new(0, 0, (Sz 8), 0)
        $b.Tag = @{ Glyph = (Get-AstGlyph $tab.Icon); Color = $script:Theme.Text; Key = $tab.Key; Callback = $Callback; Bar = $bar }
        $b.Add_Click({ param($s, $e) Select-AstTab $s.Tag.Bar $s.Tag.Key $s.Tag.Callback })
        $bar.Controls.Add($b)
    }
    return $bar
}

# ---------- Virtual data list (fast: only visible rows are created) ----------
# Columns: @{ Header = 'lang_key'; Width = 200; Prop = 'PropertyName' }.  Rows are plain objects.
# An optional 'Tone' property on a row (good / warn / bad / muted) colors the whole row.
function Get-AstDataRow {
    param($List, $E)
    $info = $List.Tag
    if ($E.ItemIndex -ge $info.View.Count) { $E.Item = [System.Windows.Forms.ListViewItem]::new(''); return }
    $r = $info.View[$E.ItemIndex]
    $item = $null
    foreach ($col in $info.Columns) {
        $prop = [string]$col.Prop
        $val = [string]$r.$prop
        if ($null -eq $item) { $item = [System.Windows.Forms.ListViewItem]::new($val) }
        else { [void]$item.SubItems.Add($val) }
    }
    if ($r.PSObject.Properties['Tone']) {
        switch ([string]$r.Tone) {
            'bad'   { $item.ForeColor = $script:Theme.Bad }
            'warn'  { $item.ForeColor = $script:Theme.Warn }
            'good'  { $item.ForeColor = $script:Theme.Good }
            'muted' { $item.ForeColor = $script:Theme.TextMuted }
        }
    }
    $E.Item = $item
}

function New-AstDataList {
    param([array]$Columns, [string]$KeyProp = 'Id', [string]$CountKey = '', $CountLabel = $null)
    $t = $script:Theme
    $lv = [System.Windows.Forms.ListView]::new()
    $lv.Dock = 'Fill'
    $lv.View = 'Details'
    $lv.VirtualMode = $true
    $lv.FullRowSelect = $true
    $lv.MultiSelect = $false
    $lv.HideSelection = $false
    $lv.BorderStyle = 'None'
    $lv.BackColor = $t.Surface2
    $lv.ForeColor = $t.Text
    $lv.Font = Get-AstFont 'Segoe UI' 9.5 'Regular'
    foreach ($col in $Columns) { [void]$lv.Columns.Add((T $col.Header), (Sz $col.Width)) }
    $lv.Tag = @{ Columns = $Columns; Data = @(); View = @(); SortCol = 0; SortAsc = $true; Filter = ''; KeyProp = $KeyProp; CountKey = $CountKey; CountLabel = $CountLabel }
    Set-AstDoubleBuffered $lv
    $lv.Add_RetrieveVirtualItem({ param($s, $e) Get-AstDataRow $s $e })
    $lv.Add_ColumnClick({ param($s, $e) Set-AstDataSort $s $e.Column })
    return $lv
}

function Update-AstDataList {
    param($List)
    if (-not $List -or $List.IsDisposed) { return }
    $info = $List.Tag
    $rows = @($info.Data)
    $filter = [string]$info.Filter
    if ($filter.Length -gt 0) {
        $props = @($info.Columns | ForEach-Object { [string]$_.Prop })
        $rows = @($rows | Where-Object {
            $r = $_
            $hit = $false
            foreach ($pn in $props) {
                if (([string]$r.$pn).IndexOf($filter, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) { $hit = $true; break }
            }
            $hit
        })
    }
    $sortProp = [string]$info.Columns[$info.SortCol].Prop
    $rows = @($rows | Sort-Object -Property $sortProp -Descending:(-not $info.SortAsc))

    $keyProp = [string]$info.KeyProp
    $selKey = $null
    if ($List.SelectedIndices.Count -gt 0) {
        $idx = $List.SelectedIndices[0]
        if ($idx -lt $info.View.Count) { $selKey = [string]$info.View[$idx].$keyProp }
    }
    $info.View = $rows
    $List.BeginUpdate()
    try {
        $List.VirtualListSize = $rows.Count
        if ($null -ne $selKey) {
            for ($i = 0; $i -lt $rows.Count; $i++) {
                if ([string]$rows[$i].$keyProp -eq $selKey) { [void]$List.SelectedIndices.Add($i); break }
            }
        }
    }
    finally { $List.EndUpdate() }
    $List.Invalidate()

    $arrow = [string][char]0x25B2
    if (-not $info.SortAsc) { $arrow = [string][char]0x25BC }
    for ($i = 0; $i -lt $info.Columns.Count; $i++) {
        $caption = T $info.Columns[$i].Header
        if ($i -eq $info.SortCol) { $caption = $caption + ' ' + $arrow }
        $List.Columns[$i].Text = $caption
    }
    if ($info.CountLabel -and -not $info.CountLabel.IsDisposed -and $info.CountKey) {
        $info.CountLabel.Text = (T $info.CountKey) -f $rows.Count
    }
}

function Set-AstDataList {
    param($List, $Data)
    if (-not $List -or $List.IsDisposed) { return }
    $List.Tag.Data = @($Data)
    Update-AstDataList $List
}

function Set-AstDataSort {
    param($List, [int]$Column)
    $info = $List.Tag
    if ($info.SortCol -eq $Column) { $info.SortAsc = -not $info.SortAsc }
    else { $info.SortCol = $Column; $info.SortAsc = $true }
    Update-AstDataList $List
}

function Get-AstDataSelected {
    param($List)
    if (-not $List -or $List.IsDisposed) { return $null }
    if ($List.SelectedIndices.Count -eq 0) { return $null }
    $idx = $List.SelectedIndices[0]
    if ($idx -ge $List.Tag.View.Count) { return $null }
    return $List.Tag.View[$idx]
}

function New-AstSearchBox {
    param($List, [int]$Width = 220)
    $x = New-AstTextBox -Width $Width
    $x.Tag = $List
    $x.Add_TextChanged({ param($s, $e) $l = $s.Tag; $l.Tag.Filter = $s.Text.Trim(); Update-AstDataList $l })
    Set-AstTip $x (T 'search_tip')
    return $x
}

function New-AstToolbar {
    # Wraps onto several lines when the window is narrow and grows to fit (no clipped buttons)
    $f = [System.Windows.Forms.FlowLayoutPanel]::new()
    $f.Dock = 'Top'
    $f.Height = Sz 52
    $f.WrapContents = $true
    $f.BackColor = [System.Drawing.Color]::Transparent
    $f.Add_Resize({
        param($s, $e)
        if ($s.Width -lt 60) { return }
        $h = [math]::Max((Sz 52), $s.GetPreferredSize([System.Drawing.Size]::new($s.Width, 0)).Height)
        if ($s.Height -ne $h) { $s.Height = $h }
    })
    return $f
}

# ---------- Score styling and reusable hero banner (used by Security, Storage, ...) ----------
function Get-AstScoreStyle {
    param([int]$Score)
    $t = $script:Theme
    if ($Score -ge 80) { return @{ C1 = $t.Accent; C2 = $t.Teal; Key = 'health_good' } }
    if ($Score -ge 60) { return @{ C1 = $t.Warn; C2 = $t.Pink; Key = 'health_fair' } }
    return @{ C1 = $t.Bad; C2 = $t.Purple; Key = 'health_poor' }
}

function New-AstHeroBanner {
    param([int]$Score, [string]$Title, [string]$Sub, [switch]$Refresh)
    $style = Get-AstScoreStyle $Score
    $hero = New-AstHero $Score $style.C1 $style.C2 140

    $textHost = [System.Windows.Forms.Panel]::new()
    $textHost.Dock = 'Fill'
    $textHost.BackColor = [System.Drawing.Color]::Transparent
    $textHost.Padding = New-AstPad 170 22 16 10

    $subLbl = [System.Windows.Forms.Label]::new()
    $subLbl.Dock = 'Fill'
    $subLbl.BackColor = [System.Drawing.Color]::Transparent
    $subLbl.Font = Get-AstFont 'Segoe UI' 10.5 'Regular'
    $subLbl.ForeColor = [System.Drawing.Color]::White
    $subLbl.TextAlign = 'TopLeft'
    $subLbl.Text = $Sub
    $titleLbl = [System.Windows.Forms.Label]::new()
    $titleLbl.Dock = 'Top'
    $titleLbl.Height = Sz 46
    $titleLbl.BackColor = [System.Drawing.Color]::Transparent
    $titleLbl.Font = Get-AstFont 'Segoe UI Semibold' 20 'Regular'
    $titleLbl.ForeColor = [System.Drawing.Color]::White
    $titleLbl.TextAlign = 'BottomLeft'
    $titleLbl.Text = $Title
    $textHost.Controls.Add($subLbl)
    $textHost.Controls.Add($titleLbl)

    if ($Refresh) {
        $btnHost = [System.Windows.Forms.Panel]::new()
        $btnHost.Dock = Get-AstEnd
        $btnHost.Width = Sz 170
        $btnHost.BackColor = [System.Drawing.Color]::Transparent
        $btnHost.Padding = [System.Windows.Forms.Padding]::new(0, (Sz 48), (Sz 20), 0)
        $btn = New-AstButton (T 'refresh') -Icon 'refresh' -Width 140 -OnClick {
            $script:Form.BeginInvoke([System.Action]{ Show-AstPage $script:CurrentPage }) | Out-Null
        }
        $btn.Dock = 'Top'
        $btn.Margin = [System.Windows.Forms.Padding]::new(0)
        $btnHost.Controls.Add($btn)
        $hero.Controls.Add($textHost)
        $hero.Controls.Add($btnHost)
    }
    else { $hero.Controls.Add($textHost) }
    return $hero
}

# Value label of a stat card (first control added by New-AstStatCard)
function Set-AstCardTone {
    param($Card, [string]$Tone)
    $t = $script:Theme
    switch ($Tone) {
        'good' { $c = $t.Good }
        'warn' { $c = $t.Warn }
        'bad'  { $c = $t.Bad }
        default { $c = $t.TextMuted }
    }
    $Card.Controls[0].ForeColor = $c
    if ($Card.Tag -is [hashtable] -and $Card.Tag.Strip) { $Card.Tag.Strip.BackColor = $c }
}

