# ============================================================
# UI.ps1 - application shell: window, sidebar navigation, page switching
# ASCII-only file. All visible text comes from Lang\*.json through T 'key'.
#
# Adding a page: define a function  Build-AstPage-<Id>  taking ($Container) and register the Id
# in $script:Pages below. Pages without a builder show the designed "coming next" screen.
# A page that owns timers/runspaces sets  $script:PageCleanup = { ... }  to release them.
# ============================================================

$script:CurrentPage = 'dashboard'
$script:UI          = @{ Nav = @{} }
$script:PageCleanup = $null

$script:Pages = @(
    @{ Id = 'dashboard';   TitleKey = 'nav_dashboard';   Icon = 'home';     Color = 'Accent' },
    @{ Id = 'performance'; TitleKey = 'nav_performance'; Icon = 'pulse';    Color = 'Pink' },
    @{ Id = 'maintenance'; TitleKey = 'nav_maintenance'; Icon = 'sync';     Color = 'Good' },
    @{ Id = 'network';     TitleKey = 'nav_network';     Icon = 'globe';    Color = 'Sky' },
    @{ Id = 'startup';     TitleKey = 'nav_startup';     Icon = 'power';    Color = 'Warn' },
    @{ Id = 'storage';     TitleKey = 'nav_storage';     Icon = 'drive';    Color = 'Teal' },
    @{ Id = 'security';    TitleKey = 'nav_security';    Icon = 'lock';     Color = 'Bad' },
    @{ Id = 'diagnostics'; TitleKey = 'nav_diagnostics'; Icon = 'search';   Color = 'Purple' },
    @{ Id = 'tools';       TitleKey = 'nav_tools';       Icon = 'apps';     Color = 'Accent' },
    @{ Id = 'restore';     TitleKey = 'nav_restore';     Icon = 'restore';  Color = 'Teal' },
    @{ Id = 'settings';    TitleKey = 'nav_settings';    Icon = 'settings'; Color = 'Purple' },
    @{ Id = 'help';        TitleKey = 'nav_help';        Icon = 'help';     Color = 'Sky' }
)

function Invoke-AstPageCleanup {
    $cleanup = $script:PageCleanup
    $script:PageCleanup = $null
    if ($cleanup) {
        try { & $cleanup }
        catch { Write-AstLog 'WARN' ('Page cleanup failed: ' + $_.Exception.Message) }
    }
}

function Test-AstPageAvailable {
    param([string]$Id)
    return [bool](Get-Command -Name ('Build-AstPage-' + $Id) -CommandType Function -ErrorAction SilentlyContinue)
}

function Set-AstStatus {
    param([string]$Text)
    if ($script:UI.Status -and -not $script:UI.Status.IsDisposed) { $script:UI.Status.Text = $Text }
}

# ---------- Navigation ----------
function Set-AstNavItemColor {
    param($Item, [string]$State)
    $t = $script:Theme
    switch ($State) {
        'active' { $bg = $t.Accent;       $fg = $t.AccentText }
        'hover'  { $bg = $t.SidebarHover; $fg = $t.Text }
        default  { $bg = $t.Sidebar;      $fg = $t.TextMuted }
    }
    $Item.Panel.BackColor = $bg
    $Item.Icon.BackColor  = $bg
    $Item.Text.BackColor  = $bg
    $Item.Icon.ForeColor  = $fg
    $Item.Text.ForeColor  = $fg
    if ($State -eq 'active') { $Item.Ind.BackColor = [System.Drawing.Color]::White } else { $Item.Ind.BackColor = $bg }
}

function New-AstNavItem {
    param([string]$Id, [string]$Icon, [string]$Caption)

    $panel = [System.Windows.Forms.Panel]::new()
    $panel.Size = [System.Drawing.Size]::new((Sz 240), (Sz 42))
    $panel.Margin = [System.Windows.Forms.Padding]::new(0)

    $iconLbl = New-AstIcon $Icon 12
    $iconLbl.Dock = Get-AstStart
    $iconLbl.Width = Sz 52

    $text = [System.Windows.Forms.Label]::new()
    $text.Dock = 'Fill'
    $text.Font = Get-AstFont 'Segoe UI' 10 'Regular'
    $text.Text = $Caption
    $text.TextAlign = 'MiddleLeft'

    $ind = [System.Windows.Forms.Panel]::new()
    $ind.Dock = Get-AstStart
    $ind.Width = Sz 4

    $panel.Controls.Add($text)
    $panel.Controls.Add($iconLbl)
    $panel.Controls.Add($ind)

    $onClick = { param($sender, $e) Show-AstPage ([string]$sender.Tag) }
    $onEnter = {
        param($sender, $e)
        $navId = [string]$sender.Tag
        if ($navId -ne $script:CurrentPage) { $item = $script:UI.Nav[$navId]; Set-AstNavItemColor $item 'hover' }
    }
    $onLeave = {
        param($sender, $e)
        $navId = [string]$sender.Tag
        if ($navId -ne $script:CurrentPage) { $item = $script:UI.Nav[$navId]; Set-AstNavItemColor $item 'normal' }
    }
    foreach ($c in @($panel, $iconLbl, $text, $ind)) {
        $c.Tag = $Id
        $c.Cursor = 'Hand'
        $c.Add_Click($onClick)
        $c.Add_MouseEnter($onEnter)
        $c.Add_MouseLeave($onLeave)
    }
    $item = @{ Panel = $panel; Icon = $iconLbl; Text = $text; Ind = $ind }
    Set-AstNavItemColor $item 'normal'
    $script:UI.Nav[$Id] = $item
    return $panel
}

function Show-AstPage {
    param([string]$Id)

    $page = $script:Pages | Where-Object { $_.Id -eq $Id } | Select-Object -First 1
    if (-not $page) { return }
    $script:CurrentPage = $Id

    foreach ($key in @($script:UI.Nav.Keys)) {
        $item = $script:UI.Nav[$key]
        if ($key -eq $Id) { Set-AstNavItemColor $item 'active' } else { Set-AstNavItemColor $item 'normal' }
    }
    $script:UI.Title.Text = T $page.TitleKey
    $script:UI.HeaderIcon.Text = Get-AstGlyph $page.Icon
    $script:UI.HeaderIcon.ForeColor = $script:Theme[$page.Color]

    Invoke-AstPageCleanup

    $content = $script:UI.Content
    $content.SuspendLayout()
    foreach ($c in @($content.Controls)) { $content.Controls.Remove($c); $c.Dispose() }

    try {
        if (Test-AstPageAvailable $Id) { & ('Build-AstPage-' + $Id) $content }
        else { Build-AstPage-Placeholder $content $page }
    }
    catch {
        Write-AstLog 'ERROR' ("Page '{0}' failed: {1}" -f $Id, $_.Exception.ToString())
        $content.Controls.Add((New-AstLabel (T 'error_load_page') -Size 11 -Width 600))
    }
    $content.ResumeLayout($true)
    Set-AstStatus ''
}

# Designed screen for pages that are planned but not delivered yet
function Build-AstPage-Placeholder {
    param($Container, $Page)
    $stack = New-AstPage $Container ('desc_' + $Page.Id)
    $features = (T ('soon_' + $Page.Id)) -split '\|'
    $bullets = ($features | ForEach-Object { '  ' + [char]0x2022 + '  ' + $_.Trim() }) -join "`n"
    Add-AstRow $stack (New-AstInfoCard (T 'soon_title') ((T 'soon_text') + "`n`n" + $bullets) 'info' $Page.Color)
}

# ---------- Main window ----------
function Build-AstUI {
    $f = $script:Form
    Import-AstLanguage $script:Settings['Language']
    $script:Theme = Get-AstTheme $script:Settings['Theme']
    $t = $script:Theme

    $f.SuspendLayout()
    Invoke-AstPageCleanup
    foreach ($c in @($f.Controls)) { $f.Controls.Remove($c); $c.Dispose() }
    $script:UI = @{ Nav = @{} }
    if ($script:Tip) { try { $script:Tip.Dispose() } catch { } }
    $script:Tip = New-Object System.Windows.Forms.ToolTip
    $script:Tip.InitialDelay = 350
    $script:Tip.ShowAlways = $true

    # Only the reading direction changes; the window itself is never mirrored or recreated.
    if ($script:IsRtl) { $f.RightToLeft = 'Yes' } else { $f.RightToLeft = 'No' }
    $f.BackColor = $t.Back
    $f.ForeColor = $t.Text
    $f.Text = '{0}  v{1}' -f $script:AppName, $script:AppVersion

    $isAdmin = Test-AstAdmin

    # Content area
    $content = [System.Windows.Forms.Panel]::new()
    $content.Dock = 'Fill'
    $content.BackColor = $t.Back
    $content.Padding = [System.Windows.Forms.Padding]::new((Sz 24), (Sz 16), (Sz 24), (Sz 8))
    Set-AstDoubleBuffered $content
    $script:UI.Content = $content

    # Header: page icon + title + chips
    $header = [System.Windows.Forms.Panel]::new()
    $header.Dock = 'Top'
    $header.Height = Sz 66
    $header.BackColor = $t.Surface

    $headerIcon = New-AstIcon 'home' 18
    $headerIcon.Dock = Get-AstStart
    $headerIcon.Width = Sz 64
    $script:UI.HeaderIcon = $headerIcon

    $title = [System.Windows.Forms.Label]::new()
    $title.Dock = 'Fill'
    $title.Font = Get-AstFont 'Segoe UI Semibold' 16 'Regular'
    $title.ForeColor = $t.Text
    $title.TextAlign = 'MiddleLeft'
    $script:UI.Title = $title

    $badge = [System.Windows.Forms.Label]::new()
    $badge.Dock = Get-AstEnd
    $badge.Width = Sz 170
    $badge.Font = Get-AstFont 'Segoe UI Semibold' 9 'Regular'
    $badge.TextAlign = 'MiddleCenter'
    if ($isAdmin) { $badge.Text = T 'badge_admin'; $badge.ForeColor = $t.Good }
    else          { $badge.Text = T 'badge_user';  $badge.ForeColor = $t.Warn }
    Set-AstTip $badge (T 'badge_tip')

    $headerLine = [System.Windows.Forms.Panel]::new()
    $headerLine.Dock = 'Bottom'
    $headerLine.Height = Sz 2
    $headerLine.BackColor = $t.Accent

    $header.Controls.Add($title)
    $header.Controls.Add($headerIcon)
    $header.Controls.Add($badge)
    if ($script:Settings['ExpertMode']) {
        $chip = [System.Windows.Forms.Label]::new()
        $chip.Dock = Get-AstEnd
        $chip.Width = Sz 90
        $chip.Font = Get-AstFont 'Segoe UI Semibold' 9 'Regular'
        $chip.TextAlign = 'MiddleCenter'
        $chip.ForeColor = $t.Purple
        $chip.Text = T 'chip_expert'
        Set-AstTip $chip (T 'chip_expert_tip')
        $header.Controls.Add($chip)
    }

    # Sidebar
    $sidebar = [System.Windows.Forms.Panel]::new()
    $sidebar.Dock = Get-AstStart
    $sidebar.Width = Sz 240
    $sidebar.BackColor = $t.Sidebar
    Set-AstDoubleBuffered $sidebar

    # Brand: logo tile + two-line name
    $brand = [System.Windows.Forms.Panel]::new()
    $brand.Dock = 'Top'
    $brand.Height = Sz 84
    $logoHost = [System.Windows.Forms.Panel]::new()
    $logoHost.Dock = Get-AstStart
    $logoHost.Width = Sz 78
    $logoHost.Padding = [System.Windows.Forms.Padding]::new((Sz 18), (Sz 20), (Sz 18), (Sz 20))
    $logo = New-AstIcon 'settings' 17 ([System.Drawing.Color]::White)
    $logo.Dock = 'Fill'
    $logo.BackColor = $t.Accent
    $logoHost.Controls.Add($logo)
    $brandSub = [System.Windows.Forms.Label]::new()
    $brandSub.Dock = 'Fill'
    $brandSub.Text = 'SYSTEM TOOLS'
    $brandSub.Font = Get-AstFont 'Segoe UI Semibold' 8.5 'Regular'
    $brandSub.ForeColor = $t.TextMuted
    $brandSub.TextAlign = 'TopLeft'
    $brandName = [System.Windows.Forms.Label]::new()
    $brandName.Dock = 'Top'
    $brandName.Height = Sz 46
    $brandName.Text = 'AYMEN'
    $brandName.Font = Get-AstFont 'Segoe UI Semibold' 17 'Regular'
    $brandName.ForeColor = $t.Text
    $brandName.TextAlign = 'BottomLeft'
    $brand.Controls.Add($brandSub)
    $brand.Controls.Add($brandName)
    $brand.Controls.Add($logoHost)

    $navFlow = [System.Windows.Forms.FlowLayoutPanel]::new()
    $navFlow.Dock = 'Fill'
    $navFlow.FlowDirection = 'TopDown'
    $navFlow.WrapContents = $false
    $navFlow.AutoScroll = $true
    $navFlow.BackColor = $t.Sidebar
    Set-AstDoubleBuffered $navFlow
    foreach ($p in $script:Pages) {
        $navFlow.Controls.Add((New-AstNavItem -Id $p.Id -Icon $p.Icon -Caption (T $p.TitleKey)))
    }
    $sidebar.Controls.Add($navFlow)
    $sidebar.Controls.Add($brand)

    # Status bar
    $status = [System.Windows.Forms.Label]::new()
    $status.Dock = 'Bottom'
    $status.Height = Sz 28
    $status.BackColor = $t.Sidebar
    $status.ForeColor = $t.TextMuted
    $status.Font = Get-AstFont 'Segoe UI' 8.5 'Regular'
    $status.TextAlign = 'MiddleLeft'
    $status.Padding = New-AstPad 14 0 14 0
    $script:UI.Status = $status

    # Docking order: Fill first, then header, sidebar, status bar (last added is docked first)
    $header.Controls.Add($headerLine)
    $f.Controls.Add($content)
    $f.Controls.Add($header)
    $f.Controls.Add($sidebar)
    $f.Controls.Add($status)

    $f.ResumeLayout($true)
    Show-AstPage $script:CurrentPage
}

function Initialize-AstMainForm {
    $g = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
    try { $script:Scale = [double]$g.DpiX / 96.0 } finally { $g.Dispose() }
    if ($script:Scale -lt 1) { $script:Scale = 1.0 }

    $f = [System.Windows.Forms.Form]::new()
    $f.StartPosition = 'CenterScreen'
    $f.Size = [System.Drawing.Size]::new((Sz 1240), (Sz 800))
    $f.MinimumSize = [System.Drawing.Size]::new((Sz 1100), (Sz 680))
    Set-AstDoubleBuffered $f
    $appIcon = New-AstAppIcon
    if ($appIcon) { $f.Icon = $appIcon }
    $f.Font = Get-AstFont 'Segoe UI' 9 'Regular'
    $f.Add_FormClosing({
        Invoke-AstPageCleanup
        try { Stop-AllAstTasks } catch { }
        Write-AstLog 'INFO' 'Application closed.'
    })
    $script:Form = $f

    Build-AstUI
}
