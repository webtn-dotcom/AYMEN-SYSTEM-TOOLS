# ============================================================
# Page.Misc.ps1 - Settings and Help pages
# ASCII-only file.
# ============================================================

$script:SetUI = @{}

function Invoke-AstApplySettings {
    $ui = $script:SetUI
    $li = $ui.LangCombo.SelectedIndex
    $ti = $ui.ThemeCombo.SelectedIndex
    if ($li -ge 0) { $script:Settings['Language'] = $ui.LangCodes[$li] }
    if ($ti -ge 0) { $script:Settings['Theme'] = $ui.ThemeCodes[$ti] }
    $script:Settings['ExpertMode'] = [bool]$ui.Expert.Checked
    Save-AstSettings
    Write-AstLog 'INFO' ("Settings applied: language={0}, theme={1}, expert={2}" -f $script:Settings['Language'], $script:Settings['Theme'], $script:Settings['ExpertMode'])
    # Rebuild the whole UI after this handler returns (new language, direction, colors, mode)
    $script:Form.BeginInvoke([System.Action]{ Build-AstUI }) | Out-Null
}

function Open-AstFolder {
    param([string]$Key)
    try { Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $script:Paths[$Key]) }
    catch { Write-AstLog 'WARN' ('Could not open folder: ' + $_.Exception.Message) }
}

function Build-AstPage-settings {
    param($Container)
    $stack = New-AstPage $Container 'desc_settings'

    $langs = @(Get-AstLanguageList)
    $langCodes = @($langs | ForEach-Object { $_.Code })
    $langNames = @($langs | ForEach-Object { $_.Name })
    $themeCodes = @('dark', 'light')
    $langIndex = [Array]::IndexOf($langCodes, [string]$script:Settings['Language'])
    if ($langIndex -lt 0) { $langIndex = 0 }
    $themeIndex = [Array]::IndexOf($themeCodes, [string]$script:Settings['Theme'])
    if ($themeIndex -lt 0) { $themeIndex = 0 }

    # --- Preferences ---
    $sec = New-AstSection (T 'sec_prefs') 'settings' 190 'Purple'
    $flow = New-AstFlow
    $lblL = New-AstLabel (T 'settings_language') -Muted
    $lblL.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 12), (Sz 8), 0)
    $cmbLang = New-AstCombo -Items $langNames -Index $langIndex -Width 170
    $lblT = New-AstLabel (T 'settings_theme') -Muted
    $lblT.Margin = [System.Windows.Forms.Padding]::new((Sz 10), (Sz 12), (Sz 8), 0)
    $cmbTheme = New-AstCombo -Items @((T 'theme_dark'), (T 'theme_light')) -Index $themeIndex -Width 150
    foreach ($c in @($lblL, $cmbLang, $lblT, $cmbTheme)) { $flow.Controls.Add($c) }
    $flow.SetFlowBreak($cmbTheme, $true)

    $chkExpert = New-AstCheck (T 'settings_expert') ([bool]$script:Settings['ExpertMode'])
    $flow.Controls.Add($chkExpert)
    $flow.SetFlowBreak($chkExpert, $true)
    $lblExp = New-AstLabel (T 'settings_expert_d') -Muted -Width 820
    $flow.Controls.Add($lblExp)
    $flow.SetFlowBreak($lblExp, $true)
    $btnApply = New-AstButton (T 'settings_apply') -Icon 'check' -Style primary -OnClick { Invoke-AstApplySettings }
    $flow.Controls.Add($btnApply)
    $sec.Body.Controls.Add($flow)
    Set-AstSectionAuto $sec $flow
    Add-AstRow $stack $sec.Panel
    $script:SetUI = @{ LangCombo = $cmbLang; ThemeCombo = $cmbTheme; Expert = $chkExpert; LangCodes = $langCodes; ThemeCodes = $themeCodes }

    # --- Rights and folders ---
    $sec2 = New-AstSection (T 'sec_access') 'lock' 130 'Warn'
    $f2 = New-AstFlow
    if (Test-AstAdmin) { $state = T 'settings_admin_yes' } else { $state = T 'settings_admin_no' }
    $lblState = New-AstLabel $state -Muted -Width 820
    $f2.Controls.Add($lblState)
    $f2.SetFlowBreak($lblState, $true)
    if (-not (Test-AstAdmin)) {
        $f2.Controls.Add((New-AstButton (T 'restart_admin') -Icon 'lock' -Style primary -OnClick { Invoke-AstRestartAdmin }))
    }
    $f2.Controls.Add((New-AstButton (T 'open_logs') -Icon 'folder' -OnClick { Open-AstFolder 'Logs' }))
    $f2.Controls.Add((New-AstButton (T 'open_reports') -Icon 'folder' -OnClick { Open-AstFolder 'Reports' }))
    $f2.Controls.Add((New-AstButton (T 'open_config') -Icon 'folder' -OnClick { Open-AstFolder 'Config' }))
    $sec2.Body.Controls.Add($f2)
    Set-AstSectionAuto $sec2 $f2
    Add-AstRow $stack $sec2.Panel

    # --- About ---
    $about = (T 'about_text') + "`n`n" + $script:AppName + '  v' + $script:AppVersion
    Add-AstRow $stack (New-AstInfoCard (T 'about_title') $about 'info' 'Sky')
}

function Build-AstPage-help {
    param($Container)
    $stack = New-AstPage $Container 'desc_help'
    $colors = @('Accent', 'Good', 'Bad', 'Warn', 'Teal', 'Purple')
    $icons  = @('home', 'settings', 'lock', 'lock', 'search', 'info')
    for ($i = 1; $i -le 6; $i++) {
        Add-AstRow $stack (New-AstInfoCard (T ('help_' + $i + '_t')) (T ('help_' + $i + '_x')) $icons[$i - 1] $colors[$i - 1]) 10
    }
    Add-AstRow $stack (New-AstTextBlock (T 'help_glossary') -Semi -Size 12) 4
    foreach ($g in @('sfc', 'dism', 'chkdsk', 'dns', 'gw', 'rp', 'startup', 'uac')) {
        Add-AstRow $stack (New-AstInfoCard (T ('gl_' + $g + '_t')) (T ('gl_' + $g + '_x')) 'help' 'Sky') 10
    }
}
