# ============================================================
# Page.Restore.ps1 - restore points and Windows backup shortcuts
# ASCII-only file.
# ============================================================

$script:RestoreCtx = $null

$script:RestoreListScript = {
    $types = @{ 0 = 'Application install'; 1 = 'Application uninstall'; 10 = 'Device driver install'; 12 = 'Modify settings'; 13 = 'Cancelled operation' }
    $rows = @()
    try {
        foreach ($rp in @(Get-ComputerRestorePoint -ErrorAction Stop)) {
            $when = ''
            try { $when = [System.Management.ManagementDateTimeConverter]::ToDateTime([string]$rp.CreationTime).ToString('yyyy-MM-dd HH:mm') } catch { }
            $type = [string]$rp.RestorePointType
            if ($types.ContainsKey([int]$rp.RestorePointType)) { $type = $types[[int]$rp.RestorePointType] }
            $rows += [pscustomobject]@{ Seq = [int]$rp.SequenceNumber; Description = [string]$rp.Description; Created = $when; Type = $type; Id = [string]$rp.SequenceNumber }
        }
    }
    catch { }
    , $rows
}

$script:CreateRestoreScript = {
    param($Description)
    try { Checkpoint-Computer -Description $Description -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop; 'OK' }
    catch { 'ERR: ' + $_.Exception.Message }
}

$script:EnableRestoreScript = {
    param($Drive)
    try { Enable-ComputerRestore -Drive $Drive -ErrorAction Stop; 'OK' }
    catch { 'ERR: ' + $_.Exception.Message }
}

function Build-AstPage-restore {
    param($Container)
    if (Test-AstAdmin) {
        Start-AstLoadAsync -Container $Container -Script $script:RestoreListScript -Render 'Show-AstRestore' -Text (T 'loading_restore')
    }
    else {
        # Listing restore points needs administrator rights: render the page without the list
        Show-AstRestore $Container @()
    }
}

function Show-AstRestore {
    param($Container, $Points)
    $expert = [bool]$script:Settings['ExpertMode']
    $isAdmin = Test-AstAdmin
    $stack = New-AstPage $Container 'desc_restore'
    $ctx = @{}
    $script:RestoreCtx = $ctx

    if (-not $isAdmin) {
        Add-AstRow $stack (New-AstBanner (T 'restore_admin_banner') 'warning' 'Warn' (T 'restart_admin') { Invoke-AstRestartAdmin })
    }

    # --- Create ---
    $secC = New-AstSection (T 'sec_create_rp') 'restore' 132 'Teal' -Spinner
    $flow = New-AstFlow
    $hint = New-AstLabel (T 'restore_hint') -Muted -Width 900
    $flow.Controls.Add($hint)
    $flow.SetFlowBreak($hint, $true)
    $txt = New-AstTextBox -Width 420
    $txt.Text = 'AYMEN SYSTEM TOOLS - ' + (Get-Date -Format 'yyyy-MM-dd HH:mm')
    $txt.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 6), (Sz 10), 0)
    $ctx.Desc = $txt
    $bCreate = New-AstButton (T 'restore_create') -Icon 'add' -Style primary -OnClick { Start-AstCreateRestore } -Tip (T 'restore_create_tip')
    $flow.Controls.Add($txt)
    $flow.Controls.Add($bCreate)
    $ctx.Create = $bCreate
    $ctx.Spinner = $secC.Spinner
    $secC.Spinner.Visible = $false
    if ($expert) {
        $flow.SetFlowBreak($bCreate, $true)
        $bEnable = New-AstButton (T 'restore_enable') -Icon 'check' -OnClick { Start-AstEnableRestore } -Tip (T 'restore_enable_tip')
        $flow.Controls.Add($bEnable)
    }
    $secC.Body.Controls.Add($flow)
    Set-AstSectionAuto $secC $flow
    Add-AstRow $stack $secC.Panel

    # --- List ---
    $secL = New-AstSection (T 'sec_rp_list') 'history' 210 'Purple'
    $count = New-AstLabel '' -Muted
    $count.Margin = [System.Windows.Forms.Padding]::new((Sz 6), (Sz 14), 0, 0)
    $cols = @(
        @{ Header = 'col_seq'; Width = 80; Prop = 'Seq' }, @{ Header = 'col_desc'; Width = 430; Prop = 'Description' },
        @{ Header = 'col_created'; Width = 170; Prop = 'Created' }, @{ Header = 'col_type'; Width = 190; Prop = 'Type' })
    $list = New-AstDataList -Columns $cols -KeyProp 'Id' -CountKey 'count_items' -CountLabel $count
    $list.Tag.SortCol = 0
    $list.Tag.SortAsc = $false
    if ($isAdmin) {
        Set-AstDataList $list @($Points | Where-Object { $_ -and $_.Id })
    }
    else { $count.Text = T 'restore_need_admin' }
    $toolbar = New-AstToolbar
    $toolbar.Controls.Add((New-AstButton (T 'refresh') -Icon 'refresh' -OnClick {
        $script:Form.BeginInvoke([System.Action]{ Show-AstPage 'restore' }) | Out-Null
    }))
    $toolbar.Controls.Add($count)
    $secL.Body.Controls.Add($list)
    $secL.Body.Controls.Add($toolbar)
    Add-AstRow $stack $secL.Panel

    # --- Windows features ---
    $secW = New-AstSection (T 'sec_rp_tools') 'link' 70 'Accent'
    $wf = New-AstFlow
    $wf.Controls.Add((New-AstButton (T 'restore_wizard') -Icon 'restore' -OnClick { Start-Process -FilePath 'rstrui.exe' } -Tip (T 'restore_wizard_tip')))
    $wf.Controls.Add((New-AstButton (T 'restore_protection') -Icon 'settings' -OnClick { Start-Process -FilePath 'SystemPropertiesProtection.exe' } -Tip (T 'restore_protection_tip')))
    $wf.Controls.Add((New-AstButton (T 'restore_backup') -Icon 'save' -OnClick { Start-Process -FilePath 'ms-settings:backup' } -Tip (T 'restore_backup_tip')))
    $secW.Body.Controls.Add($wf)
    Set-AstSectionAuto $secW $wf
    Add-AstRow $stack $secW.Panel

    Add-AstRow $stack (New-AstInfoCard (T 'restore_note_t') (T 'restore_note_x') 'info' 'Sky')
}

function Start-AstRestoreJob {
    param([scriptblock]$Script, [object[]]$ArgumentList)
    $ctx = $script:RestoreCtx
    $ctx.Create.Enabled = $false
    $ctx.Spinner.Visible = $true
    Start-AstBackground -ScriptBlock $Script -ArgumentList $ArgumentList -State $ctx -OnComplete {
        param($res, $err, $s) Complete-AstRestoreJob $res $err $s
    }
}

function Complete-AstRestoreJob {
    param($Result, $ErrorText, $Ctx)
    if (-not $Ctx -or $Ctx.Create.IsDisposed) { return }
    $Ctx.Create.Enabled = $true
    $Ctx.Spinner.Visible = $false
    $msg = [string](@($Result)[0])
    if ($ErrorText -and -not $msg) { $msg = 'ERR: ' + $ErrorText }
    if ($msg -like 'ERR:*') {
        Write-AstLog 'WARN' ('Restore point operation failed: ' + $msg)
        [void](Show-AstMessage ((T 'restore_failed') -f $msg.Substring(4).Trim()) (T 'sec_create_rp') 'OK' 'Warning')
    }
    else {
        Write-AstLog 'INFO' 'Restore point operation succeeded.'
        [void](Show-AstMessage (T 'restore_ok') (T 'sec_create_rp') 'OK' 'Information')
        $script:Form.BeginInvoke([System.Action]{ Show-AstPage 'restore' }) | Out-Null
    }
}

function Start-AstCreateRestore {
    $ctx = $script:RestoreCtx
    if (-not (Assert-AstAdmin)) { return }
    $desc = $ctx.Desc.Text.Trim()
    if ($desc.Length -lt 3) { [void](Show-AstMessage (T 'restore_desc_short') (T 'sec_create_rp') 'OK' 'Warning'); return }
    if ((Show-AstMessage (T 'restore_confirm') (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    Write-AstLog 'INFO' ('Creating restore point: ' + $desc)
    Start-AstRestoreJob $script:CreateRestoreScript @($desc)
}

function Start-AstEnableRestore {
    if (-not (Assert-AstAdmin)) { return }
    if ((Show-AstMessage (T 'restore_enable_confirm') (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    Write-AstLog 'INFO' 'Enabling System Protection on the system drive.'
    Start-AstRestoreJob $script:EnableRestoreScript @(($env:SystemDrive + '\'))
}
