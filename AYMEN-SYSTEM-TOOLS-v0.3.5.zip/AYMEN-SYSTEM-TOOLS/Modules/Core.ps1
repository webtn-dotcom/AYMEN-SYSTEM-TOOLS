# ============================================================
# Core.ps1 - paths, logging, settings, languages, themes, icons, system summary
# ASCII-only file (Windows PowerShell 5.1 reads BOM-less files as ANSI).
# ============================================================

$script:AppName    = 'AYMEN SYSTEM TOOLS'
$script:AppVersion = '0.3.5'
$script:Strings    = @{}
$script:IsRtl      = $false
$script:ExePath    = $null
if (-not $script:EmbeddedLang) { $script:EmbeddedLang = @{} }   # filled by Build-Exe.ps1 in the single-file EXE

# ---------- Paths ----------
function Initialize-AstPaths {
    param([Parameter(Mandatory)][string]$Root, [string]$DataRoot = '')
    if (-not $DataRoot) { $DataRoot = $Root }
    $script:Paths = @{
        Root    = $Root
        Config  = Join-Path $DataRoot 'Config'
        Lang    = Join-Path $Root 'Lang'
        Logs    = Join-Path $DataRoot 'Logs'
        Reports = Join-Path $DataRoot 'Reports'
        Icons   = Join-Path $DataRoot 'Icons'
    }
    foreach ($key in 'Config', 'Logs', 'Reports', 'Icons') {
        if (-not (Test-Path -LiteralPath $script:Paths[$key])) {
            New-Item -ItemType Directory -Path $script:Paths[$key] -Force | Out-Null
        }
    }
    $script:Paths['Settings'] = Join-Path $script:Paths['Config'] 'settings.json'
}

# ---------- Logging ----------
function Write-AstLog {
    param(
        [ValidateSet('INFO', 'WARN', 'ERROR')][string]$Level = 'INFO',
        [Parameter(Mandatory)][string]$Message
    )
    try {
        $file = Join-Path $script:Paths['Logs'] ('ast_{0}.log' -f (Get-Date -Format 'yyyyMMdd'))
        $line = '{0} [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
        Add-Content -LiteralPath $file -Value $line -Encoding UTF8
    }
    catch { }
}

# ---------- Privileges ----------
function Test-AstAdmin {
    try {
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch { return $false }
}

function Restart-AstAsAdmin {
    try {
        if ($script:ExePath) {
            Start-Process -FilePath $script:ExePath -Verb RunAs -ErrorAction Stop
        }
        else {
            $scriptPath = Join-Path $script:Paths['Root'] 'AymenSystemTools.ps1'
            $argLine = '-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "{0}"' -f $scriptPath
            Start-Process -FilePath 'powershell.exe' -ArgumentList $argLine -Verb RunAs -ErrorAction Stop
        }
        Write-AstLog 'INFO' 'Restart as administrator requested.'
        return $true
    }
    catch {
        Write-AstLog 'WARN' ('Restart as administrator failed or cancelled: ' + $_.Exception.Message)
        return $false
    }
}

# ---------- Settings ----------
function Get-DefaultSettings {
    return @{ Language = 'en'; Theme = 'dark'; ExpertMode = $false }
}

function Import-AstSettings {
    $settings = Get-DefaultSettings
    if (Test-Path -LiteralPath $script:Paths['Settings']) {
        try {
            $raw = Get-Content -LiteralPath $script:Paths['Settings'] -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($prop in $raw.PSObject.Properties) {
                if ($settings.ContainsKey($prop.Name)) { $settings[$prop.Name] = $prop.Value }
            }
        }
        catch {
            Write-AstLog 'WARN' ('settings.json unreadable, defaults used: ' + $_.Exception.Message)
        }
    }
    if ($settings['Language'] -notin 'en', 'fr', 'ar') { $settings['Language'] = 'en' }
    if ($settings['Theme'] -notin 'dark', 'light') { $settings['Theme'] = 'dark' }
    $settings['ExpertMode'] = [bool]$settings['ExpertMode']
    $script:Settings = $settings
}

function Save-AstSettings {
    try {
        $script:Settings | ConvertTo-Json | Set-Content -LiteralPath $script:Paths['Settings'] -Encoding UTF8
    }
    catch {
        Write-AstLog 'ERROR' ('Could not save settings: ' + $_.Exception.Message)
    }
}

# ---------- Languages ----------
# A language file next to the program wins; otherwise the copy embedded in the EXE is used.
function Get-AstLangText {
    param([string]$Code)
    $file = Join-Path $script:Paths['Lang'] ($Code + '.json')
    if (Test-Path -LiteralPath $file) { return [System.IO.File]::ReadAllText($file, [System.Text.Encoding]::UTF8) }
    if ($script:EmbeddedLang.ContainsKey($Code)) {
        return [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String([string]$script:EmbeddedLang[$Code]))
    }
    return $null
}

# English is always loaded first as the fallback, then the selected language overrides it.
function Import-AstLanguage {
    param([string]$Code = 'en')

    $strings = @{}
    foreach ($c in (@('en', $Code) | Select-Object -Unique)) {
        try {
            $text = Get-AstLangText $c
            if ($text) {
                $obj = $text | ConvertFrom-Json
                foreach ($prop in $obj.PSObject.Properties) { $strings[$prop.Name] = [string]$prop.Value }
            }
        }
        catch {
            Write-AstLog 'ERROR' ("Language '{0}' unreadable: {1}" -f $c, $_.Exception.Message)
        }
    }
    $script:Strings = $strings
    $script:IsRtl = ($Code -eq 'ar')
}

function T {
    param([Parameter(Mandatory)][string]$Key)
    if ($script:Strings.ContainsKey($Key)) { return $script:Strings[$Key] }
    return $Key
}

function Get-AstLanguageList {
    $list = @()
    foreach ($code in 'en', 'fr', 'ar') {
        $name = $code
        try {
            $text = Get-AstLangText $code
            if ($text) { $name = [string](($text | ConvertFrom-Json).lang_name) }
        }
        catch { }
        $list += [pscustomobject]@{ Code = $code; Name = $name }
    }
    return $list
}

# ---------- Themes ----------
function Get-AstTheme {
    param([string]$Name = 'dark')

    if ($Name -eq 'light') {
        $hex = @{
            Back = '#F1F4F9'; Surface = '#FFFFFF'; Surface2 = '#EEF2F7'; Sidebar = '#FFFFFF'; SidebarHover = '#E8EDF4'
            Text = '#111827'; TextMuted = '#5B6475'; Accent = '#2563EB'; AccentText = '#FFFFFF'
            Border = '#D5DBE5'; Good = '#16A34A'; Warn = '#D97706'; Bad = '#DC2626'
            Purple = '#7C3AED'; Teal = '#0D9488'; Pink = '#DB2777'; Sky = '#0284C7'
        }
    }
    else {
        $hex = @{
            Back = '#0F1623'; Surface = '#1A2332'; Surface2 = '#243044'; Sidebar = '#0B111C'; SidebarHover = '#182235'
            Text = '#F3F4F6'; TextMuted = '#9AA4B5'; Accent = '#3B82F6'; AccentText = '#FFFFFF'
            Border = '#2F3B50'; Good = '#22C55E'; Warn = '#F59E0B'; Bad = '#EF4444'
            Purple = '#8B5CF6'; Teal = '#14B8A6'; Pink = '#EC4899'; Sky = '#38BDF8'
        }
    }
    $theme = @{}
    foreach ($key in @($hex.Keys)) {
        $theme[$key] = [System.Drawing.ColorTranslator]::FromHtml($hex[$key])
    }
    return $theme
}

# ---------- Icons (Segoe MDL2 Assets glyph codes, present on Windows 10 and 11) ----------
$script:IconMap = @{
    home = 0xE80F; pulse = 0xE9D9; sync = 0xE895; globe = 0xE774; power = 0xE7E8; drive = 0xEDA2
    lock = 0xE72E; search = 0xE721; apps = 0xE71D; restore = 0xE777; settings = 0xE713; help = 0xE897
    trash = 0xE74D; save = 0xE74E; download = 0xE896; upload = 0xE898; refresh = 0xE72C; check = 0xE73E
    cancel = 0xE711; warning = 0xE7BA; info = 0xE946; folder = 0xE838; play = 0xE768; stop = 0xE71A
    copy = 0xE8C8; history = 0xE81C; link = 0xE71B; clock = 0xE916; page = 0xE7C3; wifi = 0xE701
    cloud = 0xE753; cmd = 0xE756; edit = 0xE70F; add = 0xE710; more = 0xE712; filter = 0xE71C
    back = 0xE72B; contact = 0xE77B; devices = 0xE772; code = 0xE943; pin = 0xE718; star = 0xE734
}

function Get-AstGlyph {
    param([string]$Name)
    if ($script:IconMap.ContainsKey($Name)) { return [string][char]$script:IconMap[$Name] }
    return [string][char]0xE946
}

# ---------- System information (read-only) ----------
# Self-contained scriptblock so it can run in a background runspace as well as in-process.
$script:SummaryScript = {
    $cs   = Get-CimInstance -ClassName Win32_ComputerSystem
    $os   = Get-CimInstance -ClassName Win32_OperatingSystem
    $cpu  = Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1
    $logicalDisks = @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3')

    $ramTotal = [double]$cs.TotalPhysicalMemory / 1GB
    $ramFree  = [double]$os.FreePhysicalMemory * 1KB / 1GB
    $ramUsed  = $ramTotal - $ramFree
    $ramPct   = 0
    if ($ramTotal -gt 0) { $ramPct = [int][math]::Round($ramUsed / $ramTotal * 100) }

    $disks = @()
    foreach ($d in $logicalDisks) {
        if (-not $d.Size) { continue }
        $size = [double]$d.Size
        $free = [double]$d.FreeSpace
        $disks += [pscustomobject]@{
            Name        = [string]$d.DeviceID
            Label       = [string]$d.VolumeName
            SizeGB      = [math]::Round($size / 1GB, 1)
            FreeGB      = [math]::Round($free / 1GB, 1)
            UsedPercent = [int][math]::Round(($size - $free) / $size * 100)
            FreePercent = [int][math]::Round($free / $size * 100)
        }
    }

    # Number of programs that start with Windows (registry Run keys)
    $startupCount = 0
    foreach ($key in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run') {
        try {
            $props = @((Get-ItemProperty -Path $key -ErrorAction Stop).PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })
            $startupCount += $props.Count
        }
        catch { }
    }

    # Protection state (may be unavailable with third-party antivirus)
    $defender = 'unknown'
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        if ($mp.RealTimeProtectionEnabled) { $defender = 'on' } else { $defender = 'off' }
    }
    catch { }
    $firewall = 'unknown'
    try {
        $profiles = @(Get-NetFirewallProfile -ErrorAction Stop)
        $off = @($profiles | Where-Object { [string]$_.Enabled -eq 'False' })
        if ($off.Count -eq 0) { $firewall = 'on' } else { $firewall = 'off' }
    }
    catch { }

    $pending = $false
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $pending = $true }
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $pending = $true }

    $admin = $false
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $admin = (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch { }

    $sysDrive = $env:SystemDrive
    $sysDisk = $disks | Where-Object { $_.Name -eq $sysDrive } | Select-Object -First 1

    [pscustomobject]@{
        ComputerName  = $env:COMPUTERNAME
        UserName      = ('{0}\{1}' -f $env:USERDOMAIN, $env:USERNAME)
        IsAdmin       = $admin
        Model         = (([string]$cs.Manufacturer + ' ' + [string]$cs.Model).Trim())
        OsName        = (([string]$os.Caption) -replace '^Microsoft\s+', '').Trim()
        OsArch        = [string]$os.OSArchitecture
        OsBuild       = [string]$os.BuildNumber
        CpuName       = (([string]$cpu.Name) -replace '\s+', ' ').Trim()
        CpuThreads    = [int]$cpu.NumberOfLogicalProcessors
        RamTotalGB    = [math]::Round($ramTotal, 1)
        RamUsedGB     = [math]::Round($ramUsed, 1)
        RamPercent    = $ramPct
        Uptime        = ((Get-Date) - $os.LastBootUpTime)
        Disks         = $disks
        SystemDisk    = $sysDisk
        StartupCount  = $startupCount
        Defender      = $defender
        Firewall      = $firewall
        PendingReboot = $pending
    }
}

function Get-AstSystemSummary { return (& $script:SummaryScript) }

function Format-AstUptime {
    param([TimeSpan]$Span)
    return ((T 'uptime_format') -f [int][math]::Floor($Span.TotalDays), $Span.Hours, $Span.Minutes)
}

function Format-AstBytes {
    param([double]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N1} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N0} KB' -f ($Bytes / 1KB)) }
    return ('{0:N0} B' -f $Bytes)
}
