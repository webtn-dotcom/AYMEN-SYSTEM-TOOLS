# ============================================================
# Main.ps1 - application start (shared by the .ps1 entry script, the single-file EXE and the launcher)
# ASCII-only file.
# ============================================================

function Get-AstDataRoot {
    # Config, Logs and Reports live next to the program; if that folder is read-only
    # (for example Program Files) they move to %LOCALAPPDATA%\AYMEN-SYSTEM-TOOLS.
    param([string]$Root)
    try {
        $probe = Join-Path $Root 'Logs'
        if (-not (Test-Path -LiteralPath $probe)) { New-Item -ItemType Directory -Path $probe -Force -ErrorAction Stop | Out-Null }
        $testFile = Join-Path $probe ('.w' + [guid]::NewGuid().ToString('N'))
        [System.IO.File]::WriteAllText($testFile, 'x')
        Remove-Item -LiteralPath $testFile -Force -ErrorAction SilentlyContinue
        return $Root
    }
    catch {
        $alt = Join-Path $env:LOCALAPPDATA 'AYMEN-SYSTEM-TOOLS'
        New-Item -ItemType Directory -Path $alt -Force | Out-Null
        return $alt
    }
}

function Start-AstApplication {
    param([Parameter(Mandatory)][string]$Root, [string[]]$LoadErrors = @())

    $ErrorActionPreference = 'Stop'
    try {
        # Is this process a compiled EXE (PS2EXE / launcher) or powershell.exe running the script?
        $procPath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
        $script:ExePath = $null
        if ([System.IO.Path]::GetFileName($procPath) -notmatch '^(powershell|pwsh|powershell_ise)\.exe$') { $script:ExePath = $procPath }

        Initialize-AstPaths -Root $Root -DataRoot (Get-AstDataRoot $Root)
        Import-AstSettings
        foreach ($err in $LoadErrors) { Write-AstLog 'ERROR' ('Module load problem: ' + $err) }

        [System.Windows.Forms.Application]::add_ThreadException({
            param($sender, $e)
            Write-AstLog 'ERROR' ('Unhandled UI exception: ' + $e.Exception.ToString())
        })

        Write-AstLog 'INFO' ("=== {0} v{1} started | admin={2} | lang={3} | theme={4} | exe={5}" -f $script:AppName, $script:AppVersion, (Test-AstAdmin), $script:Settings['Language'], $script:Settings['Theme'], [bool]$script:ExePath)

        Initialize-AstMainForm

        # From here on, errors inside UI event handlers are logged instead of aborting the app
        $ErrorActionPreference = 'Continue'
        [System.Windows.Forms.Application]::Run($script:Form)
    }
    catch {
        try { Write-AstLog 'ERROR' ('Fatal: ' + $_.Exception.ToString()) } catch { }
        [void][System.Windows.Forms.MessageBox]::Show(
            ("AYMEN SYSTEM TOOLS could not start.`n`n" + $_.Exception.Message),
            'AYMEN SYSTEM TOOLS',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error)
    }
}
