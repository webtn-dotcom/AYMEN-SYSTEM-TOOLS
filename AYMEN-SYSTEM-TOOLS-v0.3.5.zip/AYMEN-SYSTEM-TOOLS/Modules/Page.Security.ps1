# ============================================================
# Page.Security.ps1 - security checks (read-only) + safe actions (update signatures, quick scan)
# ASCII-only file. This page never disables any protection.
# ============================================================

$script:SecCtx = $null

$script:SecurityScript = {
    $defender = 'unknown'; $sigDays = -1; $sigDate = ''
    try {
        $mp = Get-MpComputerStatus -ErrorAction Stop
        if ($mp.RealTimeProtectionEnabled) { $defender = 'on' } else { $defender = 'off' }
        $age = (Get-Date) - $mp.AntivirusSignatureLastUpdated
        $sigDays = [int][math]::Floor($age.TotalDays)
        $sigDate = $mp.AntivirusSignatureLastUpdated.ToString('yyyy-MM-dd')
    }
    catch { }
    $others = @()
    try {
        $others = @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop |
            ForEach-Object { [string]$_.displayName } | Where-Object { $_ -notlike '*Defender*' })
    }
    catch { }

    $firewall = 'unknown'
    try {
        $profiles = @(Get-NetFirewallProfile -ErrorAction Stop)
        $off = @($profiles | Where-Object { [string]$_.Enabled -eq 'False' })
        if ($off.Count -eq 0) { $firewall = 'on' } else { $firewall = 'off' }
    }
    catch { }

    $uac = 'unknown'
    try { if ((Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name EnableLUA -ErrorAction Stop).EnableLUA -eq 1) { $uac = 'on' } else { $uac = 'off' } } catch { }
    $rdp = 'unknown'
    try { if ((Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -ErrorAction Stop).fDenyTSConnections -eq 1) { $rdp = 'off' } else { $rdp = 'on' } } catch { }
    $secureBoot = 'unknown'
    try { if (Confirm-SecureBootUEFI -ErrorAction Stop) { $secureBoot = 'on' } else { $secureBoot = 'off' } } catch { }
    $bitlocker = 'unknown'
    try {
        $vol = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
        if ([string]$vol.ProtectionStatus -eq 'On') { $bitlocker = 'on' } else { $bitlocker = 'off' }
    }
    catch { }

    $updateDays = -1
    try {
        $hf = Get-HotFix -ErrorAction Stop | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 1
        if ($hf) { $updateDays = [int][math]::Floor(((Get-Date) - $hf.InstalledOn).TotalDays) }
    }
    catch { }
    $pending = $false
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $pending = $true }
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $pending = $true }

    [pscustomobject]@{
        Defender = $defender; SigDays = $sigDays; SigDate = $sigDate; OtherAv = ($others -join ', ')
        Firewall = $firewall; Uac = $uac; Rdp = $rdp; SecureBoot = $secureBoot; BitLocker = $bitlocker
        UpdateDays = $updateDays; Pending = $pending
    }
}

$script:DefenderUpdateScript = {
    param($Shared)
    $Shared['Status'] = 'Update-MpSignature'
    try { Update-MpSignature -ErrorAction Stop; [void]$Shared['Lines'].Add('OK') }
    catch { [void]$Shared['Lines'].Add('ERROR: ' + $_.Exception.Message); $Shared['ExitCode'] = 1 }
}

$script:DefenderScanScript = {
    param($Shared)
    $Shared['Status'] = 'Start-MpScan (QuickScan)'
    try { Start-MpScan -ScanType QuickScan -ErrorAction Stop; [void]$Shared['Lines'].Add('OK') }
    catch { [void]$Shared['Lines'].Add('ERROR: ' + $_.Exception.Message); $Shared['ExitCode'] = 1 }
}

function Add-AstSecurityCheck {
    param($Grid, $List, [string]$TitleKey, [string]$ValueText, [string]$Tone)
    $card = New-AstStatCard (T $TitleKey) $ValueText
    Set-AstCardTone $card $Tone
    $Grid.Controls.Add($card)
    [void]$List.Add($Tone)
}

function Build-AstPage-security {
    param($Container)
    Start-AstLoadAsync -Container $Container -Script $script:SecurityScript -Render 'Show-AstSecurity' -Text (T 'loading_security')
}

function Show-AstSecurity {
    param($Container, $D)
    $stack = New-AstPage $Container 'desc_security'
    $lock = New-Object System.Collections.ArrayList
    $ctx = @{ Lock = $lock }
    $script:SecCtx = $ctx

    $grid = New-AstGrid -TileWidth 300 -TileHeight 100
    $tones = New-Object System.Collections.ArrayList

    # Antivirus
    if ($D.Defender -eq 'on') { Add-AstSecurityCheck $grid $tones 'chk_av' (T 'v_defender_on') 'good' }
    elseif ($D.OtherAv) { Add-AstSecurityCheck $grid $tones 'chk_av' ((T 'v_other_av') -f $D.OtherAv) 'good' }
    elseif ($D.Defender -eq 'off') { Add-AstSecurityCheck $grid $tones 'chk_av' (T 'v_defender_off') 'bad' }
    else { Add-AstSecurityCheck $grid $tones 'chk_av' (T 'v_unknown') 'muted' }
    # Signatures
    if ($D.SigDays -ge 0) {
        $tone = 'good'
        if ($D.SigDays -gt 7) { $tone = 'bad' } elseif ($D.SigDays -gt 3) { $tone = 'warn' }
        Add-AstSecurityCheck $grid $tones 'chk_sig' ((T 'v_days_ago') -f $D.SigDays, $D.SigDate) $tone
    }
    else { Add-AstSecurityCheck $grid $tones 'chk_sig' (T 'v_unknown') 'muted' }
    # Firewall
    if ($D.Firewall -eq 'on') { Add-AstSecurityCheck $grid $tones 'chk_fw' (T 'v_on') 'good' }
    elseif ($D.Firewall -eq 'off') { Add-AstSecurityCheck $grid $tones 'chk_fw' (T 'v_fw_partial') 'bad' }
    else { Add-AstSecurityCheck $grid $tones 'chk_fw' (T 'v_unknown') 'muted' }
    # UAC
    if ($D.Uac -eq 'on') { Add-AstSecurityCheck $grid $tones 'chk_uac' (T 'v_on') 'good' }
    elseif ($D.Uac -eq 'off') { Add-AstSecurityCheck $grid $tones 'chk_uac' (T 'v_off') 'bad' }
    else { Add-AstSecurityCheck $grid $tones 'chk_uac' (T 'v_unknown') 'muted' }
    # Remote Desktop
    if ($D.Rdp -eq 'off') { Add-AstSecurityCheck $grid $tones 'chk_rdp' (T 'v_rdp_off') 'good' }
    elseif ($D.Rdp -eq 'on') { Add-AstSecurityCheck $grid $tones 'chk_rdp' (T 'v_rdp_on') 'warn' }
    else { Add-AstSecurityCheck $grid $tones 'chk_rdp' (T 'v_unknown') 'muted' }
    # Secure Boot
    if ($D.SecureBoot -eq 'on') { Add-AstSecurityCheck $grid $tones 'chk_sb' (T 'v_on') 'good' }
    elseif ($D.SecureBoot -eq 'off') { Add-AstSecurityCheck $grid $tones 'chk_sb' (T 'v_off') 'warn' }
    else { Add-AstSecurityCheck $grid $tones 'chk_sb' (T 'v_unknown') 'muted' }
    # Windows updates
    if ($D.UpdateDays -ge 0) {
        $tone = 'good'
        if ($D.UpdateDays -gt 90) { $tone = 'bad' } elseif ($D.UpdateDays -gt 35) { $tone = 'warn' }
        Add-AstSecurityCheck $grid $tones 'chk_upd' ((T 'v_updated_days') -f $D.UpdateDays) $tone
    }
    else { Add-AstSecurityCheck $grid $tones 'chk_upd' (T 'v_unknown') 'muted' }
    # Pending restart
    if ($D.Pending) { Add-AstSecurityCheck $grid $tones 'chk_reboot' (T 'v_reboot_yes') 'warn' }
    else { Add-AstSecurityCheck $grid $tones 'chk_reboot' (T 'v_reboot_no') 'good' }
    # BitLocker (informational)
    if ($D.BitLocker -eq 'on') { Add-AstSecurityCheck $grid $tones 'chk_bl' (T 'v_on') 'good' }
    elseif ($D.BitLocker -eq 'off') { Add-AstSecurityCheck $grid $tones 'chk_bl' (T 'v_off') 'muted' }
    else { Add-AstSecurityCheck $grid $tones 'chk_bl' (T 'v_need_admin') 'muted' }

    $good = @($tones | Where-Object { $_ -eq 'good' }).Count
    $counted = @($tones | Where-Object { $_ -ne 'muted' }).Count
    $score = 100
    if ($counted -gt 0) { $score = [int][math]::Round($good / $counted * 100) }
    $style = Get-AstScoreStyle $score
    $problems = @($tones | Where-Object { $_ -eq 'bad' -or $_ -eq 'warn' }).Count
    if ($problems -eq 0) { $sub = T 'sec_all_good' } else { $sub = (T 'sec_problems') -f $problems }
    Add-AstRow $stack (New-AstHeroBanner $score (T $style.Key) $sub -Refresh)
    Add-AstRow $stack (New-AstTextBlock (T 'sec_status') -Semi -Size 12) 4
    Add-AstRow $stack $grid

    # --- Safe actions ---
    $secA = New-AstSection (T 'sec_actions') 'lock' 124 'Bad'
    $flow = New-AstFlow
    $hint = New-AstLabel (T 'sec_actions_hint') -Muted -Width 900
    $flow.Controls.Add($hint)
    $flow.SetFlowBreak($hint, $true)
    $b1 = New-AstButton (T 'sec_update_sig') -Icon 'download' -Style primary -OnClick { Start-AstDefenderUpdate } -Tip (T 'sec_update_sig_tip')
    $b2 = New-AstButton (T 'sec_quick_scan') -Icon 'search' -OnClick { Start-AstDefenderScan } -Tip (T 'sec_quick_scan_tip')
    $b3 = New-AstButton (T 'sec_open_security') -Icon 'lock' -OnClick { Start-Process -FilePath 'windowsdefender:' }
    $b4 = New-AstButton (T 'sec_open_fw') -Icon 'link' -OnClick { Start-Process -FilePath 'wf.msc' }
    $b5 = New-AstButton (T 'fix_update') -Icon 'download' -OnClick { Start-Process -FilePath 'ms-settings:windowsupdate' }
    foreach ($b in @($b1, $b2, $b3, $b4, $b5)) { $flow.Controls.Add($b) }
    [void]$lock.Add($b1); [void]$lock.Add($b2)
    $secA.Body.Controls.Add($flow)
    Set-AstSectionAuto $secA $flow
    Add-AstRow $stack $secA.Panel

    $secO = New-AstSection (T 'sec_output') 'cmd' 220 'Sky'
    $console = New-AstConsole -Key 'security'
    $console.Panel.Dock = 'Fill'
    $secO.Body.Controls.Add($console.Panel)
    Add-AstRow $stack $secO.Panel
    $ctx.Console = $console
    Connect-AstTask 'security' $console $lock
}

function Start-AstDefenderUpdate {
    $ctx = $script:SecCtx
    if (-not $ctx -or -not (Assert-AstAdmin)) { return }
    Start-AstTask -Key 'security' -Console $ctx.Console -Script $script:DefenderUpdateScript -Lock $ctx.Lock
}
function Start-AstDefenderScan {
    $ctx = $script:SecCtx
    if (-not $ctx -or -not (Assert-AstAdmin)) { return }
    if ((Show-AstMessage (T 'sec_scan_confirm') (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    Start-AstTask -Key 'security' -Console $ctx.Console -Script $script:DefenderScanScript -Lock $ctx.Lock
}
