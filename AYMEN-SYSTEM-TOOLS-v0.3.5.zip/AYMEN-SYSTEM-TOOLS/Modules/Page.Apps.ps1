# ============================================================
# Page.Apps.ps1 - "Apps & Startup": startup programs, Windows services, installed programs
# ASCII-only file.
# Startup items are enabled/disabled the same way Task Manager does it (StartupApproved registry
# values), so nothing is deleted and every change is reversible.
# ============================================================

$script:AppsCtx = $null

# Services that must never be stopped, restarted or disabled from this tool
$script:ProtectedServices = @(
    'RpcSs', 'RpcEptMapper', 'DcomLaunch', 'BrokerInfrastructure', 'SamSs', 'Winmgmt', 'EventLog',
    'PlugPlay', 'Power', 'ProfSvc', 'CryptSvc', 'gpsvc', 'LanmanWorkstation', 'mpssvc', 'WinDefend',
    'Schedule', 'SystemEventsBroker', 'TrustedInstaller', 'LSM', 'Dhcp', 'Dnscache', 'nsi', 'BFE',
    'TermService', 'UserManager', 'CoreMessagingRegistrar', 'StateRepository', 'Themes', 'AudioEndpointBuilder'
)

# ---------- Background scripts ----------
$script:StartupScript = {
    function Get-Approved {
        param($Path, $Name)
        try {
            $v = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name
            if ($v -is [byte[]] -and $v.Length -gt 0) { return (($v[0] -band 1) -eq 0) }
        }
        catch { }
        return $true
    }
    $base = 'Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved'
    $runKeys = @(
        @{ Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'; Approved = ('HKCU:\' + $base + '\Run'); Src = 'HKCU Run'; Hive = 'HKCU' },
        @{ Path = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'; Approved = ('HKLM:\' + $base + '\Run'); Src = 'HKLM Run'; Hive = 'HKLM' },
        @{ Path = 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'; Approved = ('HKLM:\' + $base + '\Run32'); Src = 'HKLM Run (32-bit)'; Hive = 'HKLM' }
    )
    foreach ($k in $runKeys) {
        try {
            $props = @((Get-ItemProperty -Path $k.Path -ErrorAction Stop).PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })
            foreach ($p in $props) {
                [pscustomobject]@{
                    Name = [string]$p.Name; Command = [string]$p.Value; Source = [string]$k.Src
                    Enabled = [bool](Get-Approved $k.Approved $p.Name); Approved = [string]$k.Approved
                    Hive = [string]$k.Hive; Id = ([string]$k.Src + '|' + [string]$p.Name)
                }
            }
        }
        catch { }
    }
    $folders = @(
        @{ Path = (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'); Approved = ('HKCU:\' + $base + '\StartupFolder'); Src = 'Startup folder (user)'; Hive = 'HKCU' },
        @{ Path = (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp'); Approved = ('HKLM:\' + $base + '\StartupFolder'); Src = 'Startup folder (all users)'; Hive = 'HKLM' }
    )
    foreach ($f in $folders) {
        if (-not (Test-Path -LiteralPath $f.Path)) { continue }
        foreach ($file in @(Get-ChildItem -LiteralPath $f.Path -Force -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'desktop.ini' })) {
            [pscustomobject]@{
                Name = [string]$file.Name; Command = [string]$file.FullName; Source = [string]$f.Src
                Enabled = [bool](Get-Approved $f.Approved $file.Name); Approved = [string]$f.Approved
                Hive = [string]$f.Hive; Id = ([string]$f.Src + '|' + [string]$file.Name)
            }
        }
    }
}

$script:ServicesScript = {
    foreach ($s in (Get-CimInstance -ClassName Win32_Service)) {
        $tone = 'muted'
        if ($s.State -eq 'Running') { $tone = 'good' }
        elseif ($s.StartMode -eq 'Auto') { $tone = 'warn' }
        [pscustomobject]@{
            Name = [string]$s.Name; Display = [string]$s.DisplayName; State = [string]$s.State
            StartMode = [string]$s.StartMode; Account = [string]$s.StartName; Id = [string]$s.Name; Tone = $tone
        }
    }
}

$script:ServiceActionScript = {
    param($Name, $Action)
    try {
        switch ($Action) {
            'start'    { Start-Service -Name $Name -ErrorAction Stop }
            'stop'     { Stop-Service -Name $Name -Force -ErrorAction Stop }
            'restart'  { Restart-Service -Name $Name -Force -ErrorAction Stop }
            'auto'     { Set-Service -Name $Name -StartupType Automatic -ErrorAction Stop }
            'manual'   { Set-Service -Name $Name -StartupType Manual -ErrorAction Stop }
            'disabled' { Set-Service -Name $Name -StartupType Disabled -ErrorAction Stop }
        }
        'OK'
    }
    catch { 'ERR: ' + $_.Exception.Message }
}

$script:ProgramsScript = {
    $keys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    $seen = @{}
    foreach ($key in $keys) {
        foreach ($p in @(Get-ItemProperty -Path $key -ErrorAction SilentlyContinue)) {
            if (-not $p.DisplayName) { continue }
            if ($p.SystemComponent -eq 1) { continue }
            if ($p.ParentKeyName) { continue }
            $id = [string]$p.DisplayName + '|' + [string]$p.DisplayVersion
            if ($seen.ContainsKey($id)) { continue }
            $seen[$id] = $true
            $mb = 0.0
            if ($p.EstimatedSize) { $mb = [math]::Round([double]$p.EstimatedSize / 1024, 1) }
            $date = ''
            $raw = [string]$p.InstallDate
            if ($raw -match '^\d{8}$') { $date = $raw.Substring(0, 4) + '-' + $raw.Substring(4, 2) + '-' + $raw.Substring(6, 2) }
            [pscustomobject]@{
                Name = [string]$p.DisplayName; Version = [string]$p.DisplayVersion; Publisher = [string]$p.Publisher
                InstallDate = $date; SizeMB = $mb; Uninstall = [string]$p.UninstallString; Id = $id
            }
        }
    }
}

# ---------- Tabs ----------
function Show-AstAppsTab {
    param([string]$Key)
    $ctx = $script:AppsCtx
    if (-not $ctx) { return }
    $content = $ctx.Content
    $content.SuspendLayout()
    foreach ($c in @($content.Controls)) { $content.Controls.Remove($c); $c.Dispose() }
    try {
        switch ($Key) {
            'startup'  { Build-AstStartupTab $content }
            'services' { Build-AstServicesTab $content }
            'programs' { Build-AstProgramsTab $content }
        }
    }
    catch { Write-AstLog 'ERROR' ("Apps tab '{0}' failed: {1}" -f $Key, $_.Exception.ToString()) }
    $content.ResumeLayout($true)
}

function Build-AstPage-startup {
    param($Container)
    $ctx = @{}
    $script:AppsCtx = $ctx
    $content = [System.Windows.Forms.Panel]::new()
    $content.Dock = 'Fill'
    $content.Padding = [System.Windows.Forms.Padding]::new(0, (Sz 6), 0, 0)
    $ctx.Content = $content
    $tabs = @(
        @{ Key = 'startup';  Title = 'tab_startup';  Icon = 'power' },
        @{ Key = 'services'; Title = 'tab_services'; Icon = 'settings' },
        @{ Key = 'programs'; Title = 'tab_programs'; Icon = 'apps' }
    )
    $bar = New-AstTabBar $tabs 'Show-AstAppsTab'
    $Container.Controls.Add($content)
    $Container.Controls.Add($bar)
    $ctx.Bar = $bar
    Select-AstTab $bar 'startup' 'Show-AstAppsTab'
}

function New-AstListSection {
    param([string]$TitleKey, [string]$Icon, [string]$Color)
    $sec = New-AstSection (T $TitleKey) $Icon 100 $Color -Spinner
    $sec.Panel.Dock = 'Fill'
    return $sec
}

# ---------- Startup tab ----------
function Build-AstStartupTab {
    param($Content)
    $sec = New-AstListSection 'sec_startup' 'power' 'Warn'
    $toolbar = New-AstToolbar
    $count = New-AstLabel '' -Muted
    $count.Margin = [System.Windows.Forms.Padding]::new((Sz 6), (Sz 14), 0, 0)
    $cols = @(
        @{ Header = 'col_name'; Width = 230; Prop = 'Name' }, @{ Header = 'col_status'; Width = 100; Prop = 'Status' },
        @{ Header = 'col_source'; Width = 170; Prop = 'Source' }, @{ Header = 'col_command'; Width = 520; Prop = 'Command' })
    $list = New-AstDataList -Columns $cols -KeyProp 'Id' -CountKey 'count_items' -CountLabel $count
    $state = @{ List = $list; Spinner = $sec.Spinner }
    $script:AppsCtx.Startup = $state

    $bRef = New-AstButton (T 'refresh') -Icon 'refresh' -OnClick { Start-AstStartupLoad }
    $bOn = New-AstButton (T 'startup_enable') -Icon 'check' -Style primary -OnClick { Set-AstStartupSelected $true } -Tip (T 'startup_enable_tip')
    $bOff = New-AstButton (T 'startup_disable') -Icon 'cancel' -OnClick { Set-AstStartupSelected $false } -Tip (T 'startup_disable_tip')
    $bOpen = New-AstButton (T 'startup_taskmgr') -Icon 'pulse' -OnClick { Start-Process -FilePath 'taskmgr.exe' -ArgumentList '/0 /startup' } -Tip (T 'startup_taskmgr_tip')
    foreach ($c in @($bRef, $bOn, $bOff, $bOpen, (New-AstSearchBox $list 200), $count)) { $toolbar.Controls.Add($c) }
    $sec.Body.Controls.Add($list)
    $sec.Body.Controls.Add($toolbar)
    $Content.Controls.Add($sec.Panel)
    Start-AstStartupLoad
}

function Start-AstStartupLoad {
    $st = $script:AppsCtx.Startup
    if (-not $st -or $st.List.IsDisposed) { return }
    $st.Spinner.Visible = $true
    Start-AstBackground -ScriptBlock $script:StartupScript -State $st -OnComplete {
        param($res, $err, $s) Complete-AstStartupLoad $res $err $s
    }
}

function Complete-AstStartupLoad {
    param($Result, $ErrorText, $St)
    if (-not $St -or $St.List.IsDisposed) { return }
    $St.Spinner.Visible = $false
    $rows = @()
    foreach ($r in @($Result)) {
        if (-not $r -or -not $r.Id) { continue }
        if ($r.Enabled) { $status = T 'state_enabled'; $tone = 'good' } else { $status = T 'state_disabled'; $tone = 'muted' }
        $rows += $r | Add-Member -NotePropertyName Status -NotePropertyValue $status -PassThru |
            Add-Member -NotePropertyName Tone -NotePropertyValue $tone -PassThru
    }
    Set-AstDataList $St.List $rows
    if ($ErrorText) { Write-AstLog 'WARN' ('Startup load problem: ' + $ErrorText) }
}

function Set-AstStartupSelected {
    param([bool]$Enable)
    $st = $script:AppsCtx.Startup
    $row = Get-AstDataSelected $st.List
    if (-not $row) { [void](Show-AstMessage (T 'select_first') (T 'tab_startup') 'OK' 'Information'); return }
    if ($row.Hive -eq 'HKLM' -and -not (Assert-AstAdmin)) { return }
    $key = 'startup_disable_confirm'
    if ($Enable) { $key = 'startup_enable_confirm' }
    if ((Show-AstMessage ((T $key) -f $row.Name) (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    try {
        if (-not (Test-Path -Path $row.Approved)) { New-Item -Path $row.Approved -Force | Out-Null }
        $bytes = New-Object byte[] 12
        if ($Enable) { $bytes[0] = 2 }
        else {
            $bytes[0] = 3
            $ft = [BitConverter]::GetBytes([DateTime]::Now.ToFileTime())
            [Array]::Copy($ft, 0, $bytes, 4, 8)
        }
        New-ItemProperty -Path $row.Approved -Name $row.Name -PropertyType Binary -Value $bytes -Force | Out-Null
        Write-AstLog 'INFO' ("Startup item {0}: {1} ({2})" -f $(if ($Enable) { 'enabled' } else { 'disabled' }), $row.Name, $row.Source)
        Start-AstStartupLoad
    }
    catch {
        Write-AstLog 'ERROR' ('Startup change failed: ' + $_.Exception.Message)
        [void](Show-AstMessage ((T 'proc_failed') -f $_.Exception.Message) (T 'error_title') 'OK' 'Error')
    }
}

# ---------- Services tab ----------
function Build-AstServicesTab {
    param($Content)
    $sec = New-AstListSection 'sec_services' 'settings' 'Purple'
    $toolbar = New-AstToolbar
    $count = New-AstLabel '' -Muted
    $count.Margin = [System.Windows.Forms.Padding]::new((Sz 6), (Sz 14), 0, 0)
    $cols = @(
        @{ Header = 'col_name'; Width = 190; Prop = 'Name' }, @{ Header = 'col_display'; Width = 330; Prop = 'Display' },
        @{ Header = 'col_state'; Width = 100; Prop = 'State' }, @{ Header = 'col_startmode'; Width = 110; Prop = 'StartMode' },
        @{ Header = 'col_account'; Width = 200; Prop = 'Account' })
    $list = New-AstDataList -Columns $cols -KeyProp 'Id' -CountKey 'count_items' -CountLabel $count
    $lock = New-Object System.Collections.ArrayList
    $state = @{ List = $list; Spinner = $sec.Spinner; Lock = $lock }
    $script:AppsCtx.Services = $state

    $bRef = New-AstButton (T 'refresh') -Icon 'refresh' -OnClick { Start-AstServicesLoad }
    $bStart = New-AstButton (T 'svc_start') -Icon 'play' -Style primary -OnClick { Invoke-AstServiceAction 'start' }
    $bStop = New-AstButton (T 'svc_stop') -Icon 'stop' -OnClick { Invoke-AstServiceAction 'stop' }
    $bRestart = New-AstButton (T 'svc_restart') -Icon 'sync' -OnClick { Invoke-AstServiceAction 'restart' }
    $combo = New-AstCombo -Items @((T 'svc_auto'), (T 'svc_manual'), (T 'svc_disabled')) -Index 1 -Width 150
    $combo.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 6), (Sz 8), 0)
    $state.Mode = $combo
    $bSet = New-AstButton (T 'svc_set') -Icon 'check' -OnClick { Invoke-AstServiceMode } -Tip (T 'svc_set_tip')
    foreach ($b in @($bRef, $bStart, $bStop, $bRestart, $bSet)) { [void]$lock.Add($b) }
    foreach ($c in @($bRef, $bStart, $bStop, $bRestart, $combo, $bSet, (New-AstSearchBox $list 180), $count)) { $toolbar.Controls.Add($c) }
    $sec.Body.Controls.Add($list)
    $sec.Body.Controls.Add($toolbar)
    $Content.Controls.Add($sec.Panel)
    Start-AstServicesLoad
}

function Start-AstServicesLoad {
    $st = $script:AppsCtx.Services
    if (-not $st -or $st.List.IsDisposed) { return }
    $st.Spinner.Visible = $true
    Start-AstBackground -ScriptBlock $script:ServicesScript -State $st -OnComplete {
        param($res, $err, $s) Complete-AstServicesLoad $res $err $s
    }
}

function Complete-AstServicesLoad {
    param($Result, $ErrorText, $St)
    if (-not $St -or $St.List.IsDisposed) { return }
    $St.Spinner.Visible = $false
    Set-AstDataList $St.List @(@($Result) | Where-Object { $_ -and $_.Id })
    if ($ErrorText) { Write-AstLog 'WARN' ('Services load problem: ' + $ErrorText) }
}

function Invoke-AstServiceCommand {
    param([string]$Name, [string]$Action)
    $st = $script:AppsCtx.Services
    foreach ($b in @($st.Lock)) { if ($b -and -not $b.IsDisposed) { $b.Enabled = $false } }
    $st.Spinner.Visible = $true
    Start-AstBackground -ScriptBlock $script:ServiceActionScript -ArgumentList @($Name, $Action) -State $st -OnComplete {
        param($res, $err, $s) Complete-AstServiceCommand $res $err $s
    }
}

function Complete-AstServiceCommand {
    param($Result, $ErrorText, $St)
    if (-not $St -or $St.List.IsDisposed) { return }
    foreach ($b in @($St.Lock)) { if ($b -and -not $b.IsDisposed) { $b.Enabled = $true } }
    $msg = [string](@($Result)[0])
    if ($ErrorText -and -not $msg) { $msg = 'ERR: ' + $ErrorText }
    if ($msg -like 'ERR:*') {
        $St.Spinner.Visible = $false
        [void](Show-AstMessage ((T 'proc_failed') -f $msg.Substring(4).Trim()) (T 'error_title') 'OK' 'Error')
    }
    Start-AstServicesLoad
}

function Invoke-AstServiceAction {
    param([string]$Action)
    $st = $script:AppsCtx.Services
    $row = Get-AstDataSelected $st.List
    if (-not $row) { [void](Show-AstMessage (T 'select_first') (T 'tab_services') 'OK' 'Information'); return }
    if (-not (Assert-AstAdmin)) { return }
    if ($Action -ne 'start' -and ($script:ProtectedServices -contains $row.Name)) {
        Write-AstLog 'WARN' ('Blocked change of protected service ' + $row.Name)
        [void](Show-AstMessage ((T 'svc_protected') -f $row.Name) (T 'tab_services') 'OK' 'Warning')
        return
    }
    if ($Action -ne 'start') {
        if ((Show-AstMessage ((T 'svc_confirm') -f $Action, $row.Name) (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    }
    Write-AstLog 'INFO' ("Service action {0}: {1}" -f $Action, $row.Name)
    Invoke-AstServiceCommand $row.Name $Action
}

function Invoke-AstServiceMode {
    $st = $script:AppsCtx.Services
    $row = Get-AstDataSelected $st.List
    if (-not $row) { [void](Show-AstMessage (T 'select_first') (T 'tab_services') 'OK' 'Information'); return }
    if (-not (Assert-AstAdmin)) { return }
    $modes = @('auto', 'manual', 'disabled')
    $mode = $modes[[math]::Max(0, $st.Mode.SelectedIndex)]
    if ($script:ProtectedServices -contains $row.Name) {
        [void](Show-AstMessage ((T 'svc_protected') -f $row.Name) (T 'tab_services') 'OK' 'Warning')
        return
    }
    if ((Show-AstMessage ((T 'svc_confirm') -f $mode, $row.Name) (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    Write-AstLog 'INFO' ("Service startup type {0}: {1}" -f $mode, $row.Name)
    Invoke-AstServiceCommand $row.Name $mode
}

# ---------- Programs tab ----------
function Build-AstProgramsTab {
    param($Content)
    $sec = New-AstListSection 'sec_programs' 'apps' 'Accent'
    $toolbar = New-AstToolbar
    $count = New-AstLabel '' -Muted
    $count.Margin = [System.Windows.Forms.Padding]::new((Sz 6), (Sz 14), 0, 0)
    $cols = @(
        @{ Header = 'col_name'; Width = 330; Prop = 'Name' }, @{ Header = 'col_version'; Width = 120; Prop = 'Version' },
        @{ Header = 'col_publisher'; Width = 210; Prop = 'Publisher' }, @{ Header = 'col_date'; Width = 100; Prop = 'InstallDate' },
        @{ Header = 'col_size'; Width = 100; Prop = 'SizeMB' })
    $list = New-AstDataList -Columns $cols -KeyProp 'Id' -CountKey 'count_items' -CountLabel $count
    $state = @{ List = $list; Spinner = $sec.Spinner }
    $script:AppsCtx.Programs = $state

    $bRef = New-AstButton (T 'refresh') -Icon 'refresh' -OnClick { Start-AstProgramsLoad }
    $bUn = New-AstButton (T 'prog_uninstall') -Icon 'trash' -Style danger -OnClick { Invoke-AstUninstall } -Tip (T 'prog_uninstall_tip')
    $bEx = New-AstButton (T 'prog_export') -Icon 'save' -OnClick { Export-AstPrograms } -Tip (T 'prog_export_tip')
    $bWin = New-AstButton (T 'prog_windows') -Icon 'link' -OnClick { Start-Process -FilePath 'appwiz.cpl' }
    foreach ($c in @($bRef, $bUn, $bEx, $bWin, (New-AstSearchBox $list 190), $count)) { $toolbar.Controls.Add($c) }
    $sec.Body.Controls.Add($list)
    $sec.Body.Controls.Add($toolbar)
    $Content.Controls.Add($sec.Panel)
    Start-AstProgramsLoad
}

function Start-AstProgramsLoad {
    $st = $script:AppsCtx.Programs
    if (-not $st -or $st.List.IsDisposed) { return }
    $st.Spinner.Visible = $true
    Start-AstBackground -ScriptBlock $script:ProgramsScript -State $st -OnComplete {
        param($res, $err, $s) Complete-AstProgramsLoad $res $err $s
    }
}

function Complete-AstProgramsLoad {
    param($Result, $ErrorText, $St)
    if (-not $St -or $St.List.IsDisposed) { return }
    $St.Spinner.Visible = $false
    Set-AstDataList $St.List @(@($Result) | Where-Object { $_ -and $_.Id })
    if ($ErrorText) { Write-AstLog 'WARN' ('Programs load problem: ' + $ErrorText) }
}

function Invoke-AstUninstall {
    $st = $script:AppsCtx.Programs
    $row = Get-AstDataSelected $st.List
    if (-not $row) { [void](Show-AstMessage (T 'select_first') (T 'tab_programs') 'OK' 'Information'); return }
    if (-not $row.Uninstall) { [void](Show-AstMessage (T 'prog_no_uninstall') (T 'tab_programs') 'OK' 'Information'); return }
    if ((Show-AstMessage ((T 'prog_confirm') -f $row.Name) (T 'confirm_title') 'YesNo' 'Warning') -ne 'Yes') { return }
    try {
        # cmd strips the outer quotes it is given, so the original command stays intact
        [void][System.Diagnostics.Process]::Start('cmd.exe', ('/c "' + [string]$row.Uninstall + '"'))
        Write-AstLog 'INFO' ('Uninstall started for: ' + $row.Name)
    }
    catch { [void](Show-AstMessage ((T 'proc_failed') -f $_.Exception.Message) (T 'error_title') 'OK' 'Error') }
}

function Export-AstPrograms {
    $st = $script:AppsCtx.Programs
    $rows = @($st.List.Tag.Data)
    if ($rows.Count -eq 0) { return }
    try {
        $file = Join-Path $script:Paths['Reports'] ('programs_{0}.csv' -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
        $rows | Select-Object Name, Version, Publisher, InstallDate, SizeMB | Export-Csv -Path $file -NoTypeInformation -Encoding UTF8
        Write-AstLog 'INFO' ('Programs exported: ' + $file)
        Start-Process -FilePath 'explorer.exe' -ArgumentList ('/select,"{0}"' -f $file)
    }
    catch { [void](Show-AstMessage ((T 'proc_failed') -f $_.Exception.Message) (T 'error_title') 'OK' 'Error') }
}
