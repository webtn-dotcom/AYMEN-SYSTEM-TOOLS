# ============================================================
# Page.Network.ps1 - adapters overview, one-click diagnosis, ping / traceroute / DNS tools
# ASCII-only file.
# ============================================================

$script:NetCtx = $null

# ---------- Background scripts ----------
$script:AdaptersScript = {
    $cfgs = @{}
    try { foreach ($c in (Get-NetIPConfiguration -ErrorAction Stop)) { $cfgs[[string]$c.InterfaceAlias] = $c } } catch { }
    $rows = @()
    try {
        foreach ($a in (Get-NetAdapter -ErrorAction Stop | Sort-Object Status, Name)) {
            $ip = ''; $gw = ''; $dns = ''
            $c = $cfgs[[string]$a.Name]
            if ($c) {
                try { $ip = (@($c.IPv4Address | ForEach-Object { $_.IPAddress }) -join ', ') } catch { }
                try { if ($c.IPv4DefaultGateway) { $gw = [string](@($c.IPv4DefaultGateway)[0]).NextHop } } catch { }
                try { $dns = (@($c.DNSServer | Where-Object { $_.AddressFamily -eq 2 } | ForEach-Object { $_.ServerAddresses }) -join ', ') } catch { }
            }
            $rows += [pscustomobject]@{
                Name = [string]$a.Name; Status = [string]$a.Status; Ip = $ip; Gateway = $gw
                Dns = $dns; Speed = [string]$a.LinkSpeed; Mac = [string]$a.MacAddress
            }
        }
    }
    catch { }
    , $rows
}

$script:NetDiagScript = {
    param($Shared, $M)
    function Say([string]$text) { [void]$Shared['Lines'].Add($text) }
    $Shared['Status'] = [string]$M['title']
    $Shared['Percent'] = 5.0

    $gw = $null; $ip = ''; $alias = ''
    try {
        $cfg = Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.NetAdapter.Status -eq 'Up' -and $_.IPv4DefaultGateway } | Select-Object -First 1
        if ($cfg) {
            $gw = [string](@($cfg.IPv4DefaultGateway)[0]).NextHop
            $alias = [string]$cfg.InterfaceAlias
            $ip = [string](@($cfg.IPv4Address)[0]).IPAddress
        }
    }
    catch { }
    if ($gw) { Say ('[ OK ]  ' + ([string]$M['adapter_ok'] -f $alias, $ip)) }
    else { Say ('[FAIL]  ' + [string]$M['adapter_fail']); $Shared['Percent'] = 100.0; return }

    $Shared['Percent'] = 30.0
    $r = $false
    try { $r = Test-Connection -ComputerName $gw -Count 2 -Quiet -ErrorAction Stop } catch { }
    if ($r) { Say ('[ OK ]  ' + ([string]$M['gw_ok'] -f $gw)) } else { Say ('[FAIL]  ' + ([string]$M['gw_fail'] -f $gw)) }

    $Shared['Percent'] = 55.0
    $r2 = $false
    try { $r2 = Test-Connection -ComputerName '1.1.1.1' -Count 2 -Quiet -ErrorAction Stop } catch { }
    if ($r2) { Say ('[ OK ]  ' + [string]$M['inet_ok']) } else { Say ('[FAIL]  ' + [string]$M['inet_fail']) }

    $Shared['Percent'] = 80.0
    $r3 = $false
    try { $null = Resolve-DnsName -Name 'www.microsoft.com' -Type A -DnsOnly -ErrorAction Stop; $r3 = $true } catch { }
    if ($r3) { Say ('[ OK ]  ' + [string]$M['dns_ok']) } else { Say ('[FAIL]  ' + [string]$M['dns_fail']) }

    $Shared['Percent'] = 100.0
    Say ''
    Say ([string]$M['done'])
}

$script:DnsLookupScript = {
    param($Shared, $Name)
    $Shared['Status'] = [string]$Name
    try {
        $out = Resolve-DnsName -Name $Name -ErrorAction Stop | Select-Object Name, Type, TTL, IPAddress, NameHost | Format-Table -AutoSize | Out-String -Width 200
        foreach ($l in ($out -split "`r?`n")) { if ($l.Trim().Length -gt 0) { [void]$Shared['Lines'].Add($l.TrimEnd()) } }
    }
    catch { [void]$Shared['Lines'].Add('ERROR: ' + $_.Exception.Message) }
}

$script:ConnectionsScript = {
    param($Shared)
    try {
        $out = Get-NetTCPConnection -State Established -ErrorAction Stop |
            Sort-Object RemoteAddress |
            Select-Object -First 80 LocalAddress, LocalPort, RemoteAddress, RemotePort,
                @{ n = 'Process'; e = { (Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName } } |
            Format-Table -AutoSize | Out-String -Width 220
        foreach ($l in ($out -split "`r?`n")) { if ($l.Trim().Length -gt 0) { [void]$Shared['Lines'].Add($l.TrimEnd()) } }
    }
    catch { [void]$Shared['Lines'].Add('ERROR: ' + $_.Exception.Message) }
}

# ---------- Adapters ----------
function Start-AstAdaptersLoad {
    $ctx = $script:NetCtx
    if (-not $ctx -or $ctx.List.IsDisposed) { return }
    if ($ctx.Spinner) { $ctx.Spinner.Visible = $true }
    Start-AstBackground -ScriptBlock $script:AdaptersScript -State $ctx -OnComplete {
        param($res, $err, $st) Complete-AstAdaptersLoad $res $err $st
    }
}

function Complete-AstAdaptersLoad {
    param($Result, $ErrorText, $Ctx)
    if (-not $Ctx -or $Ctx.List.IsDisposed) { return }
    if ($Ctx.Spinner) { $Ctx.Spinner.Visible = $false }
    $rows = @()
    if ($Result -and @($Result).Count -gt 0) { $rows = @(@($Result)[0]) }
    $Ctx.List.BeginUpdate()
    try {
        $Ctx.List.Items.Clear()
        foreach ($r in $rows) {
            if (-not $r) { continue }
            $item = [System.Windows.Forms.ListViewItem]::new([string]$r.Name)
            [void]$item.SubItems.Add([string]$r.Status)
            [void]$item.SubItems.Add([string]$r.Ip)
            [void]$item.SubItems.Add([string]$r.Gateway)
            [void]$item.SubItems.Add([string]$r.Dns)
            [void]$item.SubItems.Add([string]$r.Speed)
            [void]$item.SubItems.Add([string]$r.Mac)
            if ($r.Status -eq 'Up') { $item.ForeColor = $script:Theme.Good } else { $item.ForeColor = $script:Theme.TextMuted }
            [void]$Ctx.List.Items.Add($item)
        }
    }
    finally { $Ctx.List.EndUpdate() }
    if ($ErrorText) { Write-AstLog 'WARN' ('Adapters load problem: ' + $ErrorText) }
}

# ---------- Tools ----------
function Get-AstHostInput {
    $ctx = $script:NetCtx
    if (-not $ctx) { return $null }
    $name = $ctx.Host.Text.Trim()
    if ($name -notmatch '^[A-Za-z0-9][A-Za-z0-9._:-]{0,252}$') {
        [void](Show-AstMessage (T 'net_host_invalid') (T 'sec_nettools') 'OK' 'Warning')
        return $null
    }
    return $name
}

function Start-AstNetSteps {
    param([object[]]$Steps, [bool]$NeedsAdmin = $false, [string]$ConfirmKey = '')
    $ctx = $script:NetCtx
    if (-not $ctx) { return }
    if ($NeedsAdmin -and -not (Assert-AstAdmin)) { return }
    if ($ConfirmKey) {
        if ((Show-AstMessage (T $ConfirmKey) (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    }
    Start-AstTask -Key 'net' -Console $ctx.Console -Steps $Steps -Lock $ctx.Lock
}

function Start-AstPing {
    $h = Get-AstHostInput
    if ($h) { Start-AstNetSteps -Steps @(@{ Title = ((T 'step_ping') -f $h); Exe = 'ping.exe'; Args = ('-n 4 ' + $h) }) }
}
function Start-AstTraceroute {
    $h = Get-AstHostInput
    if ($h) { Start-AstNetSteps -Steps @(@{ Title = ((T 'step_trace') -f $h); Exe = 'tracert.exe'; Args = ('-d -h 25 ' + $h) }) }
}
function Start-AstDnsLookup {
    $h = Get-AstHostInput
    $ctx = $script:NetCtx
    if ($h -and $ctx) { Start-AstTask -Key 'net' -Console $ctx.Console -Script $script:DnsLookupScript -ScriptArgs @($h) -Lock $ctx.Lock }
}
function Start-AstNetDiag {
    $ctx = $script:NetCtx
    if (-not $ctx) { return }
    $msg = @{
        title = (T 'net_diag_title'); adapter_ok = (T 'net_diag_adapter_ok'); adapter_fail = (T 'net_diag_adapter_fail')
        gw_ok = (T 'net_diag_gw_ok'); gw_fail = (T 'net_diag_gw_fail'); inet_ok = (T 'net_diag_inet_ok')
        inet_fail = (T 'net_diag_inet_fail'); dns_ok = (T 'net_diag_dns_ok'); dns_fail = (T 'net_diag_dns_fail'); done = (T 'net_diag_done')
    }
    Start-AstTask -Key 'net' -Console $ctx.Console -Script $script:NetDiagScript -ScriptArgs @($msg) -Lock $ctx.Lock
}
function Start-AstConnections {
    $ctx = $script:NetCtx
    if ($ctx) { Start-AstTask -Key 'net' -Console $ctx.Console -Script $script:ConnectionsScript -Lock $ctx.Lock }
}
function Start-AstRenewIp {
    Start-AstNetSteps -NeedsAdmin $true -ConfirmKey 'net_renew_confirm' -Steps @(
        @{ Title = (T 'step_release'); Exe = 'ipconfig.exe'; Args = '/release' },
        @{ Title = (T 'step_renew'); Exe = 'ipconfig.exe'; Args = '/renew' })
}
function Start-AstNetReset {
    Start-AstNetSteps -NeedsAdmin $true -ConfirmKey 'net_reset_confirm' -Steps @(
        @{ Title = (T 'step_winsock'); Exe = 'netsh.exe'; Args = 'winsock reset' },
        @{ Title = (T 'step_iprest'); Exe = 'netsh.exe'; Args = 'int ip reset' })
}
function Start-AstFlushDnsNet {
    Start-AstNetSteps -NeedsAdmin $true -Steps @(@{ Title = (T 'step_flushdns'); Exe = 'ipconfig.exe'; Args = '/flushdns' })
}

# ---------- Page ----------
function Build-AstPage-network {
    param($Container)
    $expert = [bool]$script:Settings['ExpertMode']
    $stack = New-AstPage $Container 'desc_network'
    $lock = New-Object System.Collections.ArrayList
    $ctx = @{ Lock = $lock }
    $script:NetCtx = $ctx

    # --- Adapters ---
    $secA = New-AstSection (T 'sec_adapters') 'wifi' 236 'Sky' -Spinner
    $toolbar = New-AstToolbar
    $btnRef = New-AstButton (T 'refresh') -Icon 'refresh' -OnClick { Start-AstAdaptersLoad }
    $btnNc = New-AstButton (T 'net_open_connections') -Icon 'link' -OnClick { Start-Process -FilePath 'ncpa.cpl' } -Tip (T 'net_open_connections_tip')
    $toolbar.Controls.Add($btnRef); $toolbar.Controls.Add($btnNc)

    $lv = [System.Windows.Forms.ListView]::new()
    $lv.Dock = 'Fill'
    $lv.View = 'Details'
    $lv.FullRowSelect = $true
    $lv.HideSelection = $false
    $lv.BorderStyle = 'None'
    $lv.BackColor = $script:Theme.Surface2
    $lv.ForeColor = $script:Theme.Text
    $lv.Font = Get-AstFont 'Segoe UI' 9.5 'Regular'
    foreach ($col in @(@('net_col_name', 190), @('net_col_status', 80), @('net_col_ip', 130), @('net_col_gw', 120), @('net_col_dns', 170), @('net_col_speed', 90), @('net_col_mac', 140))) {
        [void]$lv.Columns.Add((T $col[0]), (Sz $col[1]))
    }
    $secA.Body.Controls.Add($lv)
    $secA.Body.Controls.Add($toolbar)
    Add-AstRow $stack $secA.Panel
    $ctx.List = $lv; $ctx.Spinner = $secA.Spinner

    # --- Diagnosis and tools ---
    $toolsHeight = 124
    if ($expert) { $toolsHeight = 176 }
    $secT = New-AstSection (T 'sec_nettools') 'search' $toolsHeight 'Accent'
    $flow = New-AstFlow
    $lblHost = New-AstLabel (T 'net_host') -Muted
    $lblHost.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 14), (Sz 8), 0)
    $txtHost = New-AstTextBox -Width 220
    $txtHost.Text = 'google.com'
    $txtHost.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 8), (Sz 14), 0)
    Set-AstTip $txtHost (T 'net_host_tip')
    $ctx.Host = $txtHost
    $bPing = New-AstButton (T 'net_ping') -Icon 'play' -OnClick { Start-AstPing } -Tip (T 'net_ping_tip')
    $bTrace = New-AstButton (T 'net_trace') -Icon 'link' -OnClick { Start-AstTraceroute } -Tip (T 'net_trace_tip')
    $bDns = New-AstButton (T 'net_dns') -Icon 'search' -OnClick { Start-AstDnsLookup } -Tip (T 'net_dns_tip')
    foreach ($c in @($lblHost, $txtHost, $bPing, $bTrace, $bDns)) { $flow.Controls.Add($c) }
    $flow.SetFlowBreak($bDns, $true)
    $bDiag = New-AstButton (T 'net_diag') -Icon 'check' -Style primary -OnClick { Start-AstNetDiag } -Tip (T 'net_diag_tip')
    $bFlush = New-AstButton (T 'fix_dns') -Icon 'refresh' -OnClick { Start-AstFlushDnsNet } -Tip (T 'fix_dns_tip')
    $flow.Controls.Add($bDiag); $flow.Controls.Add($bFlush)
    foreach ($b in @($bPing, $bTrace, $bDns, $bDiag, $bFlush)) { [void]$lock.Add($b) }
    if ($expert) {
        $flow.SetFlowBreak($bFlush, $true)
        $x1 = New-AstButton (T 'net_connections') -Icon 'filter' -OnClick { Start-AstConnections } -Tip (T 'net_connections_tip')
        $x2 = New-AstButton (T 'net_renew') -Icon 'sync' -OnClick { Start-AstRenewIp } -Tip (T 'net_renew_tip')
        $x3 = New-AstButton (T 'net_reset') -Icon 'warning' -Style danger -OnClick { Start-AstNetReset } -Tip (T 'net_reset_tip')
        foreach ($b in @($x1, $x2, $x3)) { $flow.Controls.Add($b); [void]$lock.Add($b) }
    }
    $secT.Body.Controls.Add($flow)
    Set-AstSectionAuto $secT $flow
    Add-AstRow $stack $secT.Panel

    # --- Output ---
    $secO = New-AstSection (T 'sec_output') 'cmd' 290 'Sky'
    $console = New-AstConsole -Key 'net'
    $console.Panel.Dock = 'Fill'
    $secO.Body.Controls.Add($console.Panel)
    Add-AstRow $stack $secO.Panel
    $ctx.Console = $console

    Connect-AstTask 'net' $console $lock
    Start-AstAdaptersLoad
}
