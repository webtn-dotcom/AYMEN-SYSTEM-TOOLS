# ============================================================
# Page.Tools.ps1 - Windows tools hub: one searchable place for the built-in admin tools
# ASCII-only file. Names/descriptions come from Lang\*.json (keys tool_<id> and tool_<id>_d).
# ============================================================

$script:ToolsCtx = $null

function Get-AstToolList {
    $sys = $env:SystemRoot
    return @(
        @{ Id = 'devmgmt';  Icon = 'devices'; Color = 'Accent'; Target = 'devmgmt.msc' },
        @{ Id = 'diskmgmt'; Icon = 'drive';   Color = 'Teal';   Target = 'diskmgmt.msc' },
        @{ Id = 'taskmgr';  Icon = 'pulse';   Color = 'Pink';   Target = 'taskmgr.exe' },
        @{ Id = 'services'; Icon = 'settings'; Color = 'Purple'; Target = 'services.msc' },
        @{ Id = 'eventvwr'; Icon = 'page';    Color = 'Warn';   Target = 'eventvwr.msc' },
        @{ Id = 'regedit';  Icon = 'code';    Color = 'Bad';    Target = 'regedit.exe' },
        @{ Id = 'msinfo';   Icon = 'info';    Color = 'Sky';    Target = 'msinfo32.exe' },
        @{ Id = 'msconfig'; Icon = 'power';   Color = 'Warn';   Target = 'msconfig.exe' },
        @{ Id = 'compmgmt'; Icon = 'settings'; Color = 'Accent'; Target = 'compmgmt.msc' },
        @{ Id = 'taskschd'; Icon = 'clock';   Color = 'Purple'; Target = 'taskschd.msc' },
        @{ Id = 'resmon';   Icon = 'pulse';   Color = 'Pink';   Target = 'resmon.exe' },
        @{ Id = 'perfmon';  Icon = 'pulse';   Color = 'Good';   Target = 'perfmon.exe' },
        @{ Id = 'appwiz';   Icon = 'apps';    Color = 'Accent'; Target = 'appwiz.cpl' },
        @{ Id = 'ncpa';     Icon = 'globe';   Color = 'Sky';    Target = 'ncpa.cpl' },
        @{ Id = 'power';    Icon = 'power';   Color = 'Good';   Target = 'powercfg.cpl' },
        @{ Id = 'sysdm';    Icon = 'settings'; Color = 'Purple'; Target = 'sysdm.cpl' },
        @{ Id = 'firewall'; Icon = 'lock';    Color = 'Bad';    Target = 'wf.msc' },
        @{ Id = 'defender'; Icon = 'lock';    Color = 'Good';   Target = 'windowsdefender:' },
        @{ Id = 'dxdiag';   Icon = 'search';  Color = 'Sky';    Target = 'dxdiag.exe' },
        @{ Id = 'mdsched';  Icon = 'devices'; Color = 'Warn';   Target = 'mdsched.exe' },
        @{ Id = 'dfrgui';   Icon = 'drive';   Color = 'Teal';   Target = 'dfrgui.exe' },
        @{ Id = 'cleanmgr'; Icon = 'trash';   Color = 'Good';   Target = 'cleanmgr.exe' },
        @{ Id = 'mstsc';    Icon = 'link';    Color = 'Sky';    Target = 'mstsc.exe' },
        @{ Id = 'cmd';      Icon = 'cmd';     Color = 'Accent'; Target = 'cmd.exe' },
        @{ Id = 'powershell'; Icon = 'cmd';   Color = 'Sky';    Target = 'powershell.exe' },
        @{ Id = 'cmdadmin'; Icon = 'cmd';     Color = 'Bad';    Target = 'cmd.exe'; Verb = 'RunAs' },
        @{ Id = 'hosts';    Icon = 'edit';    Color = 'Warn';   Target = 'notepad.exe'; Args = ('"' + $sys + '\System32\drivers\etc\hosts"'); Verb = 'RunAs' },
        @{ Id = 'startupfolder'; Icon = 'folder'; Color = 'Good'; Target = 'explorer.exe'; Args = 'shell:startup' }
    )
}

function Update-AstToolsGrid {
    $ctx = $script:ToolsCtx
    if (-not $ctx -or $ctx.Grid.IsDisposed) { return }
    $filter = $ctx.Search.Text.Trim()
    foreach ($c in @($ctx.Grid.Controls)) { $ctx.Grid.Controls.Remove($c); $c.Dispose() }
    $shown = 0
    foreach ($tool in (Get-AstToolList)) {
        $name = T ('tool_' + $tool.Id)
        $desc = T ('tool_' + $tool.Id + '_d')
        if ($filter.Length -gt 0) {
            $hit = ($name.IndexOf($filter, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) -or
                   ($desc.IndexOf($filter, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) -or
                   ($tool.Target.IndexOf($filter, [System.StringComparison]::OrdinalIgnoreCase) -ge 0)
            if (-not $hit) { continue }
        }
        $action = @{ Kind = 'launch'; Target = $tool.Target; Args = $tool.Args; Verb = $tool.Verb }
        $ctx.Grid.Controls.Add((New-AstTile $tool.Icon $name $desc $tool.Color $action))
        $shown++
    }
    $ctx.Count.Text = (T 'tools_count') -f $shown
    Update-AstStackLayout $ctx.Stack
}

function Build-AstPage-tools {
    param($Container)
    $stack = New-AstPage $Container 'desc_tools'
    $ctx = @{ Stack = $stack }
    $script:ToolsCtx = $ctx

    $bar = New-AstFlow
    $bar.Dock = 'None'
    $bar.Height = Sz 50
    $bar.WrapContents = $false
    $lbl = New-AstLabel (T 'tools_search') -Muted
    $lbl.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 14), (Sz 8), 0)
    $txt = New-AstTextBox -Width 300
    $txt.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 9), (Sz 14), 0)
    Set-AstTip $txt (T 'tools_search_tip')
    $cnt = New-AstLabel '' -Muted
    $cnt.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 14), 0, 0)
    $bar.Controls.Add($lbl); $bar.Controls.Add($txt); $bar.Controls.Add($cnt)
    Add-AstRow $stack $bar 4

    $grid = New-AstGrid -TileWidth 300 -TileHeight 108
    Add-AstRow $stack $grid
    $ctx.Grid = $grid; $ctx.Search = $txt; $ctx.Count = $cnt
    $txt.Add_TextChanged({ Update-AstToolsGrid })
    Update-AstToolsGrid
}
