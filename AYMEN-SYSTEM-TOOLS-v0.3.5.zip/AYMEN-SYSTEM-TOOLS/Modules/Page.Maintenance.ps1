# ============================================================
# Page.Maintenance.ps1 - disk cleanup, system repair (SFC / DISM / CHKDSK), Windows Update fixes
# ASCII-only file.
# Beginner mode: guided, safe actions. Expert mode (Settings): extra repair commands.
# Every system-changing action asks for confirmation; protected folders are never touched
# outside the fixed list below; nothing of the user's documents is ever deleted.
# ============================================================

$script:MaintCtx = $null

function Get-AstCleanCategories {
    $local = $env:LOCALAPPDATA
    $win = $env:SystemRoot
    $pd = $env:ProgramData
    return @(
        @{ Id = 'usertemp'; Paths = @($env:TEMP); Filter = '*'; Admin = $false; Safe = $true; Special = '' },
        @{ Id = 'wintemp';  Paths = @((Join-Path $win 'Temp')); Filter = '*'; Admin = $true; Safe = $true; Special = '' },
        @{ Id = 'wucache';  Paths = @((Join-Path $win 'SoftwareDistribution\Download')); Filter = '*'; Admin = $true; Safe = $true; Special = '' },
        @{ Id = 'thumbs';   Paths = @((Join-Path $local 'Microsoft\Windows\Explorer')); Filter = 'thumbcache_*.db'; Admin = $false; Safe = $true; Special = '' },
        @{ Id = 'crash';    Paths = @((Join-Path $local 'CrashDumps')); Filter = '*'; Admin = $false; Safe = $true; Special = '' },
        @{ Id = 'wer';      Paths = @((Join-Path $pd 'Microsoft\Windows\WER')); Filter = '*'; Admin = $true; Safe = $true; Special = '' },
        @{ Id = 'browser';  Paths = @((Join-Path $local 'Microsoft\Edge\User Data\Default\Cache\Cache_Data'), (Join-Path $local 'Google\Chrome\User Data\Default\Cache\Cache_Data')); Filter = '*'; Admin = $false; Safe = $false; Special = '' },
        @{ Id = 'recycle';  Paths = @(); Filter = '*'; Admin = $false; Safe = $false; Special = 'recycle' }
    )
}

# ---------- Background scripts ----------
$script:AnalyzeScript = {
    param($Cats)
    function Get-DirBytes {
        param([string]$Path, [string]$Filter = '*')
        if (-not (Test-Path -LiteralPath $Path)) { return 0.0 }
        $m = Get-ChildItem -LiteralPath $Path -Recurse -Force -File -Filter $Filter -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum
        if ($m -and $m.Sum) { return [double]$m.Sum }
        return 0.0
    }
    foreach ($cat in $Cats) {
        $bytes = 0.0
        if ($cat.Special -eq 'recycle') {
            foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
                $bytes += Get-DirBytes (Join-Path $d.Root '$Recycle.Bin') '*'
            }
        }
        else {
            foreach ($path in $cat.Paths) { $bytes += Get-DirBytes $path $cat.Filter }
        }
        [pscustomobject]@{ Id = [string]$cat.Id; Bytes = $bytes }
    }
}

$script:CleanScript = {
    param($Shared, $Cats, $LineFmt, $TotalFmt)
    function Get-DirBytes {
        param([string]$Path, [string]$Filter = '*')
        if (-not (Test-Path -LiteralPath $Path)) { return 0.0 }
        $m = Get-ChildItem -LiteralPath $Path -Recurse -Force -File -Filter $Filter -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum
        if ($m -and $m.Sum) { return [double]$m.Sum }
        return 0.0
    }
    $grand = 0.0
    $n = 0
    $total = @($Cats).Count
    foreach ($cat in $Cats) {
        if ($Shared['Stop']) { break }
        $Shared['Status'] = [string]$cat.Name
        $Shared['Percent'] = [double]($n / [math]::Max(1, $total) * 100)
        $n++
        $before = 0.0
        $after = 0.0
        if ($cat.Special -eq 'recycle') {
            $roots = @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | ForEach-Object { Join-Path $_.Root '$Recycle.Bin' })
            foreach ($r in $roots) { $before += Get-DirBytes $r '*' }
            try { Clear-RecycleBin -Force -ErrorAction Stop } catch { }
            foreach ($r in $roots) { $after += Get-DirBytes $r '*' }
        }
        else {
            foreach ($path in $cat.Paths) {
                if (-not (Test-Path -LiteralPath $path)) { continue }
                $before += Get-DirBytes $path $cat.Filter
                Get-ChildItem -LiteralPath $path -Force -Filter $cat.Filter -ErrorAction SilentlyContinue |
                    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
                $after += Get-DirBytes $path $cat.Filter
            }
        }
        $freed = [math]::Max(0.0, $before - $after)
        $grand += $freed
        [void]$Shared['Lines'].Add(($LineFmt -f $cat.Name, ('{0:N1} MB' -f ($freed / 1MB))))
    }
    $Shared['Percent'] = 100.0
    [void]$Shared['Lines'].Add('')
    [void]$Shared['Lines'].Add(($TotalFmt -f ('{0:N1} MB' -f ($grand / 1MB))))
}

# ---------- Cleanup actions ----------
function Update-AstCleanTotal {
    $ctx = $script:MaintCtx
    if (-not $ctx -or $ctx.List.IsDisposed -or $ctx.Populating) { return }
    $sum = 0.0
    foreach ($item in $ctx.List.Items) { if ($item.Checked) { $sum += [double]$item.Tag.Bytes } }
    $ctx.Total.Text = (T 'clean_selected') -f (Format-AstBytes $sum)
}

function Start-AstAnalyze {
    $ctx = $script:MaintCtx
    if (-not $ctx -or $ctx.List.IsDisposed) { return }
    $ctx.AnalyzeBtn.Enabled = $false
    $ctx.CleanBtn.Enabled = $false
    if ($ctx.Spinner) { $ctx.Spinner.Visible = $true }
    $ctx.Total.Text = T 'clean_analyzing'
    $cats = @(Get-AstCleanCategories)
    Start-AstBackground -ScriptBlock $script:AnalyzeScript -ArgumentList @(, $cats) -State $ctx -OnComplete {
        param($res, $err, $st) Complete-AstAnalyze $res $err $st
    }
}

function Complete-AstAnalyze {
    param($Result, $ErrorText, $Ctx)
    if (-not $Ctx -or $Ctx.List.IsDisposed) { return }
    if ($Ctx.Spinner) { $Ctx.Spinner.Visible = $false }
    $Ctx.AnalyzeBtn.Enabled = $true
    $Ctx.CleanBtn.Enabled = $true
    $sizes = @{}
    foreach ($r in @($Result)) { if ($r -and $r.Id) { $sizes[[string]$r.Id] = [double]$r.Bytes } }

    $Ctx.Populating = $true
    $Ctx.List.BeginUpdate()
    try {
        $Ctx.List.Items.Clear()
        foreach ($cat in (Get-AstCleanCategories)) {
            $bytes = 0.0
            if ($sizes.ContainsKey($cat.Id)) { $bytes = $sizes[$cat.Id] }
            $name = T ('clean_' + $cat.Id)
            if ($cat.Admin) { $name = $name + '  *' }
            $item = [System.Windows.Forms.ListViewItem]::new($name)
            [void]$item.SubItems.Add((Format-AstBytes $bytes))
            $location = T ('clean_' + $cat.Id + '_loc')
            [void]$item.SubItems.Add($location)
            $item.Tag = @{ Id = $cat.Id; Bytes = $bytes; Admin = $cat.Admin }
            $item.Checked = ($cat.Safe -and $bytes -gt 0)
            [void]$Ctx.List.Items.Add($item)
        }
    }
    finally { $Ctx.List.EndUpdate(); $Ctx.Populating = $false }
    Update-AstCleanTotal
}

function Start-AstClean {
    $ctx = $script:MaintCtx
    if (-not $ctx -or $ctx.List.IsDisposed) { return }
    $ids = @()
    $needsAdmin = $false
    $sum = 0.0
    foreach ($item in $ctx.List.Items) {
        if ($item.Checked) {
            $ids += [string]$item.Tag.Id
            $sum += [double]$item.Tag.Bytes
            if ($item.Tag.Admin) { $needsAdmin = $true }
        }
    }
    if ($ids.Count -eq 0) { [void](Show-AstMessage (T 'clean_none') (T 'sec_clean') 'OK' 'Information'); return }

    $message = (T 'clean_confirm') -f $ids.Count, (Format-AstBytes $sum)
    if ($needsAdmin -and -not (Test-AstAdmin)) { $message = $message + "`n`n" + (T 'clean_admin_skip') }
    if ((Show-AstMessage $message (T 'sec_clean') 'YesNo' 'Question') -ne 'Yes') { return }

    $selected = @()
    foreach ($cat in (Get-AstCleanCategories)) {
        if ($ids -contains $cat.Id) {
            $cat['Name'] = T ('clean_' + $cat.Id)
            $selected += $cat
        }
    }
    Start-AstTask -Key 'maint' -Console $ctx.Console -Script $script:CleanScript `
        -ScriptArgs @($selected, (T 'clean_line'), (T 'clean_total')) -Lock $ctx.Lock -OnDone 'Complete-AstClean'
}

function Complete-AstClean {
    param($Task)
    $ctx = $script:MaintCtx
    if ($ctx -and -not $ctx.List.IsDisposed) { Start-AstAnalyze }
}

# ---------- Repair actions ----------
function Start-AstMaintSteps {
    param([object[]]$Steps, [bool]$NeedsAdmin = $true, [string]$ConfirmKey = '')
    $ctx = $script:MaintCtx
    if (-not $ctx) { return }
    if ($NeedsAdmin -and -not (Assert-AstAdmin)) { return }
    if ($ConfirmKey) {
        if ((Show-AstMessage (T $ConfirmKey) (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    }
    Start-AstTask -Key 'maint' -Console $ctx.Console -Steps $Steps -Lock $ctx.Lock
}

function Start-AstRepairFull {
    Start-AstMaintSteps -ConfirmKey 'repair_full_confirm' -Steps @(
        @{ Title = (T 'step_dism_restore'); Exe = 'DISM.exe'; Args = '/Online /Cleanup-Image /RestoreHealth'; Progress = $true },
        @{ Title = (T 'step_sfc'); Exe = 'sfc.exe'; Args = '/scannow'; Encoding = 'unicode'; Progress = $true }
    )
}
function Start-AstSfc {
    Start-AstMaintSteps -ConfirmKey 'sfc_confirm' -Steps @(
        @{ Title = (T 'step_sfc'); Exe = 'sfc.exe'; Args = '/scannow'; Encoding = 'unicode'; Progress = $true })
}
function Start-AstDismCheck {
    Start-AstMaintSteps -Steps @(
        @{ Title = (T 'step_dism_check'); Exe = 'DISM.exe'; Args = '/Online /Cleanup-Image /CheckHealth'; Progress = $true })
}
function Start-AstDismScan {
    Start-AstMaintSteps -Steps @(
        @{ Title = (T 'step_dism_scan'); Exe = 'DISM.exe'; Args = '/Online /Cleanup-Image /ScanHealth'; Progress = $true })
}
function Start-AstDismRestore {
    Start-AstMaintSteps -ConfirmKey 'dism_restore_confirm' -Steps @(
        @{ Title = (T 'step_dism_restore'); Exe = 'DISM.exe'; Args = '/Online /Cleanup-Image /RestoreHealth'; Progress = $true })
}
function Start-AstDismCleanup {
    Start-AstMaintSteps -ConfirmKey 'dism_cleanup_confirm' -Steps @(
        @{ Title = (T 'step_dism_cleanup'); Exe = 'DISM.exe'; Args = '/Online /Cleanup-Image /StartComponentCleanup'; Progress = $true })
}
function Start-AstChkdsk {
    $ctx = $script:MaintCtx
    if (-not $ctx -or -not $ctx.Drive -or $ctx.Drive.SelectedItem -eq $null) { return }
    $drive = [string]$ctx.Drive.SelectedItem
    if ($drive -notmatch '^[A-Za-z]:$') { return }
    Start-AstMaintSteps -Steps @(
        @{ Title = ((T 'step_chkdsk') -f $drive); Exe = 'chkdsk.exe'; Args = ($drive + ' /scan'); Progress = $true })
}
function Start-AstWuReset {
    Start-AstMaintSteps -ConfirmKey 'wu_reset_confirm' -Steps @(
        @{ Title = (T 'step_wu_reset'); Exe = 'cmd.exe'; Args = '/c net stop wuauserv' },
        @{ Exe = 'cmd.exe'; Args = '/c net stop cryptSvc' },
        @{ Exe = 'cmd.exe'; Args = '/c net stop bits' },
        @{ Exe = 'cmd.exe'; Args = '/c net stop msiserver' },
        @{ Exe = 'cmd.exe'; Args = '/c ren "%SystemRoot%\SoftwareDistribution" SoftwareDistribution.old' },
        @{ Exe = 'cmd.exe'; Args = '/c ren "%SystemRoot%\System32\catroot2" catroot2.old' },
        @{ Exe = 'cmd.exe'; Args = '/c net start wuauserv' },
        @{ Exe = 'cmd.exe'; Args = '/c net start cryptSvc' },
        @{ Exe = 'cmd.exe'; Args = '/c net start bits' },
        @{ Exe = 'cmd.exe'; Args = '/c net start msiserver' }
    )
}
function Start-AstFlushDns {
    Start-AstMaintSteps -Steps @(@{ Title = (T 'step_flushdns'); Exe = 'ipconfig.exe'; Args = '/flushdns' })
}
function Restart-AstExplorer {
    if ((Show-AstMessage (T 'explorer_confirm') (T 'confirm_title') 'YesNo' 'Question') -ne 'Yes') { return }
    try {
        Stop-Process -Name explorer -Force -ErrorAction Stop
        Write-AstLog 'INFO' 'Windows Explorer restarted by user.'
    }
    catch { [void](Show-AstMessage ((T 'proc_failed') -f $_.Exception.Message) (T 'error_title') 'OK' 'Error') }
}

# ---------- Page ----------
function Build-AstPage-maintenance {
    param($Container)
    $expert = [bool]$script:Settings['ExpertMode']
    $stack = New-AstPage $Container 'desc_maintenance'
    $lock = New-Object System.Collections.ArrayList
    $ctx = @{ Lock = $lock; Populating = $false; Drive = $null }
    $script:MaintCtx = $ctx

    if (-not (Test-AstAdmin)) {
        Add-AstRow $stack (New-AstBanner (T 'maint_admin_banner') 'warning' 'Warn' (T 'restart_admin') { Invoke-AstRestartAdmin })
    }

    # --- Disk cleanup ---
    $secClean = New-AstSection (T 'sec_clean') 'trash' 262 'Good' -Spinner
    $btnAnalyze = New-AstButton (T 'clean_analyze') -Icon 'search' -OnClick { Start-AstAnalyze } -Tip (T 'clean_analyze_tip')
    $btnClean = New-AstButton (T 'clean_run') -Icon 'trash' -Style primary -OnClick { Start-AstClean } -Tip (T 'clean_run_tip')
    $lblTotal = New-AstLabel (T 'clean_hint') -Muted
    $lblTotal.Margin = [System.Windows.Forms.Padding]::new((Sz 6), (Sz 11), 0, 0)
    $toolbar = New-AstToolbar
    foreach ($c in @($btnAnalyze, $btnClean, $lblTotal)) { $toolbar.Controls.Add($c) }

    $lv = [System.Windows.Forms.ListView]::new()
    $lv.Dock = 'Fill'
    $lv.View = 'Details'
    $lv.CheckBoxes = $true
    $lv.FullRowSelect = $true
    $lv.HideSelection = $false
    $lv.BorderStyle = 'None'
    $lv.BackColor = $script:Theme.Surface2
    $lv.ForeColor = $script:Theme.Text
    $lv.Font = Get-AstFont 'Segoe UI' 9.5 'Regular'
    [void]$lv.Columns.Add((T 'clean_col_cat'), (Sz 330))
    [void]$lv.Columns.Add((T 'clean_col_size'), (Sz 110))
    [void]$lv.Columns.Add((T 'clean_col_loc'), (Sz 380))
    $lv.Add_ItemChecked({ Update-AstCleanTotal })
    $secClean.Body.Controls.Add($lv)
    $secClean.Body.Controls.Add($toolbar)
    Add-AstRow $stack $secClean.Panel

    $ctx.List = $lv; $ctx.Total = $lblTotal; $ctx.AnalyzeBtn = $btnAnalyze; $ctx.CleanBtn = $btnClean; $ctx.Spinner = $secClean.Spinner
    $secClean.Spinner.Visible = $false
    [void]$lock.Add($btnAnalyze); [void]$lock.Add($btnClean)

    # --- System repair ---
    $repairHeight = 118
    if ($expert) { $repairHeight = 214 }
    $secRepair = New-AstSection (T 'sec_repair') 'sync' $repairHeight 'Teal'
    $flow = New-AstFlow
    $hint = New-AstLabel (T 'repair_hint') -Muted -Width 900
    $flow.Controls.Add($hint)
    $flow.SetFlowBreak($hint, $true)
    $b1 = New-AstButton (T 'repair_full') -Icon 'sync' -Style primary -OnClick { Start-AstRepairFull } -Tip (T 'repair_full_tip')
    $b2 = New-AstButton (T 'repair_sfc') -Icon 'check' -OnClick { Start-AstSfc } -Tip (T 'repair_sfc_tip')
    $b3 = New-AstButton (T 'repair_dism_check') -Icon 'search' -OnClick { Start-AstDismCheck } -Tip (T 'repair_dism_check_tip')
    foreach ($b in @($b1, $b2, $b3)) { $flow.Controls.Add($b); [void]$lock.Add($b) }
    if ($expert) {
        $flow.SetFlowBreak($b3, $true)
        $e1 = New-AstButton (T 'repair_dism_scan') -Icon 'search' -OnClick { Start-AstDismScan } -Tip (T 'repair_dism_scan_tip')
        $e2 = New-AstButton (T 'repair_dism_restore') -Icon 'sync' -OnClick { Start-AstDismRestore } -Tip (T 'repair_dism_restore_tip')
        $e3 = New-AstButton (T 'repair_dism_cleanup') -Icon 'trash' -OnClick { Start-AstDismCleanup } -Tip (T 'repair_dism_cleanup_tip')
        foreach ($b in @($e1, $e2, $e3)) { $flow.Controls.Add($b); [void]$lock.Add($b) }
        $flow.SetFlowBreak($e3, $true)
        $drives = @([System.IO.DriveInfo]::GetDrives() | Where-Object { $_.DriveType -eq 'Fixed' -and $_.IsReady } | ForEach-Object { $_.Name.Substring(0, 2) })
        if ($drives.Count -eq 0) { $drives = @($env:SystemDrive) }
        $combo = New-AstCombo -Items $drives -Index 0 -Width 90
        $combo.Margin = [System.Windows.Forms.Padding]::new(0, (Sz 5), (Sz 8), 0)
        $ctx.Drive = $combo
        $e4 = New-AstButton (T 'repair_chkdsk') -Icon 'drive' -OnClick { Start-AstChkdsk } -Tip (T 'repair_chkdsk_tip')
        $flow.Controls.Add($combo); $flow.Controls.Add($e4)
        [void]$lock.Add($e4); [void]$lock.Add($combo)
    }
    $secRepair.Body.Controls.Add($flow)
    Set-AstSectionAuto $secRepair $flow
    Add-AstRow $stack $secRepair.Panel

    # --- Quick fixes ---
    $quickHeight = 66
    if ($expert) { $quickHeight = 66 }
    $secQuick = New-AstSection (T 'sec_quickfix') 'refresh' $quickHeight 'Warn'
    $qflow = New-AstFlow
    $q1 = New-AstButton (T 'fix_explorer') -Icon 'refresh' -OnClick { Restart-AstExplorer } -Tip (T 'fix_explorer_tip')
    $q2 = New-AstButton (T 'fix_dns') -Icon 'globe' -OnClick { Start-AstFlushDns } -Tip (T 'fix_dns_tip')
    $q3 = New-AstButton (T 'fix_cleanmgr') -Icon 'trash' -OnClick { Start-Process -FilePath 'cleanmgr.exe' } -Tip (T 'fix_cleanmgr_tip')
    $q4 = New-AstButton (T 'fix_update') -Icon 'download' -OnClick { Start-Process -FilePath 'ms-settings:windowsupdate' } -Tip (T 'fix_update_tip')
    foreach ($b in @($q1, $q2, $q3, $q4)) { $qflow.Controls.Add($b) }
    [void]$lock.Add($q2)
    if ($expert) {
        $q5 = New-AstButton (T 'fix_wureset') -Icon 'sync' -Style danger -OnClick { Start-AstWuReset } -Tip (T 'fix_wureset_tip')
        $qflow.Controls.Add($q5)
        [void]$lock.Add($q5)
    }
    $secQuick.Body.Controls.Add($qflow)
    Set-AstSectionAuto $secQuick $qflow
    Add-AstRow $stack $secQuick.Panel

    # --- Live output ---
    $secOut = New-AstSection (T 'sec_output') 'cmd' 290 'Sky'
    $console = New-AstConsole -Key 'maint'
    $console.Panel.Dock = 'Fill'
    $secOut.Body.Controls.Add($console.Panel)
    Add-AstRow $stack $secOut.Panel
    $ctx.Console = $console

    Connect-AstTask 'maint' $console $lock
    Start-AstAnalyze
}
