@echo off
title AYMEN SYSTEM TOOLS (debug)
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -NoExit -File "%~dp0AymenSystemTools.ps1"
