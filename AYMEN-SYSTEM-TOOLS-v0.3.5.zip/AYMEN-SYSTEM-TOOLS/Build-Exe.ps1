<#
    Build-Exe.ps1 - builds AYMEN-SYSTEM-TOOLS.exe into the "dist" folder.

    Mode Single   : ONE standalone EXE (all modules + languages embedded) made with PS2EXE.
                    No Modules folder, no Execution Policy problem, can be copied anywhere.
    Mode Launcher : tiny EXE compiled with the C# compiler built into Windows (works offline);
                    it starts AymenSystemTools.ps1 with -ExecutionPolicy Bypass. Keep it in the project folder.
    Mode Auto     : Single if PS2EXE is available (or installable), otherwise Launcher.

    Usage: double-click Build-Exe.bat   (or: powershell -ExecutionPolicy Bypass -File Build-Exe.ps1 -Mode Single)
    Keep this file ASCII-only.
#>
param(
    [ValidateSet('Auto', 'Single', 'Launcher')][string]$Mode = 'Auto',
    [switch]$RequireAdmin
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$root = $PSScriptRoot
if (-not $root) { $root = (Get-Location).Path }
$dist = Join-Path $root 'dist'
if (-not (Test-Path -LiteralPath $dist)) { New-Item -ItemType Directory -Path $dist | Out-Null }
$exe = Join-Path $dist 'AYMEN-SYSTEM-TOOLS.exe'
$ico = Join-Path $dist 'AYMEN-SYSTEM-TOOLS.ico'

function Write-Step { param([string]$Text) Write-Host ('[AST] ' + $Text) -ForegroundColor Cyan }

# ---------- application icon (drawn, no external file needed) ----------
function New-IconFile {
    param([string]$Path)
    $size = 64
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $r = 14
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc(0, 0, 2 * $r, 2 * $r, 180, 90)
    $path.AddArc($size - 2 * $r, 0, 2 * $r, 2 * $r, 270, 90)
    $path.AddArc($size - 2 * $r, $size - 2 * $r, 2 * $r, 2 * $r, 0, 90)
    $path.AddArc(0, $size - 2 * $r, 2 * $r, 2 * $r, 90, 90)
    $path.CloseFigure()
    $rect = New-Object System.Drawing.Rectangle(0, 0, $size, $size)
    $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, [System.Drawing.ColorTranslator]::FromHtml('#3B82F6'), [System.Drawing.ColorTranslator]::FromHtml('#8B5CF6'), [single]45)
    $g.FillPath($brush, $path)
    $font = New-Object System.Drawing.Font('Segoe MDL2 Assets', 30)
    $fmt = New-Object System.Drawing.StringFormat
    $fmt.Alignment = [System.Drawing.StringAlignment]::Center
    $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
    $g.DrawString([string][char]0xE713, $font, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF(0, 0, $size, $size)), $fmt)
    $g.Dispose()
    $icon = [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
    $fs = [System.IO.File]::Create($Path)
    try { $icon.Save($fs) } finally { $fs.Dispose() }
}

# ---------- Mode: Single (PS2EXE) ----------
function Build-Single {
    Write-Step 'Preparing the single-file script (modules and languages embedded)...'
    $names = @(Get-Content -LiteralPath (Join-Path $root 'Modules\modules.txt') | Where-Object { $_.Trim() -and -not $_.Trim().StartsWith('#') } | ForEach-Object { $_.Trim() })
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine("`$ErrorActionPreference = 'Stop'")
    [void]$sb.AppendLine('Add-Type -AssemblyName System.Windows.Forms, System.Drawing')
    [void]$sb.AppendLine('$script:EmbeddedLang = @{}')
    foreach ($code in 'en', 'fr', 'ar') {
        $file = Join-Path $root ('Lang\' + $code + '.json')
        $b64 = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($file))
        [void]$sb.AppendLine(("`$script:EmbeddedLang['{0}'] = '{1}'" -f $code, $b64))
    }
    foreach ($name in $names) {
        [void]$sb.AppendLine("`r`n# ===== module: $name =====")
        [void]$sb.AppendLine([System.IO.File]::ReadAllText((Join-Path $root ('Modules\' + $name + '.ps1'))))
    }
    [void]$sb.AppendLine('')
    [void]$sb.AppendLine('# ===== start =====')
    [void]$sb.AppendLine('$procPath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName')
    [void]$sb.AppendLine('if ([System.IO.Path]::GetFileName($procPath) -match ''^(powershell|pwsh|powershell_ise)\.exe$'') { $appRoot = $PSScriptRoot; if (-not $appRoot) { $appRoot = (Get-Location).Path } }')
    [void]$sb.AppendLine('else { $appRoot = Split-Path -Parent $procPath }')
    [void]$sb.AppendLine('Start-AstApplication -Root $appRoot')
    $single = Join-Path $dist 'AymenSystemTools.single.ps1'
    [System.IO.File]::WriteAllText($single, $sb.ToString(), (New-Object System.Text.ASCIIEncoding))

    if (-not (Get-Command -Name Invoke-ps2exe -ErrorAction SilentlyContinue)) {
        Write-Step 'PS2EXE not found: trying to load or install it (needs internet the first time)...'
        try { Import-Module ps2exe -ErrorAction Stop }
        catch {
            try {
                try { [void](Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope CurrentUser -Force -ErrorAction Stop) } catch { }
                Install-Module -Name ps2exe -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
                Import-Module ps2exe -ErrorAction Stop
            }
            catch { Write-Host ('PS2EXE could not be installed: ' + $_.Exception.Message) -ForegroundColor Yellow; return $false }
        }
    }
    Write-Step 'Compiling with PS2EXE...'
    $args2 = @{
        inputFile = $single; outputFile = $exe; noConsole = $true; STA = $true; noOutput = $true; noError = $true
        title = 'AYMEN SYSTEM TOOLS'; description = 'Windows maintenance and diagnostic toolbox'
        company = 'Aymen'; product = 'AYMEN SYSTEM TOOLS'; version = '0.3.5.0'
    }
    if (Test-Path -LiteralPath $ico) { $args2['iconFile'] = $ico }
    if ($RequireAdmin) { $args2['requireAdmin'] = $true }
    Invoke-ps2exe @args2
    return (Test-Path -LiteralPath $exe)
}

# ---------- Mode: Launcher (C# compiled with the compiler built into Windows) ----------
function Build-Launcher {
    Write-Step 'Compiling the launcher with the built-in C# compiler...'
    $src = @'
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

public static class AstLauncher
{
    [STAThread]
    public static void Main()
    {
        string dir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
        string script = Path.Combine(dir, "AymenSystemTools.ps1");
        if (!File.Exists(script))
        {
            DirectoryInfo parent = Directory.GetParent(dir);
            if (parent != null) script = Path.Combine(parent.FullName, "AymenSystemTools.ps1");
        }
        if (!File.Exists(script))
        {
            MessageBox.Show("AymenSystemTools.ps1 was not found next to this program.", "AYMEN SYSTEM TOOLS", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        ProcessStartInfo psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File \"" + script + "\"");
        psi.UseShellExecute = false;
        psi.CreateNoWindow = true;
        psi.WorkingDirectory = Path.GetDirectoryName(script);
        Process.Start(psi);
    }
}
'@
    $options = ''
    if (Test-Path -LiteralPath $ico) { $options = '/win32icon:"' + $ico + '"' }
    if (Test-Path -LiteralPath $exe) { Remove-Item -LiteralPath $exe -Force }
    if ($options) {
        Add-Type -TypeDefinition $src -ReferencedAssemblies 'System.Windows.Forms' -OutputAssembly $exe -OutputType WindowsApplication -CompilerOptions $options
    }
    else {
        Add-Type -TypeDefinition $src -ReferencedAssemblies 'System.Windows.Forms' -OutputAssembly $exe -OutputType WindowsApplication
    }
    return (Test-Path -LiteralPath $exe)
}

# ---------- run ----------
try {
    Write-Step 'Creating the application icon...'
    try { New-IconFile -Path $ico } catch { Write-Host ('Icon skipped: ' + $_.Exception.Message) -ForegroundColor Yellow }

    $ok = $false
    $used = ''
    if ($Mode -eq 'Single' -or $Mode -eq 'Auto') {
        try { $ok = [bool](Build-Single) } catch { Write-Host ('Single-file build failed: ' + $_.Exception.Message) -ForegroundColor Yellow }
        if ($ok) { $used = 'Single (standalone)' }
    }
    if (-not $ok -and ($Mode -eq 'Launcher' -or $Mode -eq 'Auto')) {
        $ok = [bool](Build-Launcher)
        if ($ok) { $used = 'Launcher (keep it in the project folder)' }
    }
    if ($ok) {
        Write-Host ''
        Write-Host ('DONE  ->  ' + $exe) -ForegroundColor Green
        Write-Host ('Mode  :  ' + $used) -ForegroundColor Green
    }
    else {
        Write-Host 'The EXE could not be built. See the messages above.' -ForegroundColor Red
        exit 1
    }
}
catch {
    Write-Host ('Build failed: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
