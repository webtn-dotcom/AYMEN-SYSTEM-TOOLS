@echo off
setlocal
title AYMEN SYSTEM TOOLS
cd /d "%~dp0"
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0AymenSystemTools.ps1"
endlocal
