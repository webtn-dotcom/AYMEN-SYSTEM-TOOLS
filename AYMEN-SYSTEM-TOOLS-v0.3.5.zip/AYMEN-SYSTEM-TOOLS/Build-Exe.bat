@echo off
setlocal
title Build AYMEN SYSTEM TOOLS EXE
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-Exe.ps1" %*
echo.
pause
endlocal
