# AYMEN SYSTEM TOOLS - project rules

Windows 10/11 maintenance and diagnostic desktop app. Tagline: "One Application. Complete Windows Control."

## Stack
- Windows PowerShell 5.1 + Windows Forms (no external dependencies). Launch: `Start-AymenSystemTools.bat` (debug: `...-Debug.bat`).
- Later: optional EXE build with PS2EXE.

## Conventions
- Modular: one file per feature group in `Modules\`, dot-sourced by `AymenSystemTools.ps1` (shared script scope, use `$script:` state).
- A page = `Build-AstPage-<Id>` function taking `$Container`; register the Id in `$script:Pages` (UI.ps1). Pages without a builder show "coming soon".
- All `.ps1` files stay ASCII-only. All visible text goes in `Lang\en.json`, `fr.json`, `ar.json` (UTF-8) and is read with `T 'key'`. Default language is English. Arabic = RTL.
- UI components live in `Modules\Kit.ps1` (New-AstPage / Add-AstRow stack, sections, tiles, console, spinner). RTL: use Get-AstStart / Get-AstEnd / New-AstPad; never set RightToLeftLayout (it recreates the window).
- Slow data: use Start-AstLoadAsync (spinner + background) or Start-AstTask (live console). Never run CIM/Get-ChildItem on big trees on the UI thread.
- Colors only from `$script:Theme` (dark/light). Pixel sizes through `Sz`. No closures with GetNewClosure in event handlers (read `$sender.Tag` instead).
- Long operations (SFC, DISM, cleanup) must run in a separate runspace so the UI never freezes: use `Start-AstBackground` (one-shot + callback) or `Start-AstWorker` (loop) from `Modules\Background.ps1`. Background scriptblocks cannot touch `$script:` state or controls.
- Pages that own timers/runspaces must set `$script:PageCleanup = { ... }` so they are released on page change, language/theme change and app exit (see Performance.ps1).
- Log with `Write-AstLog`; settings in `Config\settings.json`.

- Startup: modules are listed in `Modules\modules.txt`; add a new module there. Never dot-source module FILES (Execution Policy); the entry script and Build-Exe.ps1 read them as text.
- Layout: use `Set-AstSectionAuto $sec $flow` for button rows (auto height), `New-AstToolbar` (wraps), `Set-AstRegion` rounded corners, `Set-AstSlider` for scanning effects.

## Safety rules
- Ask for confirmation before any action that changes the system. Request admin rights only when needed.
- Never delete personal data, never disable Defender/firewall/core services, never edit the registry blindly.
- Offer restore points / undo where possible.

## Roadmap
1. Core, UI, themes, languages (done)
2. Live monitoring + process manager (done)
3A. Design system, dashboard, maintenance, network, tools, settings, help (done)
3B. Apps & Startup, Storage, Security, Diagnostics + report, Restore (done in 0.3.2)
4. Polish, custom icons, optional EXE build (PS2EXE)
3. Maintenance (cleanup, SFC, DISM, chkdsk) + Network tools
4. Startup manager, Storage, Security, Backup/Restore, reports, EXE
